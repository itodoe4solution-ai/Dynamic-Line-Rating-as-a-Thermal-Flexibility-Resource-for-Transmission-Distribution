from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd
import requests

from .common import ROOT, require_env, write_json


def _data_client():
    try:
        from acnportal.acndata import DataClient
    except ImportError as exc:
        raise RuntimeError("acnportal is not installed. Run pip install -r requirements.txt") from exc
    return DataClient(require_env("ACN_TOKEN"))


def _acn_api_root() -> str:
    # The public API is exposed under the ev.caltech.edu host.
    return "https://ev.caltech.edu/api/v1/"


def _session_has_timeseries(sess: dict) -> bool:
    for key in ("chargingCurrent", "pilotSignal"):
        payload = sess.get(key)
        if isinstance(payload, dict) and bool(payload.get("timestamps")):
            return True
    return False


def _session_sort_key(sess: dict) -> tuple[int, str]:
    ts = pd.to_datetime(sess.get("connectionTime"), utc=True, errors="coerce")
    if pd.isna(ts):
        ts = pd.Timestamp("1900-01-01T00:00:00Z")
    return int(ts.value), str(sess.get("sessionID") or sess.get("_id") or "")


def _parse_acn_timestamp(value) -> pd.Timestamp:
    if isinstance(value, pd.Timestamp):
        ts = value
    else:
        ts = pd.to_datetime(value, utc=True, errors="coerce")
    if pd.isna(ts):
        return pd.NaT
    return ts.tz_convert("UTC") if ts.tzinfo is not None else ts.tz_localize("UTC")


def rfc1123(ts: pd.Timestamp) -> str:
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.strftime("%a, %d %b %Y %H:%M:%S GMT")


def condition_for_window(start: pd.Timestamp, end: pd.Timestamp, min_energy_kwh: float = 0.0) -> str:
    # ACN API date fields are UTC/GMT. End is exclusive.
    return (
        f'connectionTime >= "{rfc1123(start)}" and '
        f'connectionTime < "{rfc1123(end)}" and '
        f'kWhDelivered >= {float(min_energy_kwh)}'
    )


def inventory_monthly(site: str, start_year: int, end_year: int, min_energy_kwh: float = 0.0) -> pd.DataFrame:
    client = _data_client()
    rows: list[dict] = []
    for year in range(start_year, end_year + 1):
        for month in range(1, 13):
            start = pd.Timestamp(year=year, month=month, day=1, tz="UTC")
            end = start + pd.offsets.MonthBegin(1)
            cond = condition_for_window(start, end, min_energy_kwh=min_energy_kwh)
            try:
                count = int(client.count_sessions(site, cond=cond))
                status = "ok"
                error = ""
            except Exception as exc:
                count = -1
                status = "error"
                error = str(exc)
            rows.append(
                {
                    "year": year,
                    "month": month,
                    "month_start_utc": start.isoformat(),
                    "month_end_utc_exclusive": end.isoformat(),
                    "session_count": count,
                    "status": status,
                    "error": error,
                }
            )
    df = pd.DataFrame(rows)
    return df


def recommend_12_month_windows(inventory: pd.DataFrame) -> pd.DataFrame:
    df = inventory.copy()
    df = df[df["status"].eq("ok") & df["session_count"].ge(0)].copy()
    if df.empty:
        return pd.DataFrame()
    df["month_start"] = pd.to_datetime(df["month_start_utc"], utc=True)
    full_index = pd.date_range(df["month_start"].min(), df["month_start"].max(), freq="MS", tz="UTC")
    counts = df.set_index("month_start")["session_count"].reindex(full_index)
    rows = []
    for i in range(0, max(0, len(counts) - 11)):
        w = counts.iloc[i:i+12]
        if len(w) < 12 or w.isna().any():
            continue
        rows.append(
            {
                "start_utc": w.index[0].isoformat(),
                "end_utc_exclusive": (w.index[-1] + pd.offsets.MonthBegin(1)).isoformat(),
                "total_sessions": int(w.sum()),
                "minimum_monthly_sessions": int(w.min()),
                "median_monthly_sessions": float(w.median()),
                "zero_months": int((w == 0).sum()),
            }
        )
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values(["zero_months", "minimum_monthly_sessions", "total_sessions"], ascending=[True, False, False])
    return out


def _json_safe(value):
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


def download_sessions(
    site: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    out_jsonl: Path,
    min_energy_kwh: float = 0.0,
    timeseries: bool = True,
    polite_sleep_seconds: float = 0.05,
    chunk_days: int = 7,
    replace_existing: bool = False,
    parallel_workers: int = 1,
) -> int:
    token = require_env("ACN_TOKEN")
    out_jsonl.parent.mkdir(parents=True, exist_ok=True)

    existing_records: dict[str, dict] = {}
    anonymous_records: list[dict] = []
    if out_jsonl.exists() and not replace_existing:
        with out_jsonl.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    obj = json.loads(line)
                    sid = obj.get("sessionID") or obj.get("_id")
                    if sid:
                        existing_records[str(sid)] = obj
                    else:
                        anonymous_records.append(obj)
                except json.JSONDecodeError:
                    pass

    n_new = 0
    n_upgraded = 0

    def _store_session(sess: dict) -> None:
        nonlocal n_new, n_upgraded
        sid = str(sess.get("sessionID") or sess.get("_id") or "")
        if sid:
            existing = existing_records.get(sid)
            if existing is not None:
                if timeseries and not _session_has_timeseries(existing) and _session_has_timeseries(sess):
                    existing_records[sid] = sess
                    n_upgraded += 1
                return
            existing_records[sid] = sess
            n_new += 1
        else:
            anonymous_records.append(sess)
            n_new += 1

    def _session_generator(chunk_start: pd.Timestamp, chunk_end: pd.Timestamp, use_timeseries: bool):
        endpoint = f"sessions/{site}/ts/" if use_timeseries else f"sessions/{site}"
        url = _acn_api_root() + endpoint
        max_results = 1 if use_timeseries else 100
        params = {
            "where": condition_for_window(chunk_start, chunk_end, min_energy_kwh=min_energy_kwh),
            "max_results": max_results,
        }
        while True:
            last_exc: Exception | None = None
            for attempt in range(4):
                try:
                    timeout_s = 600 if use_timeseries else 180
                    r = requests.get(url, params=params, auth=(token, ""), timeout=timeout_s)
                    r.raise_for_status()
                    last_exc = None
                    break
                except requests.RequestException as exc:
                    last_exc = exc
                    if attempt == 3:
                        raise
                    time.sleep(2 ** attempt)
            if last_exc is not None:
                raise last_exc
            payload = r.json()
            for sess in payload.get("_items", []):
                yield sess
            next_href = ((payload.get("_links") or {}).get("next") or {}).get("href")
            if not next_href:
                break
            url = _acn_api_root() + next_href.lstrip("/")
            params = None

    def _consume(gen) -> None:
        for sess in gen:
            _store_session(sess)
            if polite_sleep_seconds > 0:
                time.sleep(polite_sleep_seconds)

    def _collect_window(chunk_start: pd.Timestamp, chunk_end: pd.Timestamp, use_timeseries: bool) -> list[dict]:
        collected: list[dict] = []

        def _collect(gen) -> None:
            for sess in gen:
                collected.append(sess)

        span = chunk_end - chunk_start
        try:
            _collect(_session_generator(chunk_start, chunk_end, use_timeseries))
            return collected
        except Exception:
            if span > min_chunk:
                mid = chunk_start + span / 2
                if mid <= chunk_start or mid >= chunk_end:
                    mid = chunk_start + min_chunk
                collected.extend(_collect_window(chunk_start, mid, use_timeseries))
                collected.extend(_collect_window(mid, chunk_end, use_timeseries))
                return collected
            raise

    min_chunk = pd.Timedelta(days=1)

    def _fetch_chunk(chunk_start: pd.Timestamp, chunk_end: pd.Timestamp, use_timeseries: bool) -> None:
        span = chunk_end - chunk_start
        try:
            _consume(_session_generator(chunk_start, chunk_end, use_timeseries))
            return
        except Exception:
            if span > min_chunk:
                mid = chunk_start + span / 2
                if mid <= chunk_start or mid >= chunk_end:
                    mid = chunk_start + min_chunk
                _fetch_chunk(chunk_start, mid, use_timeseries)
                _fetch_chunk(mid, chunk_end, use_timeseries)
                return
            raise

    current = start
    chunk_span = pd.Timedelta(days=int(chunk_days))
    if parallel_workers > 1:
        chunk_bounds: list[tuple[pd.Timestamp, pd.Timestamp]] = []
        while current < end:
            chunk_end = min(current + chunk_span, end)
            chunk_bounds.append((current, chunk_end))
            current = chunk_end
        all_records: list[dict] = []
        with ThreadPoolExecutor(max_workers=int(parallel_workers)) as executor:
            futures = {
                executor.submit(_collect_window, chunk_start, chunk_end, timeseries): (chunk_start, chunk_end)
                for chunk_start, chunk_end in chunk_bounds
            }
            for future in as_completed(futures):
                all_records.extend(future.result())
        for sess in all_records:
            _store_session(sess)
    else:
        while current < end:
            chunk_end = min(current + chunk_span, end)
            _fetch_chunk(current, chunk_end, timeseries)
            current = chunk_end

    tmp_path = out_jsonl.with_suffix(out_jsonl.suffix + ".tmp")
    merged_records = list(existing_records.values()) + anonymous_records
    merged_records.sort(key=_session_sort_key)
    with tmp_path.open("w", encoding="utf-8") as f:
        for sess in merged_records:
            f.write(json.dumps(_json_safe(sess), ensure_ascii=False) + "\n")
    tmp_path.replace(out_jsonl)
    return n_new + n_upgraded


def sessions_jsonl_to_metadata_csv(jsonl_path: Path, out_csv: Path) -> pd.DataFrame:
    rows = []
    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            s = json.loads(line)
            user_inputs = s.get("userInputs") or []
            latest_input = user_inputs[-1] if isinstance(user_inputs, list) and user_inputs else {}
            rows.append(
                {
                    "session_id": s.get("sessionID") or s.get("_id"),
                    "site_id": s.get("siteID"),
                    "station_id": s.get("stationID"),
                    "space_id": s.get("spaceID"),
                    "cluster_id": s.get("clusterID"),
                    "connection_time_utc": _parse_acn_timestamp(s.get("connectionTime")),
                    "disconnect_time_utc": _parse_acn_timestamp(s.get("disconnectTime")),
                    "done_charging_time_utc": _parse_acn_timestamp(s.get("doneChargingTime")),
                    "measured_energy_delivered_kwh": s.get("kWhDelivered"),
                    "user_requested_kwh": latest_input.get("kWhRequested") if isinstance(latest_input, dict) else None,
                    "user_requested_departure": latest_input.get("requestedDeparture") if isinstance(latest_input, dict) else None,
                    "user_minutes_available": latest_input.get("minutesAvailable") if isinstance(latest_input, dict) else None,
                    "user_miles_requested": latest_input.get("milesRequested") if isinstance(latest_input, dict) else None,
                    "user_wh_per_mile": latest_input.get("WhPerMile") if isinstance(latest_input, dict) else None,
                    "has_charging_current_timeseries": bool((s.get("chargingCurrent") or {}).get("timestamps")) if isinstance(s.get("chargingCurrent"), dict) else False,
                    "has_pilot_signal_timeseries": bool((s.get("pilotSignal") or {}).get("timestamps")) if isinstance(s.get("pilotSignal"), dict) else False,
                    "source": "ACN-Data API",
                }
            )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["connection_time_utc"] = pd.to_datetime(df["connection_time_utc"], utc=True, errors="coerce")
        df["disconnect_time_utc"] = pd.to_datetime(df["disconnect_time_utc"], utc=True, errors="coerce")
        df["done_charging_time_utc"] = pd.to_datetime(df["done_charging_time_utc"], utc=True, errors="coerce")
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    return df
