from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .common import expected_index


def _timeseries_parts(obj: Any) -> tuple[list, list]:
    if not isinstance(obj, dict):
        return [], []
    ts = obj.get("timestamps") or obj.get("times") or []
    vals = (
        obj.get("current")
        or obj.get("values")
        or obj.get("pilot")
        or obj.get("data")
        or []
    )
    return list(ts), list(vals)


def _parse_acn_timestamp(value) -> pd.Timestamp:
    if isinstance(value, pd.Timestamp):
        ts = value
    else:
        ts = pd.to_datetime(value, utc=True, errors="coerce")
    if pd.isna(ts):
        return pd.NaT
    return ts.tz_convert("UTC") if ts.tzinfo is not None else ts.tz_localize("UTC")


def _parse_acn_timestamp_list(values: list) -> pd.DatetimeIndex:
    if not values:
        return pd.DatetimeIndex([])
    parsed = pd.to_datetime(values, utc=True, errors="coerce")
    if isinstance(parsed, pd.DatetimeIndex) and parsed.notna().sum() >= max(0, len(values) - 1):
        return parsed
    return pd.DatetimeIndex([_parse_acn_timestamp(v) for v in values])


def _overlap_hours(a0: pd.Timestamp, a1: pd.Timestamp, b0: pd.Timestamp, b1: pd.Timestamp) -> float:
    lo = max(a0, b0)
    hi = min(a1, b1)
    if hi <= lo:
        return 0.0
    return (hi - lo).total_seconds() / 3600.0


def _bin_positions(start: pd.Timestamp, end: pd.Timestamp, grid_start: pd.Timestamp, minutes: int, n: int):
    if end <= start:
        return range(0)
    step_s = minutes * 60
    i0 = max(0, int(np.floor((start - grid_start).total_seconds() / step_s)))
    i1 = min(n - 1, int(np.floor(((end - pd.Timedelta(microseconds=1)) - grid_start).total_seconds() / step_s)))
    if i1 < i0:
        return range(0)
    return range(i0, i1 + 1)


def _active_end(conn: pd.Timestamp, disc: pd.Timestamp, done: pd.Timestamp) -> pd.Timestamp:
    if pd.notna(done) and conn < done <= disc:
        return done
    return disc


def _session_segments(
    conn: pd.Timestamp,
    active_end: pd.Timestamp,
    t: pd.DatetimeIndex,
    c: np.ndarray,
) -> list[tuple[pd.Timestamp, pd.Timestamp, float]]:
    segments: list[tuple[pd.Timestamp, pd.Timestamp, float]] = []
    if len(t) < 1 or len(c) < 1:
        return segments

    valid = ~pd.isna(t)
    t = pd.DatetimeIndex(t[valid])
    c = c[np.asarray(valid)]
    if len(t) < 1 or len(c) < 1:
        return segments

    order = np.argsort(t.asi8)
    t = t[order]
    c = c[order]

    # Keep only samples close to the charging window.
    keep = (t >= conn - pd.Timedelta(minutes=5)) & (t <= active_end + pd.Timedelta(minutes=5))
    t, c = t[keep], c[keep]
    if len(t) < 1 or len(c) < 1:
        return segments

    positive_diffs = np.diff(t.asi8) / 1e9
    positive_diffs = positive_diffs[positive_diffs > 0]
    median_step_s = float(np.median(positive_diffs)) if len(positive_diffs) else 60.0

    for k in range(len(t)):
        seg_start = max(conn, t[k])
        if k + 1 < len(t):
            seg_end = min(active_end, t[k + 1])
        else:
            seg_end = min(active_end, t[k] + pd.Timedelta(seconds=median_step_s))
        if seg_end > seg_start:
            segments.append((seg_start, seg_end, float(c[k])))
    return segments


_DURATION_BUCKETS: tuple[tuple[str, float, float | None, float], ...] = (
    ("0-1h", 0.0, 1.0, 0.5),
    ("1-2h", 1.0, 2.0, 1.5),
    ("2-4h", 2.0, 4.0, 3.0),
    ("4-8h", 4.0, 8.0, 6.0),
    ("8h+", 8.0, None, 10.0),
)


def _duration_bucket_label(duration_h: float) -> str:
    if not np.isfinite(duration_h) or duration_h < 0:
        return "unknown"
    if duration_h < 1.0:
        return "0-1h"
    if duration_h < 2.0:
        return "1-2h"
    if duration_h < 4.0:
        return "2-4h"
    if duration_h < 8.0:
        return "4-8h"
    return "8h+"


def _bucket_center(label: str) -> float:
    for bucket_label, _, _, center in _DURATION_BUCKETS:
        if bucket_label == label:
            return center
    return 999.0


def _template_weights_from_stats(
    energy_bins: np.ndarray,
    duration_bins: np.ndarray,
    n_bins: int,
) -> np.ndarray:
    with np.errstate(invalid="ignore", divide="ignore"):
        avg_current = energy_bins / duration_bins
    avg_current = np.nan_to_num(avg_current, nan=0.0, posinf=0.0, neginf=0.0)
    avg_current = np.clip(avg_current, 0.0, None)
    total = float(avg_current.sum())
    if total <= 0:
        return np.full(n_bins, 1.0 / n_bins, dtype=float)
    return avg_current / total


def _build_duration_bucket_templates(
    jsonl_path: Path,
    start: pd.Timestamp,
    end: pd.Timestamp,
    n_bins: int = 24,
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    # Learn a coarse normalized charging-shape template from sessions that expose
    # measured charging-current traces. Fallback sessions reuse the template for
    # the matching charging-duration bucket instead of distributing all energy
    # uniformly across the active interval.
    global_energy_bins = np.zeros(n_bins, dtype=float)
    global_duration_bins = np.zeros(n_bins, dtype=float)
    bucket_energy_bins: dict[str, np.ndarray] = {}
    bucket_duration_bins: dict[str, np.ndarray] = {}
    bucket_order = [label for label, *_ in _DURATION_BUCKETS]
    for label in bucket_order:
        bucket_energy_bins[label] = np.zeros(n_bins, dtype=float)
        bucket_duration_bins[label] = np.zeros(n_bins, dtype=float)
    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            s = json.loads(line)
            conn = _parse_acn_timestamp(s.get("connectionTime"))
            disc = _parse_acn_timestamp(s.get("disconnectTime"))
            done = _parse_acn_timestamp(s.get("doneChargingTime"))
            delivered = pd.to_numeric(s.get("kWhDelivered"), errors="coerce")
            delivered = float(delivered) if pd.notna(delivered) else np.nan
            if pd.isna(conn) or pd.isna(disc) or pd.isna(delivered) or delivered <= 0:
                continue
            if disc <= conn:
                continue

            active_end = _active_end(conn, disc, done)
            if active_end <= conn:
                continue

            t_raw, c_raw = _timeseries_parts(s.get("chargingCurrent"))
            t = _parse_acn_timestamp_list(t_raw)
            c = pd.to_numeric(pd.Series(c_raw), errors="coerce").to_numpy(dtype=float) if c_raw else np.array([])
            if len(t) != len(c):
                m = min(len(t), len(c))
                t, c = t[:m], c[:m]
            if len(t) == 0 or len(c) == 0:
                continue
            if np.nanmin(c) < 0:
                c = np.clip(np.nan_to_num(c, nan=0.0, posinf=0.0, neginf=0.0), 0.0, None)
            else:
                c = np.nan_to_num(c, nan=0.0, posinf=0.0, neginf=0.0)

            segments = _session_segments(conn, active_end, t, c)
            duration_h = (active_end - conn).total_seconds() / 3600.0
            if duration_h <= 0 or not segments:
                continue

            bucket = _duration_bucket_label(duration_h)
            if bucket not in bucket_energy_bins:
                bucket = "8h+"
            for seg_start, seg_end, cur in segments:
                seg_hours = (seg_end - seg_start).total_seconds() / 3600.0
                if seg_hours <= 0:
                    continue
                rel_start = (seg_start - conn).total_seconds() / 3600.0 / duration_h
                rel_end = (seg_end - conn).total_seconds() / 3600.0 / duration_h
                rel_start = max(0.0, min(1.0, rel_start))
                rel_end = max(0.0, min(1.0, rel_end))
                if rel_end <= rel_start:
                    continue
                for j in range(n_bins):
                    left = bin_edges[j]
                    right = bin_edges[j + 1]
                    overlap = min(rel_end, right) - max(rel_start, left)
                    if overlap > 0:
                        bin_hours = overlap * duration_h
                        global_duration_bins[j] += bin_hours
                        global_energy_bins[j] += max(cur, 0.0) * bin_hours
                        bucket_duration_bins[bucket][j] += bin_hours
                        bucket_energy_bins[bucket][j] += max(cur, 0.0) * bin_hours

    bucket_templates = {
        label: _template_weights_from_stats(bucket_energy_bins[label], bucket_duration_bins[label], n_bins)
        for label in bucket_order
    }
    global_template = _template_weights_from_stats(global_energy_bins, global_duration_bins, n_bins)
    return bucket_templates, global_template


def _build_template_weights(
    jsonl_path: Path,
    start: pd.Timestamp,
    end: pd.Timestamp,
    n_bins: int = 24,
) -> np.ndarray:
    _, global_template = _build_duration_bucket_templates(jsonl_path, start, end, n_bins)
    return global_template


def _select_template_for_duration(
    duration_h: float,
    bucket_templates: dict[str, np.ndarray],
    global_template: np.ndarray,
) -> tuple[str, np.ndarray]:
    bucket = _duration_bucket_label(duration_h)
    template = bucket_templates.get(bucket)
    if template is not None and float(np.sum(template)) > 0:
        return bucket, template
    available = [
        (abs(duration_h - _bucket_center(label)), label, weights)
        for label, weights in bucket_templates.items()
        if float(np.sum(weights)) > 0 and np.isfinite(duration_h)
    ]
    if available:
        _, nearest_bucket, nearest_template = min(available, key=lambda item: item[0])
        return nearest_bucket, nearest_template
    return bucket, global_template


def _apply_template_to_interval(
    active_start: pd.Timestamp,
    active_end: pd.Timestamp,
    delivered_kwh: float,
    template_weights: np.ndarray,
    idx: pd.DatetimeIndex,
    grid_start: pd.Timestamp,
    interval_minutes: int,
) -> tuple[np.ndarray, set[int]]:
    energy = np.zeros(len(idx), dtype=float)
    session_charging_bins: set[int] = set()
    total_h = (active_end - active_start).total_seconds() / 3600.0
    if total_h <= 0 or delivered_kwh <= 0:
        return energy, session_charging_bins

    n_bins = len(template_weights)
    if n_bins < 1 or float(np.sum(template_weights)) <= 0:
        template_weights = np.full(24, 1.0 / 24.0, dtype=float)
        n_bins = len(template_weights)

    edges = np.linspace(0.0, 1.0, n_bins + 1)
    for j, w in enumerate(template_weights):
        if w <= 0:
            continue
        rel_start = edges[j]
        rel_end = edges[j + 1]
        seg_start = active_start + pd.Timedelta(seconds=rel_start * total_h * 3600.0)
        seg_end = active_start + pd.Timedelta(seconds=rel_end * total_h * 3600.0)
        dur_h = (seg_end - seg_start).total_seconds() / 3600.0
        if dur_h <= 0:
            continue
        e_seg = delivered_kwh * float(w)
        for i in _bin_positions(seg_start, seg_end, grid_start, interval_minutes, len(idx)):
            b0, b1 = idx[i], idx[i] + pd.Timedelta(minutes=interval_minutes)
            oh = _overlap_hours(seg_start, seg_end, b0, b1)
            if oh > 0:
                energy[i] += e_seg * (oh / dur_h)
                session_charging_bins.add(i)
    return energy, session_charging_bins


def build_ev_profile_from_jsonl(
    jsonl_path: Path,
    start: pd.Timestamp,
    end: pd.Timestamp,
    interval_minutes: int = 15,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    idx = expected_index(start, end, interval_minutes)
    n = len(idx)
    step = pd.Timedelta(minutes=interval_minutes)
    grid_start = idx[0] if len(idx) else start

    bucket_templates, global_template = _build_duration_bucket_templates(jsonl_path, start, end)

    energy = np.zeros(n, dtype=float)
    connected = np.zeros(n, dtype=int)
    charging = np.zeros(n, dtype=int)
    arrivals = np.zeros(n, dtype=int)
    departures = np.zeros(n, dtype=int)

    qc_rows = []
    balance_rows = []

    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            s = json.loads(line)
            sid = str(s.get("sessionID") or s.get("_id") or "unknown")
            conn = _parse_acn_timestamp(s.get("connectionTime"))
            disc = _parse_acn_timestamp(s.get("disconnectTime"))
            done = _parse_acn_timestamp(s.get("doneChargingTime"))
            delivered = pd.to_numeric(s.get("kWhDelivered"), errors="coerce")
            delivered = float(delivered) if pd.notna(delivered) else np.nan

            reasons = []
            if pd.isna(conn) or pd.isna(disc):
                reasons.append("invalid_connection_or_disconnect_time")
                qc_rows.append({"session_id": sid, "quality_flag": "reject", "reasons": ";".join(reasons)})
                continue
            if disc <= conn:
                reasons.append("disconnect_not_after_connection")
                qc_rows.append({"session_id": sid, "quality_flag": "reject", "reasons": ";".join(reasons)})
                continue
            if np.isnan(delivered) or delivered < 0:
                reasons.append("invalid_delivered_energy")
                qc_rows.append({"session_id": sid, "quality_flag": "reject", "reasons": ";".join(reasons)})
                continue

            active_end = _active_end(conn, disc, done)
            duration_h = (active_end - conn).total_seconds() / 3600.0
            duration_bucket = _duration_bucket_label(duration_h)

            # Connected-state accounting: overlap of [connection, disconnect) with each 15-min interval.
            for i in _bin_positions(conn, disc, grid_start, interval_minutes, n):
                b0, b1 = idx[i], idx[i] + step
                if _overlap_hours(conn, disc, b0, b1) > 0:
                    connected[i] += 1

            if start <= conn < end:
                arrivals[int((conn - start).total_seconds() // (interval_minutes * 60))] += 1
            if start <= disc < end:
                j = int((disc - start).total_seconds() // (interval_minutes * 60))
                if 0 <= j < n:
                    departures[j] += 1

            t_raw, c_raw = _timeseries_parts(s.get("chargingCurrent"))
            t = _parse_acn_timestamp_list(t_raw)
            c = pd.to_numeric(pd.Series(c_raw), errors="coerce").to_numpy(dtype=float) if c_raw else np.array([])
            if len(t) != len(c):
                reasons.append("charging_current_length_mismatch")
                m = min(len(t), len(c))
                t, c = t[:m], c[:m]
            if len(c):
                if np.nanmin(c) < 0:
                    reasons.append("negative_charging_current_clipped")
                c = np.nan_to_num(c, nan=0.0, posinf=0.0, neginf=0.0)
                c = np.clip(c, 0.0, None)

            segments = []
            session_charging_bins = set()
            reconstruction_method = "template_shape"
            template_bucket = pd.NA
            if len(t) >= 1 and len(c) >= 1:
                segments = _session_segments(conn, active_end, t, c)
                reconstruction_method = "measured_current_shape" if segments else "template_shape"

            weights = np.array([(b-a).total_seconds()/3600.0 * cur for a,b,cur in segments], dtype=float)
            weight_sum = float(weights.sum()) if len(weights) else 0.0
            used_fallback = False

            if delivered > 0 and weight_sum > 0:
                segment_energies = delivered * weights / weight_sum
                for (seg_start, seg_end, cur), e_seg in zip(segments, segment_energies):
                    dur_h = (seg_end - seg_start).total_seconds() / 3600.0
                    if dur_h <= 0:
                        continue
                    for i in _bin_positions(seg_start, seg_end, grid_start, interval_minutes, n):
                        b0, b1 = idx[i], idx[i] + step
                        oh = _overlap_hours(seg_start, seg_end, b0, b1)
                        if oh <= 0:
                            continue
                        energy[i] += e_seg * (oh / dur_h)
                        if cur > 1e-6:
                            session_charging_bins.add(i)
            elif delivered > 0:
                # Fallback: ACN delivered energy is measured, but current time series is unavailable.
                # Allocate the energy using a learned charging-shape template over the active interval.
                used_fallback = True
                reasons.append("energy_only_template_fallback")
                template_bucket, session_template_weights = _select_template_for_duration(
                    duration_h, bucket_templates, global_template
                )
                tpl_energy, tpl_bins = _apply_template_to_interval(
                    conn, active_end, delivered, session_template_weights, idx, grid_start, interval_minutes
                )
                if tpl_energy.sum() > 0:
                    energy += tpl_energy
                    session_charging_bins.update(tpl_bins)
                else:
                    reasons.append("energy_only_uniform_fallback")
                    total_h = (active_end - conn).total_seconds() / 3600.0
                    if total_h > 0:
                        for i in _bin_positions(conn, active_end, grid_start, interval_minutes, n):
                            b0, b1 = idx[i], idx[i] + step
                            oh = _overlap_hours(conn, active_end, b0, b1)
                            if oh > 0:
                                energy[i] += delivered * oh / total_h
                                session_charging_bins.add(i)
            elif delivered == 0:
                pass

            for i in session_charging_bins:
                charging[i] += 1

            full_session_inside = conn >= start and disc <= end
            reconstructed_inside = 0.0
            if full_session_inside:
                # Sum energy only in bins overlapped by the session. Since the session is wholly inside the grid,
                # this is the full reconstructed energy for this session up to floating-point precision.
                if delivered > 0 and weight_sum > 0:
                    reconstructed_inside = float(delivered)
                elif delivered > 0 and used_fallback:
                    reconstructed_inside = float(delivered)
                else:
                    reconstructed_inside = 0.0
            err_pct = (
                abs(reconstructed_inside - delivered) / delivered * 100.0
                if full_session_inside and delivered > 0
                else np.nan
            )
            balance_rows.append(
                {
                    "session_id": sid,
                    "reported_kwh": delivered,
                    "reconstructed_kwh": reconstructed_inside if full_session_inside else np.nan,
                    "absolute_error_kwh": abs(reconstructed_inside - delivered) if full_session_inside else np.nan,
                    "error_percent": err_pct,
                    "full_session_inside_study_window": full_session_inside,
                    "used_energy_only_fallback": used_fallback,
                    "duration_bucket": duration_bucket,
                    "template_bucket": template_bucket if used_fallback else duration_bucket,
                    "reconstruction_method": reconstruction_method if delivered > 0 else "no_energy",
                }
            )
            qc_rows.append(
                {
                    "session_id": sid,
                    "quality_flag": "review" if reasons else "pass",
                    "reasons": ";".join(sorted(set(reasons))),
                    "duration_bucket": duration_bucket,
                    "template_bucket": template_bucket if used_fallback else duration_bucket,
                    "reconstruction_method": reconstruction_method if delivered > 0 else "no_energy",
                }
            )

    power_kw = energy / (interval_minutes / 60.0)
    # Physical invariant: if no EV is connected, aggregated EV energy/power must be zero.
    invalid_mask = (connected == 0) & (power_kw > 1e-9)

    profile = pd.DataFrame(
        {
            "timestamp_utc": idx,
            "ev_power_kw": power_kw,
            "ev_energy_kwh": energy,
            "ev_connected_count": connected,
            "ev_charging_count": charging,
            "ev_arrivals": arrivals,
            "ev_departures": departures,
        }
    )
    profile["quality_flag"] = np.where(invalid_mask, "fail_connected_zero_power_positive", "pass")

    qc = pd.DataFrame(qc_rows)
    balance = pd.DataFrame(balance_rows)
    return profile, qc, balance
