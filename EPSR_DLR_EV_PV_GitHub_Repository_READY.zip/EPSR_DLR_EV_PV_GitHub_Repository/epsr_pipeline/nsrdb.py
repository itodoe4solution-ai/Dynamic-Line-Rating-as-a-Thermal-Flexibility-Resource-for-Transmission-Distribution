from __future__ import annotations

import csv
import io
from pathlib import Path

import pandas as pd
import requests

from .common import require_env, write_json


def download_nsrdb_year(
    year: int,
    latitude: float,
    longitude: float,
    endpoint: str,
    attributes: list[str],
    interval_minutes: int,
    out_csv: Path,
    leap_day: bool = True,
    utc: bool = True,
) -> Path:
    params = {
        "api_key": require_env("NREL_API_KEY"),
        "wkt": f"POINT({longitude} {latitude})",
        "attributes": ",".join(attributes),
        "names": str(year),
        "utc": str(bool(utc)).lower(),
        "leap_day": str(bool(leap_day)).lower(),
        "interval": int(interval_minutes),
        "full_name": require_env("NREL_FULL_NAME"),
        "email": require_env("NREL_EMAIL"),
        "affiliation": require_env("NREL_AFFILIATION"),
        "reason": "Academic power-systems research",
        "mailing_list": "false",
    }
    r = requests.get(endpoint, params=params, timeout=180)
    r.raise_for_status()
    text = r.text
    if text.lstrip().startswith("{"):
        raise RuntimeError(f"NSRDB returned JSON instead of CSV: {text[:1000]}")
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    out_csv.write_text(text, encoding="utf-8")

    lines = text.splitlines()
    if len(lines) >= 2:
        meta_keys = next(csv.reader([lines[0].lstrip("\ufeff")]))
        meta_vals = next(csv.reader([lines[1]]))
        metadata = {str(k): v for k, v in zip(meta_keys, meta_vals)}
        write_json(metadata, out_csv.with_suffix(".metadata.json"))
    return out_csv


def _normalize_name(name: str) -> str:
    return (
        str(name).strip().lower().replace(" ", "_").replace("-", "_")
        .replace("(", "").replace(")", "").replace("/", "_")
    )


def read_nsrdb_csv(path: Path) -> pd.DataFrame:
    # NSRDB direct CSV: row 1 metadata names, row 2 metadata values, row 3 data header.
    df = pd.read_csv(path, skiprows=2)
    df.columns = [_normalize_name(c) for c in df.columns]

    date_cols = {c.lower(): c for c in df.columns}
    required = ["year", "month", "day", "hour", "minute"]
    if not all(c in df.columns for c in required):
        raise ValueError(f"Unexpected NSRDB columns in {path}: {df.columns.tolist()[:20]}")
    df["timestamp_utc"] = pd.to_datetime(
        dict(
            year=df["year"], month=df["month"], day=df["day"],
            hour=df["hour"], minute=df["minute"]
        ),
        utc=True,
        errors="coerce",
    )

    aliases = {
        "temperature": "temperature_c",
        "air_temperature": "temperature_c",
        "wind_speed": "wind_speed_ms",
        "wind_direction": "wind_direction_deg",
        "ghi": "ghi_wm2",
        "dni": "dni_wm2",
        "dhi": "dhi_wm2",
        "surface_pressure": "surface_pressure_mbar",
        "pressure": "surface_pressure_mbar",
        "relative_humidity": "relative_humidity_pct",
        "solar_zenith_angle": "solar_zenith_angle_deg",
    }
    for src, dst in aliases.items():
        if src in df.columns and dst not in df.columns:
            df[dst] = pd.to_numeric(df[src], errors="coerce")

    if "surface_pressure_mbar" in df.columns:
        df["pressure_pa"] = pd.to_numeric(df["surface_pressure_mbar"], errors="coerce") * 100.0

    keep = [
        "timestamp_utc", "temperature_c", "wind_speed_ms", "wind_direction_deg",
        "ghi_wm2", "dni_wm2", "dhi_wm2", "pressure_pa",
        "relative_humidity_pct", "solar_zenith_angle_deg"
    ]
    keep = [c for c in keep if c in df.columns]
    return df[keep].copy()


def aggregate_to_15min(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy().set_index("timestamp_utc").sort_index()
    scalar_cols = [c for c in [
        "temperature_c", "wind_speed_ms", "ghi_wm2", "dni_wm2", "dhi_wm2",
        "pressure_pa", "relative_humidity_pct", "solar_zenith_angle_deg"
    ] if c in d.columns]
    out = d[scalar_cols].resample("15min").mean()

    if "wind_direction_deg" in d.columns:
        # Circular mean; ordinary arithmetic means are invalid near 0/360 degrees.
        import numpy as np
        rad = np.deg2rad(d["wind_direction_deg"])
        sin_m = pd.Series(np.sin(rad), index=d.index).resample("15min").mean()
        cos_m = pd.Series(np.cos(rad), index=d.index).resample("15min").mean()
        direction = (np.rad2deg(np.arctan2(sin_m, cos_m)) + 360.0) % 360.0
        out["wind_direction_deg"] = direction

    out = out.reset_index()
    return out
