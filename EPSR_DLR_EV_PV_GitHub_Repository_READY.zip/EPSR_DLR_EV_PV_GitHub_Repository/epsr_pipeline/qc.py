from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def timestamp_qc(df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp, minutes: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    ts = pd.to_datetime(df["timestamp_utc"], utc=True, errors="coerce")
    dup = df.loc[ts.duplicated(keep=False)].copy()
    expected = pd.date_range(start, end - pd.Timedelta(minutes=minutes), freq=f"{minutes}min", tz="UTC")
    observed = pd.DatetimeIndex(ts.dropna().unique()).sort_values()
    missing = expected.difference(observed)
    summary = pd.DataFrame([
        {
            "expected_rows": len(expected),
            "observed_rows": len(df),
            "duplicate_timestamp_rows": len(dup),
            "missing_timestamps": len(missing),
            "missing_fraction": len(missing) / len(expected) if len(expected) else np.nan,
            "first_timestamp": observed.min() if len(observed) else pd.NaT,
            "last_timestamp": observed.max() if len(observed) else pd.NaT,
        }
    ])
    missing_df = pd.DataFrame({"missing_timestamp_utc": missing})
    return summary, missing_df


def missing_values_report(
    df: pd.DataFrame,
    ignore_suffixes: tuple[str, ...] = ("_qc_flag",),
    ignore_columns: tuple[str, ...] = (),
) -> pd.DataFrame:
    cols = [
        c for c in df.columns
        if c not in ignore_columns and not any(str(c).endswith(s) for s in ignore_suffixes)
    ]
    return pd.DataFrame({
        "column": cols,
        "missing_count": [int(df[c].isna().sum()) for c in cols],
        "missing_fraction": [float(df[c].isna().mean()) for c in cols],
    }).sort_values(["missing_fraction", "column"], ascending=[False, True])


def physical_sanity(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    q = cfg["quality"]
    checks = []

    def add(name: str, mask: pd.Series, severity: str = "fail"):
        mask = mask.fillna(False)
        checks.append({"check": name, "violations": int(mask.sum()), "severity": severity, "status": "pass" if int(mask.sum()) == 0 else severity})

    if "ev_power_kw" in df:
        add("EV power < 0", df["ev_power_kw"] < -1e-9)
    if "ev_connected_count" in df and "ev_power_kw" in df:
        add("connected EV = 0 but EV power > 0", (df["ev_connected_count"] == 0) & (df["ev_power_kw"] > 1e-9))
    if "pv_ac_kw" in df:
        add("PV power < 0", df["pv_ac_kw"] < -1e-9)
        add("PV exceeds configured inverter capacity", df["pv_ac_kw"] > float(cfg["pv"]["inverter_pdc0_kw"]) + 1e-6)
    if "temperature_c" in df:
        add("temperature below configured bound", df["temperature_c"] < float(q["min_temperature_c"]))
        add("temperature above configured bound", df["temperature_c"] > float(q["max_temperature_c"]))
    if "wind_speed_ms" in df:
        add("wind speed < 0", df["wind_speed_ms"] < -1e-9)
        add("wind speed above configured bound", df["wind_speed_ms"] > float(q["max_wind_speed_ms"]), "review")
    if "wind_direction_deg" in df:
        add("wind direction outside [0,360)", (df["wind_direction_deg"] < 0) | (df["wind_direction_deg"] >= 360))
    if "ghi_wm2" in df:
        add("GHI < 0", df["ghi_wm2"] < -1e-9)
        add("GHI above configured bound", df["ghi_wm2"] > float(q["max_ghi_wm2"]), "review")
    if "dlr_ampacity_a" in df:
        add("DLR ampacity <= 0", df["dlr_ampacity_a"] <= 0)
    if "str_mva" in df:
        add("STR MVA <= 0", df["str_mva"] <= 0)
    return pd.DataFrame(checks)


def long_constant_runs(series: pd.Series, min_run: int = 16) -> int:
    s = series.copy()
    grp = (s.ne(s.shift()) | s.isna()).cumsum()
    sizes = s.groupby(grp).size()
    return int((sizes >= min_run).sum())


def weather_qc(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in ["temperature_c", "wind_speed_ms", "wind_direction_deg", "ghi_wm2", "dni_wm2", "dhi_wm2", "pressure_pa", "relative_humidity_pct"]:
        if c in df:
            rows.append({
                "variable": c,
                "n": int(df[c].notna().sum()),
                "missing": int(df[c].isna().sum()),
                "min": float(df[c].min()) if df[c].notna().any() else np.nan,
                "median": float(df[c].median()) if df[c].notna().any() else np.nan,
                "max": float(df[c].max()) if df[c].notna().any() else np.nan,
                "constant_runs_ge_4h": long_constant_runs(df[c], 16),
            })
    return pd.DataFrame(rows)


def dataset_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in df.columns:
        series = df[c]
        if pd.api.types.is_bool_dtype(series):
            series = series.astype(int)
        if pd.api.types.is_numeric_dtype(series):
            rows.append({
                "variable": c,
                "count": int(series.notna().sum()),
                "mean": float(series.mean()) if series.notna().any() else np.nan,
                "std": float(series.std()) if series.notna().any() else np.nan,
                "min": float(series.min()) if series.notna().any() else np.nan,
                "p05": float(series.quantile(.05)) if series.notna().any() else np.nan,
                "p50": float(series.quantile(.50)) if series.notna().any() else np.nan,
                "p95": float(series.quantile(.95)) if series.notna().any() else np.nan,
                "max": float(series.max()) if series.notna().any() else np.nan,
            })
    return pd.DataFrame(rows)
