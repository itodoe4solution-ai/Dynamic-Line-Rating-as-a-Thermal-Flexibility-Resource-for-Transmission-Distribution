from __future__ import annotations

import numpy as np
import pandas as pd


def chronological_split(df: pd.DataFrame, train_fraction: float, val_fraction: float):
    n = len(df)
    i1 = int(np.floor(n * train_fraction))
    i2 = int(np.floor(n * (train_fraction + val_fraction)))
    return df.iloc[:i1].copy(), df.iloc[i1:i2].copy(), df.iloc[i2:].copy()


def metrics(y: pd.Series, pred: pd.Series) -> dict:
    z = pd.DataFrame({"y": y, "p": pred}).dropna()
    if z.empty:
        return {"n": 0, "rmse": np.nan, "mae": np.nan, "nrmse": np.nan}
    err = z.p - z.y
    rmse = float(np.sqrt(np.mean(err**2)))
    mae = float(np.mean(np.abs(err)))
    denom = float(z.y.max() - z.y.min())
    nrmse = rmse / denom if denom > 0 else np.nan
    return {"n": len(z), "rmse": rmse, "mae": mae, "nrmse": nrmse}


def benchmark_series(df: pd.DataFrame, value_col: str, seasonal_lag_steps: int = 96) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = df[["timestamp_utc", value_col]].copy().sort_values("timestamp_utc")
    y = pd.to_numeric(d[value_col], errors="coerce")
    d["persistence"] = y.shift(1)
    d["seasonal_persistence"] = y.shift(seasonal_lag_steps)

    # Causal hour-of-week historical mean: expanding mean by local-like UTC slot.
    ts = pd.to_datetime(d.timestamp_utc, utc=True)
    slot = ts.dt.dayofweek * seasonal_lag_steps + ts.dt.hour * (seasonal_lag_steps // 24) + (ts.dt.minute // 15)
    hist = []
    sums, counts = {}, {}
    for k, val in zip(slot, y):
        hist.append(sums.get(int(k), 0.0) / counts[int(k)] if counts.get(int(k), 0) else np.nan)
        if pd.notna(val):
            sums[int(k)] = sums.get(int(k), 0.0) + float(val)
            counts[int(k)] = counts.get(int(k), 0) + 1
    d["historical_hour_of_week_mean"] = hist

    rows = []
    for col in ["persistence", "seasonal_persistence", "historical_hour_of_week_mean"]:
        rows.append({"target": value_col, "model": col, **metrics(y, d[col])})
    return d, pd.DataFrame(rows)


def conformal_interval_from_validation(
    validation_y: pd.Series,
    validation_pred: pd.Series,
    test_pred: pd.Series,
    nominal_coverage: float = 0.90,
) -> tuple[pd.Series, pd.Series, float]:
    residual = (validation_y - validation_pred).abs().dropna()
    if residual.empty:
        return pd.Series(np.nan, index=test_pred.index), pd.Series(np.nan, index=test_pred.index), np.nan
    # Finite-sample split-conformal quantile.
    n = len(residual)
    q_level = min(1.0, np.ceil((n + 1) * nominal_coverage) / n)
    q = float(residual.quantile(q_level, interpolation="higher"))
    return test_pred - q, test_pred + q, q


def interval_coverage(y: pd.Series, lower: pd.Series, upper: pd.Series) -> dict:
    z = pd.DataFrame({"y":y,"lo":lower,"hi":upper}).dropna()
    if z.empty:
        return {"n":0,"coverage":np.nan,"mean_width":np.nan}
    covered = (z.y >= z.lo) & (z.y <= z.hi)
    return {"n":len(z),"coverage":float(covered.mean()),"mean_width":float((z.hi-z.lo).mean())}
