"""EPSR publication-grade data preparation pipeline."""
__version__ = "0.1.0"
