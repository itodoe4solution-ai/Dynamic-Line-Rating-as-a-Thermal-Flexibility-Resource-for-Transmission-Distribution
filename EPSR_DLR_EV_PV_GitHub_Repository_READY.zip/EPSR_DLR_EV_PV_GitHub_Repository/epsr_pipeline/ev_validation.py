from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .ev import (
    _active_end,
    _duration_bucket_label,
    _parse_acn_timestamp,
    _parse_acn_timestamp_list,
    _session_segments,
    _timeseries_parts,
)


@dataclass
class MeasuredSessionShape:
    session_id: str
    connection_time: pd.Timestamp
    disconnect_time: pd.Timestamp
    active_end: pd.Timestamp
    duration_h: float
    duration_bucket: str
    delivered_kwh: float
    shape: np.ndarray
    energy_bins_raw: np.ndarray
    duration_bins: np.ndarray


def _shape_stats_from_segments(conn, active_end, segments, n_bins: int):
    energy_bins = np.zeros(n_bins, dtype=float)
    duration_bins = np.zeros(n_bins, dtype=float)
    total_h = (active_end - conn).total_seconds() / 3600.0
    if total_h <= 0:
        return energy_bins, duration_bins
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    for seg_start, seg_end, cur in segments:
        rel_start = max(0.0, min(1.0, (seg_start - conn).total_seconds() / 3600.0 / total_h))
        rel_end = max(0.0, min(1.0, (seg_end - conn).total_seconds() / 3600.0 / total_h))
        if rel_end <= rel_start:
            continue
        for j in range(n_bins):
            overlap = min(rel_end, edges[j + 1]) - max(rel_start, edges[j])
            if overlap <= 0:
                continue
            bin_hours = overlap * total_h
            duration_bins[j] += bin_hours
            energy_bins[j] += max(float(cur), 0.0) * bin_hours
    return energy_bins, duration_bins


def extract_measured_session_shapes(jsonl_path: Path, n_bins: int = 24) -> list[MeasuredSessionShape]:
    out: list[MeasuredSessionShape] = []
    with Path(jsonl_path).open('r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            s = json.loads(line)
            conn = _parse_acn_timestamp(s.get('connectionTime'))
            disc = _parse_acn_timestamp(s.get('disconnectTime'))
            done = _parse_acn_timestamp(s.get('doneChargingTime'))
            delivered = pd.to_numeric(s.get('kWhDelivered'), errors='coerce')
            if pd.isna(conn) or pd.isna(disc) or disc <= conn or pd.isna(delivered) or float(delivered) <= 0:
                continue
            active_end = _active_end(conn, disc, done)
            if active_end <= conn:
                continue
            t_raw, c_raw = _timeseries_parts(s.get('chargingCurrent'))
            t = _parse_acn_timestamp_list(t_raw)
            c = pd.to_numeric(pd.Series(c_raw), errors='coerce').to_numpy(dtype=float) if c_raw else np.array([])
            m = min(len(t), len(c))
            if m < 1:
                continue
            t, c = t[:m], c[:m]
            c = np.clip(np.nan_to_num(c, nan=0.0, posinf=0.0, neginf=0.0), 0.0, None)
            segments = _session_segments(conn, active_end, t, c)
            if not segments:
                continue
            energy_bins, duration_bins = _shape_stats_from_segments(conn, active_end, segments, n_bins)
            total = float(energy_bins.sum())
            if total <= 0:
                continue
            duration_h = (active_end - conn).total_seconds() / 3600.0
            out.append(MeasuredSessionShape(
                session_id=str(s.get('sessionID') or s.get('_id') or 'unknown'),
                connection_time=conn,
                disconnect_time=disc,
                active_end=active_end,
                duration_h=duration_h,
                duration_bucket=_duration_bucket_label(duration_h),
                delivered_kwh=float(delivered),
                shape=energy_bins / total,
                energy_bins_raw=energy_bins,
                duration_bins=duration_bins,
            ))
    return out


def _template_from_sessions(sessions: list[MeasuredSessionShape], n_bins: int) -> np.ndarray:
    if not sessions:
        return np.full(n_bins, 1.0 / n_bins)
    energy = np.sum([s.energy_bins_raw for s in sessions], axis=0)
    duration = np.sum([s.duration_bins for s in sessions], axis=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        avg_current = energy / duration
    avg_current = np.clip(np.nan_to_num(avg_current, nan=0.0, posinf=0.0, neginf=0.0), 0.0, None)
    if float(avg_current.sum()) <= 0:
        return np.full(n_bins, 1.0 / n_bins)
    return avg_current / avg_current.sum()


def _metrics(obs: np.ndarray, pred: np.ndarray, duration_h: float) -> dict[str, float]:
    err = pred - obs
    rmse = float(np.sqrt(np.mean(err ** 2)))
    mae = float(np.mean(np.abs(err)))
    mean_share = 1.0 / len(obs)
    nrmse_uniform_mean = rmse / mean_share
    peak_obs = int(np.argmax(obs)); peak_pred = int(np.argmax(pred))
    peak_bins = abs(peak_pred - peak_obs)
    peak_time_h = peak_bins / len(obs) * duration_h
    peak_share_error = abs(float(pred[peak_pred]) - float(obs[peak_obs]))
    cdf_obs = np.cumsum(obs); cdf_pred = np.cumsum(pred)
    wasserstein_normalized = float(np.mean(np.abs(cdf_pred - cdf_obs)))
    cum_mae = wasserstein_normalized
    corr = float(np.corrcoef(obs, pred)[0,1]) if np.std(obs) > 1e-12 and np.std(pred) > 1e-12 else np.nan
    return {
        'rmse_share': rmse,
        'mae_share': mae,
        'nrmse_vs_uniform_mean': nrmse_uniform_mean,
        'correlation': corr,
        'peak_bin_error': float(peak_bins),
        'peak_time_error_h': float(peak_time_h),
        'peak_share_error': float(peak_share_error),
        'cdf_mae': cum_mae,
    }


def repeated_stratified_kfold_template_validation(
    sessions: list[MeasuredSessionShape],
    n_splits: int = 5,
    repeats: int = 10,
    seed: int = 20260819,
) -> pd.DataFrame:
    if not sessions:
        return pd.DataFrame()
    n_bins = len(sessions[0].shape)
    rows = []
    buckets = sorted(set(s.duration_bucket for s in sessions))
    rng_master = np.random.default_rng(seed)
    for rep in range(repeats):
        fold_map: dict[str, int] = {}
        for bucket in buckets:
            sb = [s for s in sessions if s.duration_bucket == bucket]
            ids = np.arange(len(sb))
            rng = np.random.default_rng(int(rng_master.integers(0, 2**31-1)))
            rng.shuffle(ids)
            fold_ids = np.arange(len(sb)) % min(n_splits, len(sb))
            for pos, shuffled_idx in enumerate(ids):
                fold_map[sb[shuffled_idx].session_id] = int(fold_ids[pos])
        max_fold = max(fold_map.values()) if fold_map else -1
        for fold in range(max_fold + 1):
            test = [s for s in sessions if fold_map.get(s.session_id) == fold]
            train = [s for s in sessions if fold_map.get(s.session_id) != fold]
            global_tpl = _template_from_sessions(train, n_bins)
            bucket_tpl = {
                b: _template_from_sessions([s for s in train if s.duration_bucket == b], n_bins)
                for b in buckets
            }
            uniform_tpl = np.full(n_bins, 1.0/n_bins)
            for s in test:
                for model, pred in [
                    ('duration_bucket_template', bucket_tpl[s.duration_bucket]),
                    ('global_template', global_tpl),
                    ('uniform_profile', uniform_tpl),
                ]:
                    row = {
                        'repeat': rep,
                        'fold': fold,
                        'session_id': s.session_id,
                        'connection_time_utc': s.connection_time,
                        'duration_h': s.duration_h,
                        'duration_bucket': s.duration_bucket,
                        'reported_kwh': s.delivered_kwh,
                        'model': model,
                    }
                    row.update(_metrics(s.shape, pred, s.duration_h))
                    rows.append(row)
    return pd.DataFrame(rows)


def summarize_template_validation(detail: pd.DataFrame) -> pd.DataFrame:
    if detail.empty:
        return pd.DataFrame()
    metrics = ['rmse_share','mae_share','nrmse_vs_uniform_mean','correlation','peak_bin_error','peak_time_error_h','peak_share_error','cdf_mae']
    rows=[]
    for (model,bucket), sub in detail.groupby(['model','duration_bucket'], dropna=False):
        row={'model':model,'duration_bucket':bucket,'n_predictions':len(sub),'n_unique_sessions':sub.session_id.nunique()}
        for m in metrics:
            vals=pd.to_numeric(sub[m],errors='coerce')
            row[f'{m}_mean']=float(vals.mean())
            row[f'{m}_median']=float(vals.median())
            row[f'{m}_p90']=float(vals.quantile(0.90))
        rows.append(row)
    for model, sub in detail.groupby('model'):
        row={'model':model,'duration_bucket':'ALL','n_predictions':len(sub),'n_unique_sessions':sub.session_id.nunique()}
        for m in metrics:
            vals=pd.to_numeric(sub[m],errors='coerce')
            row[f'{m}_mean']=float(vals.mean())
            row[f'{m}_median']=float(vals.median())
            row[f'{m}_p90']=float(vals.quantile(0.90))
        rows.append(row)
    return pd.DataFrame(rows)
