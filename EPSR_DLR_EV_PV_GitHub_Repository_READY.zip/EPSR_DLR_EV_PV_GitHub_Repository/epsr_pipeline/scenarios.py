from __future__ import annotations

import numpy as np
import pandas as pd


def _q(s: pd.Series, p: float) -> float:
    return float(pd.to_numeric(s, errors="coerce").quantile(p))


def classify_regimes(master: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = master.copy()
    thresholds = []

    if "temperature_c" in d:
        vals = {f"p{int(p*100):02d}": _q(d["temperature_c"], p) for p in [.05,.10,.25,.50,.75,.90,.95,.99]}
        thresholds.append({"variable": "temperature_c", **vals})
        p05,p25,p75,p95,p99 = vals["p05"],vals["p25"],vals["p75"],vals["p95"],vals["p99"]
        d["temperature_regime"] = np.select(
            [d.temperature_c <= p05, d.temperature_c <= p25, d.temperature_c < p95, d.temperature_c < p99, d.temperature_c >= p99],
            ["very_cold", "cold", "normal", "extreme_hot", "severe_extreme_hot"],
            default="hot",
        )
        # Refine p75-p95 to hot rather than normal.
        d.loc[(d.temperature_c >= p75) & (d.temperature_c < p95), "temperature_regime"] = "hot"

    if "wind_speed_ms" in d:
        vals = {f"p{int(p*100):02d}": _q(d["wind_speed_ms"], p) for p in [.05,.10,.25,.50,.75,.90,.95,.99]}
        thresholds.append({"variable": "wind_speed_ms", **vals})
        d["wind_regime"] = np.select(
            [d.wind_speed_ms <= vals["p05"], d.wind_speed_ms <= vals["p10"], d.wind_speed_ms >= vals["p99"], d.wind_speed_ms >= vals["p90"]],
            ["very_low", "low", "extreme_high", "high"],
            default="normal",
        )

    if "pv_ac_kw" in d:
        vals = {f"p{int(p*100):02d}": _q(d["pv_ac_kw"], p) for p in [.10,.25,.50,.75,.90,.95,.99]}
        thresholds.append({"variable": "pv_ac_kw", **vals})
        d["solar_regime"] = np.select(
            [d.pv_ac_kw <= vals["p10"], d.pv_ac_kw >= vals["p99"], d.pv_ac_kw >= vals["p90"]],
            ["low", "extreme_high", "high"],
            default="normal",
        )
        d["pv_ramp_kw"] = d["pv_ac_kw"].diff()

    if "ev_power_kw" in d:
        vals = {f"p{int(p*100):02d}": _q(d["ev_power_kw"], p) for p in [.10,.25,.50,.75,.90,.95,.99]}
        thresholds.append({"variable": "ev_power_kw", **vals})
        d["ev_regime"] = np.select(
            [d.ev_power_kw <= vals["p10"], d.ev_power_kw >= vals["p99"], d.ev_power_kw >= vals["p90"]],
            ["low", "extreme", "high"],
            default="normal",
        )

    # Compound-event flags, based only on pre-simulation observed data.
    if all(c in d for c in ["temperature_c", "wind_speed_ms"]):
        t95 = _q(d["temperature_c"], .95)
        w10 = _q(d["wind_speed_ms"], .10)
        d["extreme_thermal_stress"] = (d.temperature_c >= t95) & (d.wind_speed_ms <= w10)
        if "ghi_wm2" in d:
            g75 = _q(d["ghi_wm2"], .75)
            d["critical_weather_flag"] = d["extreme_thermal_stress"] & (d.ghi_wm2 >= g75)
        else:
            d["critical_weather_flag"] = d["extreme_thermal_stress"]

    if "ev_power_kw" in d and "pv_ac_kw" in d:
        e90, e25 = _q(d.ev_power_kw,.90), _q(d.ev_power_kw,.25)
        p10, p90 = _q(d.pv_ac_kw,.10), _q(d.pv_ac_kw,.90)
        d["grid_demand_stress"] = (d.ev_power_kw >= e90) & (d.pv_ac_kw <= p10)
        d["reverse_flow_stress"] = (d.pv_ac_kw >= p90) & (d.ev_power_kw <= e25)

    return d, pd.DataFrame(thresholds)


def correlation_audit(master: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in ["ev_power_kw", "pv_ac_kw", "temperature_c", "wind_speed_ms", "ghi_wm2", "dlr_mva", "system_load_mw"] if c in master]
    if len(cols) < 2:
        return pd.DataFrame()
    return master[cols].corr(method="spearman")


def select_representative_periods(
    master: pd.DataFrame,
    local_tz: str,
    days: int = 7,
    study_start_utc: pd.Timestamp | None = None,
    study_end_utc: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Choose transparent representative windows using data statistics only.

    Selection does not use MATPOWER/OpenDSS/SMPC outcomes, avoiding post-hoc cherry-picking.
    """
    d = master.copy()
    if study_start_utc is not None:
        study_start_utc = pd.Timestamp(study_start_utc)
        if study_start_utc.tzinfo is None:
            study_start_utc = study_start_utc.tz_localize("UTC")
        else:
            study_start_utc = study_start_utc.tz_convert("UTC")
    if study_end_utc is not None:
        study_end_utc = pd.Timestamp(study_end_utc)
        if study_end_utc.tzinfo is None:
            study_end_utc = study_end_utc.tz_localize("UTC")
        else:
            study_end_utc = study_end_utc.tz_convert("UTC")
    ts = pd.to_datetime(d["timestamp_utc"], utc=True)
    d["date_local"] = ts.dt.tz_convert(local_tz).dt.floor("D")
    numeric = [c for c in ["temperature_c", "wind_speed_ms", "ghi_wm2", "pv_ac_kw", "ev_power_kw", "dlr_mva", "system_load_mw"] if c in d]
    daily = d.groupby(["date_local", "season"], observed=True)[numeric].agg(["mean", "max", "min"])
    daily.columns = [f"{a}_{b}" for a,b in daily.columns]
    daily = daily.reset_index()
    if daily.empty:
        return pd.DataFrame()

    available_start = pd.Timestamp(d["date_local"].min())
    available_end_exclusive = pd.Timestamp(d["date_local"].max()) + pd.Timedelta(days=1)
    picks = []

    def bounded_window(center):
        center = pd.Timestamp(center)
        s = center - pd.Timedelta(days=3)
        e = s + pd.Timedelta(days=days)
        if s < available_start:
            s = available_start
            e = min(available_end_exclusive, s + pd.Timedelta(days=days))
        if e > available_end_exclusive:
            e = available_end_exclusive
            s = max(available_start, e - pd.Timedelta(days=days))
        return s, e

    def window_is_within_study(start_local: pd.Timestamp, end_local: pd.Timestamp) -> bool:
        start_utc = start_local.tz_convert("UTC")
        end_utc = end_local.tz_convert("UTC")
        if study_start_utc is not None and start_utc < study_start_utc:
            return False
        if study_end_utc is not None and end_utc > study_end_utc:
            return False
        return True

    def valid_candidates(subset: pd.DataFrame) -> pd.DataFrame:
        if subset.empty:
            return subset
        rows = []
        for _, row in subset.iterrows():
            start_local, end_local = bounded_window(row["date_local"])
            if window_is_within_study(start_local, end_local):
                rows.append({
                    **row.to_dict(),
                    "window_start_local": start_local,
                    "window_end_local": end_local,
                    "window_start_utc": start_local.tz_convert("UTC"),
                    "window_end_utc": end_local.tz_convert("UTC"),
                })
        return pd.DataFrame(rows)

    def add_pick(label: str, subset: pd.DataFrame, score_col: str | None = None, mode: str = "max"):
        if subset.empty:
            return
        candidates = valid_candidates(subset)
        if candidates.empty:
            return
        if score_col and score_col in candidates:
            row = candidates.loc[candidates[score_col].idxmax() if mode == "max" else candidates[score_col].idxmin()]
        else:
            row = candidates.iloc[len(candidates)//2]
        picks.append({
            "scenario": label,
            "start_local": row["window_start_local"],
            "end_local_exclusive": row["window_end_local"],
            "start_utc": row["window_start_utc"],
            "end_utc_exclusive": row["window_end_utc"],
            "selection_basis": score_col or "seasonal median date",
        })

    for season in ["winter", "spring", "summer", "autumn"]:
        g = daily[daily.season == season].sort_values("date_local")
        add_pick(f"normal_{season}", g)

    if "temperature_c_max" in daily:
        add_pick("extreme_heat", daily, "temperature_c_max", "max")
    if "wind_speed_ms_mean" in daily:
        add_pick("low_wind", daily, "wind_speed_ms_mean", "min")
        add_pick("high_wind", daily, "wind_speed_ms_mean", "max")
    if "ev_power_kw_max" in daily:
        add_pick("extreme_ev", daily, "ev_power_kw_max", "max")
    if "pv_ac_kw_max" in daily:
        add_pick("extreme_pv", daily, "pv_ac_kw_max", "max")
    if "dlr_mva_min" in daily:
        add_pick("minimum_dlr", daily, "dlr_mva_min", "min")

    # Compound extreme days are selected directly from precomputed flags if present.
    for label, col in [("extreme_heat_low_wind_solar", "critical_weather_flag"), ("grid_demand_stress", "grid_demand_stress"), ("reverse_flow_stress", "reverse_flow_stress")]:
        if col in d and d[col].fillna(False).any():
            counts = d.groupby("date_local")[col].sum().reset_index(name="count")
            candidates = valid_candidates(counts)
            if candidates.empty:
                continue
            row = candidates.loc[candidates["count"].idxmax()]
            picks.append({
                "scenario": label,
                "start_local": row["window_start_local"],
                "end_local_exclusive": row["window_end_local"],
                "start_utc": row["window_start_utc"],
                "end_utc_exclusive": row["window_end_utc"],
                "selection_basis": f"maximum daily count of {col}",
            })

    out = pd.DataFrame(picks).drop_duplicates("scenario")
    return out
