from __future__ import annotations

import numpy as np
import pandas as pd


def build_pv_profile(weather_15: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    try:
        import pvlib
        from pvlib.temperature import TEMPERATURE_MODEL_PARAMETERS
    except ImportError as exc:
        raise RuntimeError("pvlib is not installed. Run pip install -r requirements.txt") from exc

    loc = cfg["location"]
    p = cfg["pv"]
    d = weather_15.copy().sort_values("timestamp_utc")
    idx = pd.DatetimeIndex(pd.to_datetime(d["timestamp_utc"], utc=True))

    required = ["ghi_wm2", "dni_wm2", "dhi_wm2", "temperature_c", "wind_speed_ms"]
    missing = [c for c in required if c not in d.columns]
    if missing:
        raise ValueError(f"PV model is missing required weather columns: {missing}")

    solpos = pvlib.solarposition.get_solarposition(
        idx,
        latitude=float(loc["latitude"]),
        longitude=float(loc["longitude"]),
        altitude=float(loc.get("elevation_m", 0.0)),
    )
    poa = pvlib.irradiance.get_total_irradiance(
        surface_tilt=float(p["surface_tilt_deg"]),
        surface_azimuth=float(p["surface_azimuth_deg"]),
        solar_zenith=solpos["apparent_zenith"],
        solar_azimuth=solpos["azimuth"],
        dni=pd.Series(d["dni_wm2"].to_numpy(), index=idx),
        ghi=pd.Series(d["ghi_wm2"].to_numpy(), index=idx),
        dhi=pd.Series(d["dhi_wm2"].to_numpy(), index=idx),
    )

    temp_model_name = p.get("temperature_model", "open_rack_glass_polymer")
    tparams = TEMPERATURE_MODEL_PARAMETERS["sapm"][temp_model_name]
    cell_temp = pvlib.temperature.sapm_cell(
        poa["poa_global"],
        pd.Series(d["temperature_c"].to_numpy(), index=idx),
        pd.Series(d["wind_speed_ms"].to_numpy(), index=idx),
        **tparams,
    )
    dc_kw = pvlib.pvsystem.pvwatts_dc(
        effective_irradiance=poa["poa_global"],
        temp_cell=cell_temp,
        pdc0=float(p["dc_capacity_kw"]),
        gamma_pdc=float(p["gamma_pdc_per_c"]),
    )
    ac_kw = pvlib.inverter.pvwatts(
        pdc=dc_kw,
        pdc0=float(p["inverter_pdc0_kw"]),
    )
    loss_fraction = float(p.get("system_losses_fraction", 0.0))
    ac_kw = ac_kw * (1.0 - loss_fraction)
    ac_kw = ac_kw.clip(lower=0.0, upper=float(p["inverter_pdc0_kw"]))
    dc_kw = dc_kw.clip(lower=0.0)

    # Nighttime numerical noise should be exactly zero.
    night = d["ghi_wm2"].to_numpy() <= 1.0
    ac_arr = np.asarray(ac_kw, dtype=float)
    dc_arr = np.asarray(dc_kw, dtype=float)
    ac_arr[night] = 0.0
    dc_arr[night] = 0.0

    out = pd.DataFrame(
        {
            "timestamp_utc": idx,
            "poa_global_wm2": np.asarray(poa["poa_global"], dtype=float),
            "pv_cell_temperature_c": np.asarray(cell_temp, dtype=float),
            "pv_dc_kw": dc_arr,
            "pv_ac_kw": ac_arr,
            "pv_available_kw": ac_arr,
            "pv_curtailment_possible_kw": ac_arr,
        }
    )
    out["quality_flag"] = np.where(
        (out["pv_ac_kw"] < -1e-9) | (out["pv_ac_kw"] > float(p["inverter_pdc0_kw"]) + 1e-6),
        "fail",
        "pass",
    )
    return out
