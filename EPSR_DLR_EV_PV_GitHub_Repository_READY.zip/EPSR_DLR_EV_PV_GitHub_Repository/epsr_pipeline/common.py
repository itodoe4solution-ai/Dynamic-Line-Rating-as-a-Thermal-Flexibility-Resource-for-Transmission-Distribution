from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any

import pandas as pd
import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    path = Path(path or ROOT / "config.yaml")
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_secrets() -> None:
    load_dotenv(ROOT / ".env")


def require_env(name: str) -> str:
    load_secrets()
    value = os.getenv(name)
    if not value or value.lower().startswith("replace_"):
        raise RuntimeError(
            f"Missing {name}. Copy .env.example to .env and fill in the required key/value."
        )
    return value


def ensure_directories() -> None:
    dirs = [
        "00_documentation",
        "01_legacy_dataset",
        "01_raw/acn_ev",
        "01_raw/nsrdb",
        "01_raw/noaa",
        "01_raw/eia930",
        "01_raw/caiso",
        "02_cleaned",
        "03_processed",
        "04_master",
        "05_quality_control",
        "06_scenarios",
        "07_forecasts",
        "08_dlr",
        "09_simulation_inputs",
        "10_reproducibility",
    ]
    for d in dirs:
        (ROOT / d).mkdir(parents=True, exist_ok=True)


def require_study_period(cfg: dict[str, Any]) -> tuple[pd.Timestamp, pd.Timestamp]:
    start = cfg["study"].get("start_utc")
    end = cfg["study"].get("end_utc")
    if not start or not end:
        raise RuntimeError(
            "Study period is not set. Run scripts/02_acn_inventory.py, review "
            "05_quality_control/acn_monthly_coverage.csv, then set study.start_utc "
            "and study.end_utc in config.yaml."
        )
    s = pd.Timestamp(start)
    e = pd.Timestamp(end)
    if s.tzinfo is None:
        s = s.tz_localize("UTC")
    else:
        s = s.tz_convert("UTC")
    if e.tzinfo is None:
        e = e.tz_localize("UTC")
    else:
        e = e.tz_convert("UTC")
    if e <= s:
        raise ValueError("study.end_utc must be later than study.start_utc")
    return s, e


def to_utc(ts: pd.Series | pd.DatetimeIndex) -> pd.Series | pd.DatetimeIndex:
    return pd.to_datetime(ts, utc=True, errors="coerce")


def expected_index(start: pd.Timestamp, end: pd.Timestamp, minutes: int) -> pd.DatetimeIndex:
    # end is exclusive to make joins and energy accounting unambiguous.
    return pd.date_range(start, end - pd.Timedelta(minutes=minutes), freq=f"{minutes}min", tz="UTC")


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def write_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=str)


def read_json(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)
