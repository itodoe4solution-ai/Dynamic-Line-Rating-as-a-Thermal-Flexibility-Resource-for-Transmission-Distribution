from __future__ import annotations

import numpy as np
import pandas as pd

from .common import expected_index
from .dlr import season_from_month


def build_master(
    start: pd.Timestamp,
    end: pd.Timestamp,
    interval_minutes: int,
    local_tz: str,
    ev: pd.DataFrame,
    weather: pd.DataFrame,
    pv: pd.DataFrame,
    eia: pd.DataFrame,
    dlr: pd.DataFrame,
    str_info: dict,
    seasonal: pd.DataFrame,
) -> pd.DataFrame:
    idx = expected_index(start, end, interval_minutes)
    master = pd.DataFrame({"timestamp_utc": idx})
    for frame in [ev, weather, pv, eia, dlr]:
        if frame is None or frame.empty:
            continue
        f = frame.copy()
        f["timestamp_utc"] = pd.to_datetime(f["timestamp_utc"], utc=True)
        f = f.drop_duplicates("timestamp_utc", keep="last")
        master = master.merge(f, on="timestamp_utc", how="left", suffixes=("", "_dup"))
        dup_cols = [c for c in master.columns if c.endswith("_dup")]
        if dup_cols:
            master = master.drop(columns=dup_cols)

    master["timestamp_local"] = master["timestamp_utc"].dt.tz_convert(local_tz)
    master["year"] = master["timestamp_local"].dt.year
    master["month"] = master["timestamp_local"].dt.month
    master["season"] = season_from_month(master["month"])
    master["weekday"] = master["timestamp_local"].dt.day_name()
    master["hour"] = master["timestamp_local"].dt.hour + master["timestamp_local"].dt.minute / 60.0
    master["is_weekend"] = master["timestamp_local"].dt.weekday >= 5

    master["str_ampacity_a"] = float(str_info["str_ampacity_a"])
    master["str_mva"] = float(str_info["str_mva"])
    if seasonal is not None and not seasonal.empty:
        master = master.merge(
            seasonal[["season", "seasonal_ampacity_a", "seasonal_rating_mva"]],
            on="season",
            how="left",
        )

    # Preserve a single row-level QC field without hiding detailed source QC reports.
    critical = [c for c in [
        "ev_power_kw", "temperature_c", "wind_speed_ms", "ghi_wm2",
        "pv_ac_kw", "dlr_mva"
    ] if c in master.columns]
    if critical:
        master["quality_flag"] = np.where(master[critical].isna().any(axis=1), "review_missing_critical", "pass")
    else:
        master["quality_flag"] = "review_missing_sources"
    return master
