from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import requests

from .common import require_env

EIA930_REGION_URL = "https://api.eia.gov/v2/electricity/rto/region-data/data/"


def _flag_obvious_demand_anomalies(wide: pd.DataFrame) -> pd.Series:
    if "system_load_mw" not in wide:
        return pd.Series(False, index=wide.index)
    mask = wide["system_load_mw"].notna() & (wide["system_load_mw"] < 1000.0)
    if "load_forecast_mw" in wide:
        mask &= wide["load_forecast_mw"].notna() & (wide["load_forecast_mw"] > 10000.0)
    if "net_generation_mw" in wide:
        mask &= wide["net_generation_mw"].notna()
    return mask


def download_eia930_region(
    balancing_authority: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    out_csv: Path,
    page_size: int = 5000,
) -> pd.DataFrame:
    """Download hourly EIA-930 region data for a balancing authority.

    The request intentionally does not filter by type so demand, forecast,
    net generation and interchange can be retained together when available.
    """
    key = require_env("EIA_API_KEY")
    offset = 0
    all_rows: list[dict] = []
    total = None

    while True:
        params = {
            "api_key": key,
            "frequency": "hourly",
            "data[0]": "value",
            "facets[respondent][]": balancing_authority,
            "start": start.strftime("%Y-%m-%dT%H"),
            "end": end.strftime("%Y-%m-%dT%H"),
            "sort[0][column]": "period",
            "sort[0][direction]": "asc",
            "offset": offset,
            "length": page_size,
        }
        r = requests.get(EIA930_REGION_URL, params=params, timeout=120)
        r.raise_for_status()
        payload = r.json()
        response = payload.get("response", {})
        rows = response.get("data", [])
        if total is None:
            try:
                total = int(response.get("total"))
            except Exception:
                total = None
        if not rows:
            break
        all_rows.extend(rows)
        offset += len(rows)
        if total is not None and offset >= total:
            break
        if len(rows) < page_size:
            break

    df = pd.DataFrame(all_rows)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    return df


def process_eia930_region(raw: pd.DataFrame) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame(columns=["timestamp_utc"])
    df = raw.copy()
    df["timestamp_utc"] = pd.to_datetime(df["period"], utc=True, errors="coerce")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")

    # Prefer readable type-name, fall back to the compact type code.
    label_col = "type-name" if "type-name" in df.columns else "type"
    if label_col not in df.columns:
        raise ValueError(f"Unexpected EIA-930 response columns: {df.columns.tolist()}")
    df["metric"] = df[label_col].astype(str).str.strip().str.lower()

    def canonical_metric(s: str) -> str:
        if "demand forecast" in s or "forecast" in s:
            return "load_forecast_mw"
        if s == "d" or "demand" in s:
            return "system_load_mw"
        if s == "ng" or "net generation" in s:
            return "net_generation_mw"
        if s == "ti" or "interchange" in s:
            return "net_interchange_mw"
        return "eia_" + s.replace(" ", "_").replace("/", "_")

    df["canonical"] = df["metric"].map(canonical_metric)
    wide = (
        df.dropna(subset=["timestamp_utc"])
        .pivot_table(index="timestamp_utc", columns="canonical", values="value", aggfunc="mean")
        .sort_index()
        .reset_index()
    )
    wide.columns.name = None
    if not wide.empty:
        if "system_load_mw" in wide:
            wide["system_load_mw_raw"] = wide["system_load_mw"]
            wide["system_load_mw_qc_flag"] = "pass"
            anomaly_mask = _flag_obvious_demand_anomalies(wide)
            wide.loc[anomaly_mask, "system_load_mw_qc_flag"] = "obvious_outlier"
            wide.loc[anomaly_mask, "system_load_mw"] = np.nan
        wide = wide.set_index("timestamp_utc").reindex(
            pd.date_range(wide["timestamp_utc"].min(), wide["timestamp_utc"].max(), freq="h", tz="UTC")
        )
        wide.index.name = "timestamp_utc"
        for col in wide.columns:
            if col.endswith("_raw") or col.endswith("_qc_flag"):
                continue
            if col == "system_load_mw":
                wide[col] = wide[col].interpolate(method="time").ffill().bfill()
            else:
                wide[col] = wide[col].ffill().bfill()
        if "system_load_mw_qc_flag" in wide.columns:
            flag = wide["system_load_mw_qc_flag"].astype("object")
            flag = flag.where(flag.notna(), other="source_gap")
            if "system_load_mw_raw" in wide.columns:
                flag = flag.where(wide["system_load_mw_raw"].notna(), other="source_gap")
            wide["system_load_mw_qc_flag"] = flag.fillna("pass")
        wide = wide.reset_index()
    return wide


def resample_eia930_to_15min(
    df: pd.DataFrame,
    method: str = "ffill",
    end: pd.Timestamp | None = None,
) -> pd.DataFrame:
    d = df.copy().set_index("timestamp_utc").sort_index()
    if method == "linear":
        out = d.resample("15min").interpolate("time")
    else:
        out = d.resample("15min").ffill()
    if end is not None:
        end = pd.Timestamp(end)
        if end.tzinfo is None:
            end = end.tz_localize("UTC")
        else:
            end = end.tz_convert("UTC")
        out = out.loc[out.index < end]
    return out.reset_index()
