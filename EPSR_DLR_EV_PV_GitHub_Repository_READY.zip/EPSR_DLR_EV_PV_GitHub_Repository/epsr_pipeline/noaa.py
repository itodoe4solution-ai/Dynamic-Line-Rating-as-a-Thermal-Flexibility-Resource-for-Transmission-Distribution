from __future__ import annotations

import gzip
import io
from pathlib import Path

import numpy as np
import pandas as pd
import requests

from .common import haversine_km

ISD_HISTORY_URL = "https://www.ncei.noaa.gov/pub/data/noaa/isd-history.csv"
ISD_LITE_BASE = "https://www.ncei.noaa.gov/pub/data/noaa/isd-lite"


def download_station_history(path: Path) -> pd.DataFrame:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        r = requests.get(ISD_HISTORY_URL, timeout=120)
        r.raise_for_status()
        path.write_bytes(r.content)
    df = pd.read_csv(path, dtype={"USAF": str, "WBAN": str})
    return df


def nearest_stations_with_coverage(
    history: pd.DataFrame,
    latitude: float,
    longitude: float,
    start: pd.Timestamp,
    end: pd.Timestamp,
    radius_km: float = 100.0,
) -> pd.DataFrame:
    df = history.copy()
    # Preserve zero padding in station identifiers.
    df["USAF"] = df["USAF"].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(6)
    df["WBAN"] = df["WBAN"].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5)
    df["LAT"] = pd.to_numeric(df["LAT"], errors="coerce")
    df["LON"] = pd.to_numeric(df["LON"], errors="coerce")
    df["BEGIN_DT"] = pd.to_datetime(df["BEGIN"].astype(str).str.replace(r"\.0$", "", regex=True), format="%Y%m%d", errors="coerce", utc=True)
    df["END_DT"] = pd.to_datetime(df["END"].astype(str).str.replace(r"\.0$", "", regex=True), format="%Y%m%d", errors="coerce", utc=True)
    df = df.dropna(subset=["LAT", "LON", "BEGIN_DT", "END_DT"])
    # end is exclusive in our study but station history is day-based.
    df = df[(df["BEGIN_DT"] <= start) & (df["END_DT"] >= (end - pd.Timedelta(days=1)).floor("D"))].copy()
    df["distance_km"] = [haversine_km(latitude, longitude, la, lo) for la, lo in zip(df["LAT"], df["LON"])]
    df = df[df["distance_km"] <= radius_km].sort_values("distance_km")
    return df


def download_isd_lite_station_year(usaf: str, wban: str, year: int, out_path: Path) -> Path:
    url = f"{ISD_LITE_BASE}/{year}/{usaf}-{wban}-{year}.gz"
    r = requests.get(url, timeout=120)
    if r.status_code == 404:
        raise FileNotFoundError(url)
    r.raise_for_status()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(r.content)
    return out_path


def read_isd_lite_gz(path: Path) -> pd.DataFrame:
    names = [
        "year", "month", "day", "hour", "temperature_tenths_c",
        "dewpoint_tenths_c", "slp_tenths_hpa", "wind_direction_deg",
        "wind_speed_tenths_ms", "sky_cover", "precip_1h_tenths_mm",
        "precip_6h_tenths_mm",
    ]
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
        df = pd.read_csv(f, sep=r"\s+", header=None, names=names, engine="python")
    for c in names:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.replace(-9999, np.nan)
    df["timestamp_utc"] = pd.to_datetime(
        dict(year=df.year, month=df.month, day=df.day, hour=df.hour), utc=True, errors="coerce"
    )
    df["noaa_temperature_c"] = df["temperature_tenths_c"] / 10.0
    df["noaa_dewpoint_c"] = df["dewpoint_tenths_c"] / 10.0
    df["noaa_sea_level_pressure_pa"] = df["slp_tenths_hpa"] / 10.0 * 100.0
    df["noaa_wind_speed_ms"] = df["wind_speed_tenths_ms"] / 10.0
    df["noaa_wind_direction_deg"] = df["wind_direction_deg"]
    return df[
        [
            "timestamp_utc", "noaa_temperature_c", "noaa_dewpoint_c",
            "noaa_sea_level_pressure_pa", "noaa_wind_speed_ms",
            "noaa_wind_direction_deg", "sky_cover"
        ]
    ].dropna(subset=["timestamp_utc"])


def validate_against_nsrdb(nsrdb_15: pd.DataFrame, noaa_hourly: pd.DataFrame) -> pd.DataFrame:
    # Compare on exact hourly boundaries by aggregating the 15-minute NSRDB series
    # to hourly values first. This avoids artificial error from nearest-neighbor
    # matching against sub-hourly points.
    a = nsrdb_15.copy().sort_values("timestamp_utc").set_index("timestamp_utc")
    hourly = pd.DataFrame(index=a.resample("h").mean().index)
    for col in ["temperature_c", "wind_speed_ms", "ghi_wm2", "dni_wm2", "dhi_wm2", "pressure_pa", "relative_humidity_pct", "solar_zenith_angle_deg"]:
        if col in a.columns:
            hourly[col] = a[col].resample("h").mean()
    if "wind_direction_deg" in a.columns:
        rad = np.deg2rad(a["wind_direction_deg"])
        sin_m = pd.Series(np.sin(rad), index=a.index).resample("h").mean()
        cos_m = pd.Series(np.cos(rad), index=a.index).resample("h").mean()
        hourly["wind_direction_deg"] = (np.rad2deg(np.arctan2(sin_m, cos_m)) + 360.0) % 360.0
    hourly = hourly.reset_index()

    b = noaa_hourly.copy().sort_values("timestamp_utc")
    merged = pd.merge(b, hourly, on="timestamp_utc", how="inner")
    rows = []

    def add_metric(variable: str, model_col: str, obs_col: str):
        z = merged[[model_col, obs_col]].dropna()
        if len(z) == 0:
            return
        err = z[model_col] - z[obs_col]
        rmse = float(np.sqrt(np.mean(err**2)))
        mae = float(np.mean(np.abs(err)))
        bias = float(np.mean(err))
        r2 = float(np.corrcoef(z[model_col], z[obs_col])[0, 1] ** 2) if len(z) > 2 and z[model_col].std() > 0 and z[obs_col].std() > 0 else np.nan
        rows.append({"variable": variable, "n": len(z), "rmse": rmse, "mae": mae, "bias": bias, "r2": r2})

    if "temperature_c" in merged and "noaa_temperature_c" in merged:
        add_metric("temperature_c", "temperature_c", "noaa_temperature_c")
    if "wind_speed_ms" in merged and "noaa_wind_speed_ms" in merged:
        add_metric("wind_speed_ms", "wind_speed_ms", "noaa_wind_speed_ms")

    # Circular direction error: shortest signed angular distance.
    if "wind_direction_deg" in merged and "noaa_wind_direction_deg" in merged:
        z = merged[["wind_direction_deg", "noaa_wind_direction_deg"]].dropna()
        if len(z):
            d = ((z["wind_direction_deg"] - z["noaa_wind_direction_deg"] + 180.0) % 360.0) - 180.0
            rows.append(
                {
                    "variable": "wind_direction_deg_circular",
                    "n": len(z),
                    "rmse": float(np.sqrt(np.mean(d**2))),
                    "mae": float(np.mean(np.abs(d))),
                    "bias": float(np.mean(d)),
                    "r2": np.nan,
                }
            )
    return pd.DataFrame(rows)
