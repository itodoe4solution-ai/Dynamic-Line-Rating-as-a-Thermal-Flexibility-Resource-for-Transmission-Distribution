from __future__ import annotations

import math

import numpy as np
import pandas as pd

STEFAN_BOLTZMANN = 5.67e-8
C2K = 273.15


def _wind_axis_angle_deg(wind_from_deg: np.ndarray, conductor_axis_deg: float) -> np.ndarray:
    # Conductor is an undirected axis, so 0 and 180 degrees are equivalent.
    delta = np.mod(np.abs(wind_from_deg - conductor_axis_deg), 180.0)
    return np.minimum(delta, 180.0 - delta)


def _wind_factor(phi_deg: np.ndarray) -> np.ndarray:
    phi180 = np.mod(np.abs(phi_deg), 180.0)
    phi90 = 90.0 - np.abs(phi180 - 90.0)
    p = np.deg2rad(phi90)
    return 1.194 - np.cos(p) + 0.194 * np.cos(2 * p) + 0.368 * np.sin(2 * p)


def _saturation_vapor_pressure_pa(temp_k: np.ndarray) -> np.ndarray:
    t = temp_k - C2K
    return 610.78 * np.exp((17.27 * t) / (t + 237.3))


def _air_density_ideal(pressure_pa: np.ndarray, temp_k: np.ndarray, rh_pct: np.ndarray) -> np.ndarray:
    p_wv = np.clip(rh_pct, 0, 100) / 100.0 * _saturation_vapor_pressure_pa(temp_k)
    return (pressure_pa - p_wv) / (287.058 * temp_k) + p_wv / (461.495 * temp_k)


def _ampacity_vector(
    windspeed_ms: np.ndarray,
    pressure_pa: np.ndarray,
    temp_ambient_c: np.ndarray,
    rh_pct: np.ndarray,
    wind_conductor_angle_deg: np.ndarray,
    solar_ghi_wm2: np.ndarray,
    conductor_cfg: dict,
) -> np.ndarray:
    """Steady-state IEEE-738-style thermal balance.

    This implementation follows the public National Laboratory of the Rockies/NREL
    DynamicLineRatings physics formulation (which cites IEEE 738-2012). Before a final
    EPSR submission, cross-check the chosen conductor/weather assumptions and formula
    implementation against licensed IEEE Std 738-2023 / the applicable utility guide.
    """
    d = float(conductor_cfg["diameter_m"])
    eps = float(conductor_cfg["emissivity"])
    absorp = float(conductor_cfg["absorptivity"])
    tc_c = float(conductor_cfg["max_conductor_temp_c"])
    tc_k = tc_c + C2K
    r25_ohm_m = float(conductor_cfg["r25_ohm_per_km"]) / 1000.0
    alpha = float(conductor_cfg["alpha_per_c"])
    resistance = r25_ohm_m * (1.0 + alpha * (tc_c - 25.0))

    ta_k = temp_ambient_c + C2K
    tf = (tc_k + ta_k) / 2.0
    # IEEE-style air properties used by the NLR/NREL implementation.
    mu = 1.458e-6 * tf**1.5 / (tf - C2K + 383.4)
    k_air = 2.424e-2 + 7.477e-5 * (tf - C2K) - 4.407e-9 * (tf - C2K) ** 2
    rho = _air_density_ideal(pressure_pa, tf, rh_pct)
    re = d * rho * np.clip(windspeed_ms, 0, None) / mu
    k_angle = _wind_factor(wind_conductor_angle_deg)

    delta_t = np.maximum(tc_c - temp_ambient_c, 0.0)
    q_zero = 3.645 * np.sqrt(np.maximum(rho, 0)) * d**0.75 * delta_t**1.25
    q_low = k_angle * (1.01 + 1.35 * re**0.52) * k_air * delta_t
    q_high = k_angle * 0.754 * re**0.6 * k_air * delta_t
    q_c = np.maximum.reduce([q_zero, q_low, q_high])

    q_r = math.pi * d * eps * STEFAN_BOLTZMANN * (tc_k**4 - ta_k**4)
    q_s = np.clip(solar_ghi_wm2, 0, None) * d * absorp
    joule_allowance = q_c + q_r - q_s
    current = np.sqrt(np.maximum(joule_allowance, 0.0) / resistance)
    current[~np.isfinite(current)] = np.nan
    return current


def amp_to_mva(current_a: np.ndarray | float, line_voltage_kv: float) -> np.ndarray:
    return np.sqrt(3.0) * float(line_voltage_kv) * np.asarray(current_a, dtype=float) / 1000.0


def build_dlr(weather_15: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    c = cfg["conductor"]
    d = weather_15.copy().sort_values("timestamp_utc")
    for col, default in [("pressure_pa", 101325.0), ("relative_humidity_pct", 50.0)]:
        if col not in d.columns:
            d[col] = default
    required = ["temperature_c", "wind_speed_ms", "wind_direction_deg", "ghi_wm2"]
    missing = [x for x in required if x not in d.columns]
    if missing:
        raise ValueError(f"DLR model missing columns: {missing}")

    out = pd.DataFrame({"timestamp_utc": pd.to_datetime(d["timestamp_utc"], utc=True)})
    orientations = [float(x) for x in c.get("orientation_sensitivity_deg", [c.get("primary_orientation_deg", 90.0)])]
    primary = float(c.get("primary_orientation_deg", orientations[-1]))

    wind_dir = pd.to_numeric(d["wind_direction_deg"], errors="coerce").to_numpy(dtype=float)
    wind_speed = pd.to_numeric(d["wind_speed_ms"], errors="coerce").to_numpy(dtype=float)
    temp = pd.to_numeric(d["temperature_c"], errors="coerce").to_numpy(dtype=float)
    pressure = pd.to_numeric(d["pressure_pa"], errors="coerce").fillna(101325.0).to_numpy(dtype=float)
    rh = pd.to_numeric(d["relative_humidity_pct"], errors="coerce").fillna(50.0).to_numpy(dtype=float)
    ghi = pd.to_numeric(d["ghi_wm2"], errors="coerce").fillna(0.0).to_numpy(dtype=float)

    for orientation in orientations:
        phi = _wind_axis_angle_deg(wind_dir, orientation)
        current = _ampacity_vector(wind_speed, pressure, temp, rh, phi, ghi, c)
        suffix = str(int(orientation) if orientation.is_integer() else orientation).replace(".", "p")
        out[f"dlr_ampacity_a_axis_{suffix}"] = current
        out[f"dlr_mva_axis_{suffix}"] = amp_to_mva(current, c["line_voltage_kv"])

    phi_primary = _wind_axis_angle_deg(wind_dir, primary)
    current_primary = _ampacity_vector(wind_speed, pressure, temp, rh, phi_primary, ghi, c)
    out["wind_conductor_angle_deg"] = phi_primary
    out["dlr_ampacity_a"] = current_primary
    out["dlr_mva"] = amp_to_mva(current_primary, c["line_voltage_kv"])
    out["quality_flag"] = np.where((out["dlr_ampacity_a"] > 0) & np.isfinite(out["dlr_ampacity_a"]), "pass", "fail")
    return out


def static_rating(cfg: dict) -> dict:
    s = cfg["static_rating"]
    c = cfg["conductor"]
    current = _ampacity_vector(
        np.array([float(s["wind_speed_ms"])]),
        np.array([float(s["pressure_pa"])]),
        np.array([float(s["ambient_temp_c"])]),
        np.array([50.0]),
        np.array([float(s["wind_conductor_angle_deg"])]),
        np.array([float(s["solar_ghi_wm2"])]),
        c,
    )[0]
    return {
        "str_ampacity_a": float(current),
        "str_mva": float(amp_to_mva(current, c["line_voltage_kv"])),
        "ambient_temp_c": float(s["ambient_temp_c"]),
        "wind_speed_ms": float(s["wind_speed_ms"]),
        "wind_conductor_angle_deg": float(s["wind_conductor_angle_deg"]),
        "solar_ghi_wm2": float(s["solar_ghi_wm2"]),
        "pressure_pa": float(s["pressure_pa"]),
    }


def season_from_month(month: pd.Series) -> pd.Series:
    return month.map({12:"winter",1:"winter",2:"winter",3:"spring",4:"spring",5:"spring",6:"summer",7:"summer",8:"summer",9:"autumn",10:"autumn",11:"autumn"})


def seasonal_ratings(weather_15: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    s_cfg = cfg["seasonal_rating"]
    c = cfg["conductor"]
    d = weather_15.copy()
    ts = pd.to_datetime(d["timestamp_utc"], utc=True)
    d["season"] = season_from_month(ts.dt.month)
    rows = []
    for season, g in d.groupby("season"):
        if g.empty:
            continue
        temp = float(g["temperature_c"].quantile(float(s_cfg["temperature_percentile"]) / 100.0))
        wind = float(g["wind_speed_ms"].quantile(float(s_cfg["low_wind_percentile"]) / 100.0))
        ghi = float(g["ghi_wm2"].quantile(float(s_cfg["solar_percentile"]) / 100.0))
        pressure = float(g.get("pressure_pa", pd.Series([101325.0])).median())
        rh = float(g.get("relative_humidity_pct", pd.Series([50.0])).median())
        angle = float(c.get("primary_orientation_deg", 90.0))
        current = _ampacity_vector(
            np.array([wind]), np.array([pressure]), np.array([temp]), np.array([rh]),
            np.array([angle]), np.array([ghi]), c
        )[0]
        rows.append({
            "season": season,
            "seasonal_ampacity_a": float(current),
            "seasonal_rating_mva": float(amp_to_mva(current, c["line_voltage_kv"])),
            "design_temperature_c": temp,
            "design_wind_speed_ms": wind,
            "design_ghi_wm2": ghi,
            "design_pressure_pa": pressure,
            "design_relative_humidity_pct": rh,
            "design_wind_conductor_angle_deg": angle,
        })
    return pd.DataFrame(rows)
