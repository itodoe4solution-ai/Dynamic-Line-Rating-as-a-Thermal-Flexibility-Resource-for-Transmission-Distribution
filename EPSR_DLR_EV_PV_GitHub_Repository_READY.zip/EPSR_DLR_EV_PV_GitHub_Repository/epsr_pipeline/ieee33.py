from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
import math
import numpy as np
import pandas as pd

BASE_KV_LL = 12.66

# Canonical Baran-Wu / MATPOWER case33bw loads (three-phase totals, kW/kvar).
LOADS = {
    1:(0,0), 2:(100,60), 3:(90,40), 4:(120,80), 5:(60,30), 6:(60,20),
    7:(200,100), 8:(200,100), 9:(60,20), 10:(60,20), 11:(45,30),
    12:(60,35), 13:(60,35), 14:(120,80), 15:(60,10), 16:(60,20),
    17:(60,20), 18:(90,40), 19:(90,40), 20:(90,40), 21:(90,40),
    22:(90,40), 23:(90,50), 24:(420,200), 25:(420,200), 26:(60,25),
    27:(60,25), 28:(60,20), 29:(120,70), 30:(200,600), 31:(150,70),
    32:(210,100), 33:(60,40),
}

# Closed radial branches, impedance in ohm per phase.
BRANCHES = [
    (1,2,0.0922,0.0470),(2,3,0.4930,0.2511),(3,4,0.3660,0.1864),(4,5,0.3811,0.1941),
    (5,6,0.8190,0.7070),(6,7,0.1872,0.6188),(7,8,0.7114,0.2351),(8,9,1.0300,0.7400),
    (9,10,1.0440,0.7400),(10,11,0.1966,0.0650),(11,12,0.3744,0.1238),(12,13,1.4680,1.1550),
    (13,14,0.5416,0.7129),(14,15,0.5910,0.5260),(15,16,0.7463,0.5450),(16,17,1.2890,1.7210),
    (17,18,0.7320,0.5740),(2,19,0.1640,0.1565),(19,20,1.5042,1.3554),(20,21,0.4095,0.4784),
    (21,22,0.7089,0.9373),(3,23,0.4512,0.3083),(23,24,0.8980,0.7091),(24,25,0.8960,0.7011),
    (6,26,0.2030,0.1034),(26,27,0.2842,0.1447),(27,28,1.0590,0.9337),(28,29,0.8042,0.7006),
    (29,30,0.5075,0.2585),(30,31,0.9744,0.9630),(31,32,0.3105,0.3619),(32,33,0.3410,0.5302),
]

# Normally-open tie switches from MATPOWER case33bw.
TIES = [
    (21,8,2.0,2.0),
    (9,15,2.0,2.0),
    (12,22,2.0,2.0),
    (18,33,0.5,0.5),
    (25,29,0.5,0.5),
]


def backward_forward_sweep(tol: float=1e-10, max_iter: int=1000):
    """Balanced 3-phase backward/forward sweep using the exact case33bw R/X and PQ loads."""
    vll = BASE_KV_LL * 1e3
    vsl = vll / math.sqrt(3.0)
    children = defaultdict(list)
    parent = {}
    zline = {}
    for f,t,r,x in BRANCHES:
        children[f].append(t)
        parent[t]=f
        zline[(f,t)] = complex(r,x)
    order=[]; q=deque([1])
    while q:
        u=q.popleft(); order.append(u); q.extend(children[u])
    v={i:complex(vsl,0.0) for i in range(1,34)}
    ib={}
    for iteration in range(1,max_iter+1):
        iload={}
        for i in range(1,34):
            p,qv=LOADS[i]
            sph=complex(p,qv)*1000.0/3.0
            iload[i]=np.conj(sph/v[i]) if i != 1 else 0j
        ib={}
        for u in reversed(order[1:]):
            total=iload[u] + sum(ib[(u,c)] for c in children[u])
            ib[(parent[u],u)] = total
        vnew={1:complex(vsl,0.0)}
        for u in order[1:]:
            p=parent[u]
            vnew[u]=vnew[p]-ib[(p,u)]*zline[(p,u)]
        err=max(abs(vnew[i]-v[i]) for i in vnew)
        v=vnew
        if err < tol:
            break
    rows=[]
    for i in range(1,34):
        rows.append({'bus':i,'voltage_pu':abs(v[i])/vsl,'angle_deg':math.degrees(np.angle(v[i])),'load_kw':LOADS[i][0],'load_kvar':LOADS[i][1]})
    bus_df=pd.DataFrame(rows)
    loss_rows=[]
    for k,(f,t,r,x) in enumerate(BRANCHES,1):
        cur=ib[(f,t)]
        p_loss=3*(abs(cur)**2)*r/1000.0
        q_loss=3*(abs(cur)**2)*x/1000.0
        loss_rows.append({'branch':k,'from_bus':f,'to_bus':t,'current_a':abs(cur),'p_loss_kw':p_loss,'q_loss_kvar':q_loss})
    loss_df=pd.DataFrame(loss_rows)
    summary={
        'converged': iteration < max_iter,
        'iterations': iteration,
        'total_native_load_kw': sum(v[0] for v in LOADS.values()),
        'total_native_load_kvar': sum(v[1] for v in LOADS.values()),
        'total_line_loss_kw': float(loss_df.p_loss_kw.sum()),
        'total_line_loss_kvar': float(loss_df.q_loss_kvar.sum()),
        'substation_import_kw': float(sum(v[0] for v in LOADS.values()) + loss_df.p_loss_kw.sum()),
        'substation_import_kvar': float(sum(v[1] for v in LOADS.values()) + loss_df.q_loss_kvar.sum()),
        'minimum_voltage_pu': float(bus_df.voltage_pu.min()),
        'minimum_voltage_bus': int(bus_df.loc[bus_df.voltage_pu.idxmin(),'bus']),
        'maximum_voltage_pu': float(bus_df.voltage_pu.max()),
    }
    return summary,bus_df,loss_df


def write_opendss_model(out_dir: Path):
    out_dir=Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    master = """! Canonical balanced IEEE/Baran-Wu 33-bus radial feeder\n! Data: MATPOWER case33bw (Baran & Wu 1989)\nClear\nSet DefaultBaseFrequency=60\nNew Circuit.IEEE33 basekV=12.66 pu=1.0 phases=3 bus1=b1 MVAsc3=1000000 MVAsc1=1000000\nSet VoltageBases=[12.66]\nRedirect IEEE33_Lines.dss\nRedirect IEEE33_Ties.dss\nRedirect IEEE33_Loads.dss\nCalcVoltageBases\nSet ControlMode=OFF\nSet MaxIterations=100\nSet MaxControlIter=100\nSolve mode=snapshot\n"""
    (out_dir/'IEEE33_Master.dss').write_text(master,encoding='utf-8')
    lines=[]
    for k,(f,t,r,x) in enumerate(BRANCHES,1):
        lines.append(f"New Line.L{k} phases=3 bus1=b{f}.1.2.3 bus2=b{t}.1.2.3 length=1 units=km r1={r:.6f} x1={x:.6f} r0={r:.6f} x0={x:.6f} c1=0 c0=0")
    (out_dir/'IEEE33_Lines.dss').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    ties=[]
    for k,(f,t,r,x) in enumerate(TIES,33):
        ties.append(f"New Line.Tie{k} phases=3 bus1=b{f}.1.2.3 bus2=b{t}.1.2.3 length=1 units=km r1={r:.6f} x1={x:.6f} r0={r:.6f} x0={x:.6f} c1=0 c0=0 enabled=no")
    (out_dir/'IEEE33_Ties.dss').write_text('\n'.join(ties)+'\n',encoding='utf-8')
    loadlines=[]
    for bus in range(2,34):
        p,q=LOADS[bus]
        loadlines.append(f"New Load.Load{bus} phases=3 bus1=b{bus}.1.2.3 conn=wye kV=12.66 model=1 kW={p:.6f} kvar={q:.6f} Vminpu=0.80 Vmaxpu=1.20")
    (out_dir/'IEEE33_Loads.dss').write_text('\n'.join(loadlines)+'\n',encoding='utf-8')
    pd.DataFrame([{'bus':b,'p_kw':LOADS[b][0],'q_kvar':LOADS[b][1],'der_allocation_weight':LOADS[b][0]/sum(v[0] for k,v in LOADS.items() if k!=1)} for b in range(2,34)]).to_csv(out_dir/'IEEE33_BusLoads_and_DER_weights.csv',index=False)
    pd.DataFrame(BRANCHES,columns=['from_bus','to_bus','r_ohm','x_ohm']).to_csv(out_dir/'IEEE33_ClosedBranches.csv',index=False)
    pd.DataFrame(TIES,columns=['from_bus','to_bus','r_ohm','x_ohm']).assign(status='normally_open').to_csv(out_dir/'IEEE33_OpenTies.csv',index=False)


def write_reference_outputs(out_dir: Path, qc_dir: Path):
    summary,bus_df,loss_df=backward_forward_sweep()
    out_dir=Path(out_dir); qc_dir=Path(qc_dir); out_dir.mkdir(parents=True,exist_ok=True); qc_dir.mkdir(parents=True,exist_ok=True)
    bus_df.to_csv(qc_dir/'ieee33_bfs_bus_voltage_reference.csv',index=False)
    loss_df.to_csv(qc_dir/'ieee33_bfs_branch_loss_reference.csv',index=False)
    pd.DataFrame([summary]).to_csv(qc_dir/'ieee33_independent_benchmark.csv',index=False)
    return summary
