# Notebook interface

The repository is preserved and now includes a single Q1 master notebook:

- `EPSR_Q1_Final_Master_Research_Notebook.ipynb` — six-phase master research notebook:
  1. Physical modelling
  2. Heterogeneous T–D modelling
  3. Forecasting and uncertainty
  4. STR-SMPC versus DLR-SMPC
  5. ACOPF / selected N-1 / IEEE-39
  6. Publication tables and figures

The earlier notebooks remain available as supporting interfaces:
- `EPSR_Research_Master_Notebook.ipynb`
- `EPSR_Stage1_EV_IEEE33_Notebook.ipynb`

## Running
Open the repository in VS Code/Jupyter and select the `itodo` Conda environment (or equivalent) as the kernel.

The Q1 master notebook is non-destructive by default. All execution flags start as `False`.
It refuses to invent missing Phase-2/4/5 outputs; those phases activate only when their result files or engines exist.
