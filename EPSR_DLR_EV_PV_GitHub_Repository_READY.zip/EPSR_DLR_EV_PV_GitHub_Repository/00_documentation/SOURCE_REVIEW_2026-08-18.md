# Verified Open-Source Data Sources — 18 Aug 2026

## 1. Caltech ACN-Data — primary EV source

Official page: https://ev.caltech.edu/dataset.html

Why selected:
- Caltech site is in Pasadena, California.
- Session fields include connection/disconnection time, delivered kWh, station/site identifiers and user inputs.
- The time-series endpoint includes measured charging current and pilot signal.
- The official page warns that old Web Interface downloads before 10 Oct 2019 had a timezone bug; the API/current Python interface is stated to be correct to Caltech's knowledge.

Pipeline use:
- `scripts/02_acn_inventory.py`: count sessions month-by-month before choosing a study period.
- `scripts/03_download_acn.py`: retrieve the selected period with time series.
- `scripts/04_build_ev_profile.py`: reconstruct 15-minute EV energy while preserving measured session kWh.

## 2. NSRDB GOES CONUS PSM v4 — primary weather/solar source

Official API documentation:
https://developer.nlr.gov/docs/solar/nsrdb/nsrdb-GOES-conus-v4-0-0-download/

Current documentation lists:
- 2018–2024 year options;
- approximately 2-km spatial resolution;
- 5-minute temporal resolution;
- air temperature, DHI, DNI, GHI, relative humidity, surface pressure, wind direction, wind speed and solar zenith angle among available attributes.

Pipeline use:
- one point / one year per direct CSV request;
- 5-minute raw data retained;
- circular wind-direction mean and arithmetic mean of scalar meteorology used for 15-minute aggregation.

## 3. NOAA/NCEI ISD / ISD-Lite — independent weather validation

Official station history:
https://www.ncei.noaa.gov/pub/data/noaa/isd-history.csv

Official ISD-Lite archive:
https://www.ncei.noaa.gov/pub/data/noaa/isd-lite/

Official format:
https://www.ncei.noaa.gov/pub/data/noaa/isd-lite/isd-lite-format.txt

Pipeline use:
- select the nearest station with coverage of the full study period;
- validate NSRDB temperature, wind speed and wind direction;
- retain NOAA as an independent validation source rather than mixing it into the primary driver silently.

## 4. EIA-930 — California balancing-authority operating data

Official EIA Open Data:
https://www.eia.gov/opendata/

API documentation:
https://www.eia.gov/opendata/documentation.php

Dataset family:
- hourly demand;
- day-ahead demand forecast;
- net generation;
- interchange;
- organized by balancing authority.

Pipeline uses the CISO balancing-authority facet and preserves raw hourly data before alignment to the 15-minute simulation grid.

## 5. pvlib — physical PV conversion

Official documentation:
https://pvlib-python.readthedocs.io/

Model inputs used by the pipeline:
- GHI, DNI, DHI;
- ambient temperature;
- wind speed;
- site latitude/longitude;
- array tilt/azimuth;
- configured PV and inverter capacities.

Outputs are model-derived PV power, not measured plant data.

## 6. DLR calculation and IEEE 738

Active standard page:
https://standards.ieee.org/ieee/738/10207/

IEEE Std 738-2023 describes the numerical relationship between conductor current/temperature and weather but explicitly does not prescribe the weather or conductor parameters that a utility should choose for a rating.

Public NLR/NREL implementation:
https://github.com/NatLabRockies/DynamicLineRatings

The included project calculator follows the same public IEEE-738-style heat-balance structure used by the NLR/NREL implementation and exports orientation sensitivity. The final paper should independently verify the implementation and the chosen design-weather assumptions against IEEE Std 738-2023 and applicable utility/grid-rating practice.

## 7. Why the previous Abuja/Germany mix is retained only as legacy

The legacy CSVs are useful for reproducing the rejected-paper workflow, but they do not represent one geographically coherent operating system because their EV, meteorology and grid-demand components came from different regions. The new primary dataset is therefore organized around Southern California / Pasadena / Caltech, while external-country datasets may be used only as explicitly labelled robustness tests.
