# Research Stage 1 — EV-template validation + full IEEE-33 OpenDSS benchmark

Date: 2026-08-19

## Scope frozen for this stage

This stage deliberately uses the data already available in the research package. It does not add a new primary dataset. The two priorities are:

1. Validate the duration-conditioned empirical EV charging templates against the measured ACN charging-current subset.
2. Implement the complete canonical Baran-Wu 33-bus feeder in OpenDSS and establish an independent base-case reference before any EV/PV is connected.

---

## A. EV-template validation

### Available measured-current evidence

The ACN archive contains 11,614 sessions, but only 243 sessions contain usable `chargingCurrent` traces. These 243 traces span 2018-10-30 00:01:38 UTC to 2018-11-01 16:12:39 UTC. This is therefore a narrow calibration sample, not a measured annual EV power series.

Measured-current sessions by duration bucket:

| Duration bucket | Measured sessions | Measured energy (kWh) |
|---|---:|---:|
| 0–1 h | 51 | 133.911 |
| 1–2 h | 70 | 435.310 |
| 2–4 h | 54 | 615.079 |
| 4–8 h | 44 | 491.518 |
| 8+ h | 24 | 153.655 |
| **Total** | **243** | **1,829.473** |

### Validation design

A repeated, stratified 5-fold session-level cross-validation was added. The experiment is repeated 10 times. For each fold, the duration-bucket template is learned without the held-out sessions. The held-out measured-current shape is then compared with:

- the duration-bucket template (primary reconstruction),
- one global measured-current template,
- a uniform charging profile.

The comparison is performed on normalized intra-session energy shape, so it measures temporal shape rather than trivially reproducing the measured delivered kWh.

### Main out-of-sample results

Across all 243 measured sessions and 10 repeats:

| Model | Mean shape RMSE | Median shape RMSE | Mean correlation | Median correlation | Mean CDF-MAE | Mean peak-time error (h) |
|---|---:|---:|---:|---:|---:|---:|
| Duration-bucket template | 0.025825 | 0.011769 | 0.5367 | 0.6762 | 0.09705 | 0.554 |
| Global template | 0.031216 | 0.016061 | 0.4009 | 0.5209 | 0.12805 | 0.614 |
| Uniform profile | 0.030888 | 0.013735 | — | — | 0.13487 | 0.615 |

The duration-conditioned template reduces mean shape RMSE by **17.27% relative to the global template** and **16.39% relative to the uniform profile**. Its mean cumulative-profile error is **24.21% lower than the global template**.

### Research interpretation

This supports keeping duration-conditioned templates rather than the earlier uniform-energy fallback. However, the measured-current sample covers only about 2.7 days and 98.25% of the annual reconstructed EV energy is still template based. Therefore:

- the annual EV power series must be described as **empirically reconstructed from observed ACN session metadata and a measured-current calibration subset**;
- it must not be described as a fully measured 15-minute annual EV load series;
- final controller results should include a sensitivity to EV intra-session shape (duration-bucket template vs global/uniform or another conservative shape) so that the DLR conclusion is not dependent on one fallback assumption.

Files generated:

- `05_quality_control/ev_measured_current_inventory.csv`
- `05_quality_control/ev_measured_current_bucket_inventory.csv`
- `05_quality_control/ev_template_cross_validation.csv`
- `05_quality_control/ev_template_cross_validation_summary.csv`

---

## B. Full IEEE-33 OpenDSS feeder

### Model definition

The implemented feeder is the complete canonical 33-bus Baran-Wu radial distribution benchmark as provided by MATPOWER `case33bw`:

- nominal voltage: 12.66 kV;
- 33 buses;
- 32 closed radial branches;
- 5 normally-open tie branches;
- total native demand: 3,715 kW + j2,300 kvar;
- balanced three-phase constant-P/Q loads;
- branch R/X values retained in ohms per phase.

For exact base-case reproduction, the validation model uses a stiff 12.66-kV source rather than adding an arbitrary source-transformer impedance. A transmission/distribution transformer should be added only after the untouched benchmark feeder passes validation, with its parameters reported separately.

### Independent reference calculation

A separate backward/forward-sweep implementation was added so that the OpenDSS solution is not treated as self-validating.

Independent base-case result:

| Quantity | Reference result |
|---|---:|
| Native active load | 3,715 kW |
| Native reactive load | 2,300 kvar |
| Active line loss | **202.6771 kW** |
| Reactive line loss | **135.1410 kvar** |
| PCC/substation active import | **3,917.6771 kW** |
| PCC/substation reactive import | **2,435.1410 kvar** |
| Minimum voltage | **0.913090 pu** |
| Minimum-voltage bus | **18** |
| Maximum voltage | 1.000000 pu |

### OpenDSS files generated

- `09_simulation_inputs/ieee33_opendss/IEEE33_Master.dss`
- `09_simulation_inputs/ieee33_opendss/IEEE33_Lines.dss`
- `09_simulation_inputs/ieee33_opendss/IEEE33_Ties.dss`
- `09_simulation_inputs/ieee33_opendss/IEEE33_Loads.dss`
- `09_simulation_inputs/ieee33_opendss/IEEE33_BusLoads_and_DER_weights.csv`
- `09_simulation_inputs/ieee33_opendss/IEEE33_ClosedBranches.csv`
- `09_simulation_inputs/ieee33_opendss/IEEE33_OpenTies.csv`

Independent reference outputs:

- `05_quality_control/ieee33_independent_benchmark.csv`
- `05_quality_control/ieee33_bfs_bus_voltage_reference.csv`
- `05_quality_control/ieee33_bfs_branch_loss_reference.csv`

### OpenDSS validation gate

Run:

```bash
python scripts/22_validate_ieee33_opendss.py
```

The script requires `OpenDSSDirect.py>=0.9`, solves the generated OpenDSS feeder, and compares OpenDSS against the independent reference. The initial acceptance gate is:

- minimum-voltage absolute error <= 0.002 pu;
- line-loss relative error <= 1%;
- OpenDSS convergence required.

The gate writes:

- `05_quality_control/ieee33_opendss_bus_voltage_validation.csv`
- `05_quality_control/ieee33_opendss_validation_summary.csv`

No DER, EV, PV, load-shape scaling or feeder replication should be added before this base model passes.

---

## Stage-1 research decision

The research can continue with the available data. The EV cross-validation shows that duration-conditioned templates are materially better than global/uniform reconstruction, but they remain a derived annual power shape and require sensitivity analysis in the final experiment. The canonical IEEE-33 benchmark is now fully specified and independently benchmarked; the remaining immediate task is to run the OpenDSS validation script on the research machine.

After the OpenDSS gate passes, Stage 2 should be:

1. map the 2019 CISO load series to the native IEEE-33 loads using a normalized regional load multiplier;
2. allocate EV/PV capacity to load buses using the predeclared native-load-proportional rule;
3. create heterogeneous feeder classes from observed EV session resamples and PV penetration levels;
4. validate voltage, losses and PCC P/Q across representative 2019 operating periods before coupling the feeder population to IEEE-118.
