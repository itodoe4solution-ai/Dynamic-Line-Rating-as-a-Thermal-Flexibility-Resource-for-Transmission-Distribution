can you search online and write code to download all these datas and follow the these steps Publication-Grade Dataset Preparation Workflow for EPSR

## Objective

Develop a geographically and temporally consistent real-world dataset for:

**DLR + EV charging + PV generation + transmission/distribution operation + stochastic MPC**

with sufficient coverage of:

- winter and summer;
- spring and autumn;
- high and low temperature;
- extreme heat;
- high and low wind;
- high and low solar generation;
- high and low EV demand;
- weekday/weekend differences;
- combined critical operating conditions.

The recommended primary geographical region is:

**Southern California / Pasadena / Caltech**

because the existing EV data originate from ACN-Data.

---

## Step 1 — Preserve the existing dataset

Do not delete the current seven-day dataset.

Create:

`01_legacy_dataset/`

and store the current files exactly as received.

Purpose:

- retain reproducibility;
- reproduce the rejected-paper results;
- compare old and new results;
- demonstrate how the revised dataset improves the study.

Never overwrite original raw files.

---

## Step 2 — Create a formal dataset structure

Use the following directory structure:

```
paper3_data/
│
├── 00_documentation/
├── 01_raw/
│   ├── acn_ev/
│   ├── nsrdb/
│   ├── noaa/
│   ├── eia930/
│   └── caiso/
│
├── 02_cleaned/
├── 03_processed/
├── 04_master/
├── 05_quality_control/
├── 06_scenarios/
├── 07_forecasts/
├── 08_dlr/
├── 09_simulation_inputs/
└── 10_reproducibility/

```

Do not modify files inside `01_raw`.

---

## Step 3 — Create a data-provenance manifest

Before processing anything, create:

`data_sources.csv`

with fields such as:

```
variable
source
dataset
website
location
latitude
longitude
start_date
end_date
original_resolution
download_date
timezone
processing_method
license
notes

```

For example:

| VariableSourceLocation |                       |                             |
| ---------------------- | --------------------- | --------------------------- |
| EV charging            | Caltech ACN-Data      | Pasadena                    |
| GHI/DNI/DHI            | NREL NSRDB            | Pasadena                    |
| Temperature            | NREL NSRDB            | Pasadena                    |
| Wind                   | NREL NSRDB            | Pasadena                    |
| Weather validation     | NOAA                  | nearest appropriate station |
| System demand          | EIA-930 / CAISO       | California                  |
| DLR                    | Calculated by authors | IEEE 738                    |
| PV                     | Calculated by authors | NSRDB weather               |

This single file will substantially improve reproducibility.

---

## Step 4 — Select one primary geographical system

The new primary experiment should not combine:

**California EV + Abuja weather + German grid load.**

Instead use:

[
\boxed{\text{Southern California for the complete primary dataset}}
]

Therefore:

**EV:** Caltech/Pasadena
**Weather:** Pasadena/Southern California
**Solar:** Pasadena/Southern California
**Grid load:** California ISO
**DLR weather:** Pasadena/Southern California

Other countries can later be used as independent sensitivity tests.

---

## Step 5 — Determine the longest reliable ACN period

Do not first decide that the study will use exactly 2019–2021.

Instead:

1. Query the current ACN API.
2. Determine available sessions by year and month.
3. Count valid sessions per month.
4. Identify gaps.
5. Determine changes in station availability.
6. Identify abnormal periods.
7. Select the longest defensible period.

Prefer:

[
\boxed{\geq 1\text{ complete year}}
]

and, if available:

[
\boxed{2-3\text{ years}}
]

One year at 15-minute resolution gives:

[
365\times24\times4=35,040
]

time steps.

That is vastly stronger than the current 672 samples.

---

## Step 6 — Re-download ACN EV data from the official current API

This is important because the existing May-2019 EV profile showed inconsistencies.

Download the raw information required to reconstruct EV charging:

```
session_id
station_id
connection_time
disconnect_time
done_charging_time
energy_delivered
chargingCurrent
pilotSignal
userInputs

```

Do not use interpolated charging power from the existing `ev_profile.csv`.

Reconstruct it.

---

## Step 7 — Perform basic EV-session cleaning

Reject or flag sessions with:

```
disconnect_time < connection_time
energy_delivered < 0
missing session_id
duplicate session_id
invalid timestamp
negative charging current
unrealistic charging duration

```

Do not silently remove records.

Create:

`ev_quality_flags.csv`

containing the reason every rejected or questionable record was flagged.

---

## Step 8 — Reconstruct 15-minute EV charging correctly

Generate the aggregate EV load directly from the underlying charging-current/time-series records.

For every 15-minute interval:

# [ P\_{EV}(t)

\sum\_{i=1}^{N\_t}P\_{EV,i}(t)
]

Calculate:

```
ev_power_kw
ev_energy_kwh
connected_ev_count
charging_ev_count
arrivals
departures

```

Never use linear interpolation across intervals where no EV is connected.

Enforce:

[
N\_{charging}>0 \Rightarrow N\_{connected}>0
]

and:

[
N\_{connected}=0
\Rightarrow
P\_{EV}=0
]

unless a documented measurement exception exists.

---

## Step 9 — Validate EV energy conservation

For every session:

# [ E\_i^{reconstructed}

\sum\_t P\_i(t)\Delta t
]

Compare with reported:

[
E\_i^{reported}
]

Then calculate:

[
Error\_i=
\frac{|E\_i^{reconstructed}-E\_i^{reported}|}
{E\_i^{reported}}\times100
]

Recommended objective:

**median error very close to zero**

and approximately:

[
\boxed{<1%}
]

where measurement resolution permits.

Investigate every major discrepancy.

Also verify aggregate energy:

[
\sum E\_{interval}
\approx
\sum E\_{sessions}
]

after accounting for sessions crossing dataset boundaries.

---

## Step 10 — Keep measured and assumed EV variables separate

Do not mix assumptions with observations.

Use names such as:

```
measured_energy_delivered_kwh
measured_connection_time
measured_charging_current_a

derived_ev_power_kw
derived_session_duration_h

assumed_battery_capacity_kwh
assumed_initial_soc
assumed_target_soc
assumed_v2g_eligibility

```

This is particularly important for battery SOC.

Do not call estimated SOC “measured SOC”.

---

## Step 11 — Download matching NSRDB weather and solar data

Use coordinates corresponding to the selected Southern California location.

Acquire at least:

```
timestamp
air_temperature
wind_speed
wind_direction
GHI
DNI
DHI
surface_pressure
relative_humidity

```

If 5-minute NSRDB observations/products are available for the selected period, use them.

Do not interpolate hourly weather to 15 minutes if higher-resolution data are available.

---

## Step 12 — Validate weather independently with NOAA

Select the nearest technically appropriate NOAA station.

Download overlapping:

```
temperature
wind_speed
wind_direction
pressure
wind_gust

```

NSRDB remains the continuous primary meteorological driver.

NOAA becomes an independent validation source.

Calculate, where appropriate:

[
RMSE
]

[
MAE
]

[
Bias
]

[
R^2
]

for temperature and wind.

For wind direction use circular statistics rather than ordinary linear error where possible.

---

## Step 13 — Perform meteorological quality control

Check:

```
duplicate timestamps
missing timestamps
negative wind speed
wind direction outside 0–360°
unrealistic temperature
negative nighttime irradiance
impossible irradiance
pressure anomalies
long constant-value periods

```

Every corrected value must be traceable.

Create:

`weather_qc_report.csv`

---

## Step 14 — Convert all datasets to the same timezone

Keep two timestamps:

```
timestamp_utc
timestamp_local

```

Internally use:

[
\boxed{\text{UTC}}
]

for synchronization.

Preserve local time for interpreting EV behaviour and seasons.

This prevents daylight-saving-time errors.

---

## Step 15 — Resample everything to exactly 15 minutes

The final operational time base remains:

[
\Delta t=15\text{ min}
]

For 5-minute meteorological data, aggregate appropriately.

Examples:

Temperature:

[
T\_{15}=\operatorname{mean}(T\_5)
]

Wind speed:

[
V\_{15}=\operatorname{mean}(V\_5)
]

GHI:

use correct irradiance/energy aggregation rather than blindly summing instantaneous power values.

EV energy:

[
E\_{15}=
\sum E\_{subinterval}
]

Grid load:

use time-weighted aggregation or carefully justified interpolation if the original resolution is coarser.

Document the method variable by variable.

---

## Step 16 — Download geographically consistent California system demand

Replace German demand in the primary experiment.

Use:

**EIA-930 California ISO / CISO**

and supplement with CAISO data where useful.

Store:

```
system_load_mw
load_forecast_mw
net_interchange_mw
solar_generation_mw
wind_generation_mw

```

where available and required.

---

## Step 17 — Build a proper PV model

Do not continue using only:

[
PV\_{pu}=GHI/1000.
]

Use:

```
GHI
DNI
DHI
ambient temperature
wind speed
tilt
azimuth
module characteristics
inverter characteristics
system losses

```

Calculate:

[
G\_{POA}
]

then cell/module temperature:

[
T\_c=f(T\_a,G\_{POA},V\_w)
]

and:

[
P\_{DC}=f(G\_{POA},T\_c)
]

then:

[
P\_{AC}=\eta\_{inv}P\_{DC}
]

with clipping and relevant losses.

The output should include:

```
pv_available_kw
pv_dc_kw
pv_ac_kw
pv_curtailment_possible_kw

```

---

## Step 18 — Validate the PV model

Check:

[
P\_{PV}=0
]

during nighttime.

Verify:

[
0\leq P\_{PV}\leq P\_{rated}
]

unless documented inverter oversizing permits a different relationship.

Plot representative:

- winter day;
- summer day;
- cloudy day;
- clear day;
- highly variable day.

Inspect the curves visually.

---

## Step 19 — Calculate DLR from raw weather yourself

This is critical.

Use IEEE Std 738 and your selected conductor parameters.

At each timestamp solve the heat balance:

# [ q\_c(t)+q\_r(t)

q\_s(t)+I^2(t)R(T\_c)
]

therefore:

# [ I\_{DLR}(t)

\sqrt{
\frac{q\_c(t)+q\_r(t)-q\_s(t)}
{R(T\_c)}
}
]

Inputs should include:

```
ambient temperature
wind speed
wind direction
solar conditions
conductor diameter
emissivity
absorptivity
conductor resistance
maximum conductor temperature

```

Do not rely on the old precomputed DLR series for the primary experiment.

---

## Step 20 — Calculate a genuine Static Thermal Rating

Create an independent conventional rating:

# [ I\_{STR}

f(T\_{design},V\_{wind,design},G\_{design},T\_{c,max})
]

using documented conservative design weather.

The STR must not be:

[
\min(I\_{DLR})
]

from your evaluation period.

That is one of the most important scientific corrections.

---

## Step 21 — Add seasonal ratings

Create:

```
winter_static_rating
spring_static_rating
summer_static_rating
autumn_static_rating

```

using defensible seasonal assumptions.

Your main comparison becomes:

[
\boxed{
STR
\quad vs\quad
Seasonal\ Rating
\quad vs\quad
DLR
}
]

This is much more powerful scientifically.

---

## Step 22 — Independently verify DLR calculations

Select approximately 20–50 representative timestamps covering:

- cold/high wind;
- cold/low wind;
- normal conditions;
- hot/high wind;
- hot/low wind;
- extreme heat;
- high solar;
- low solar.

Manually or independently recompute conductor ampacity.

Ensure:

[
Error\_{DLR}
]

is negligible between implementations.

---

## Step 23 — Create one master dataset

Join everything strictly by timestamp.

Recommended fields:

```
timestamp_utc
timestamp_local

year
month
season
weekday
hour

ev_power_kw
ev_energy_kwh
ev_connected_count
ev_arrivals
ev_departures

temperature_c
wind_speed_ms
wind_direction_deg
wind_gust_ms
ghi_wm2
dni_wm2
dhi_wm2
pressure_pa
relative_humidity

pv_available_kw
pv_ac_kw

caiso_load_mw

str_ampacity_a
seasonal_ampacity_a
dlr_ampacity_a

str_mva
seasonal_rating_mva
dlr_mva

temperature_regime
wind_regime
solar_regime
ev_regime
critical_weather_flag

quality_flag

```

---

## Step 24 — Audit timestamp coverage

For every expected 15-minute interval verify exactly one record exists.

Acceptance target:

[
\boxed{Duplicate\ timestamps=0}
]

and preferably:

[
\boxed{Unexplained\ missing\ timestamps=0}
]

Every unavoidable gap must be identified explicitly.

---

## Step 25 — Define seasons objectively

For Northern Hemisphere Southern California:

```
Winter: December–February
Spring: March–May
Summer: June–August
Autumn: September–November

```

Report the number of observations in each season.

---

## Step 26 — Define temperature regimes statistically

Using the complete historical dataset, calculate:

[
P\_{5},P\_{10},P\_{25},P\_{50},P\_{75},P\_{90},P\_{95},P\_{99}
]

Then define, for example:

```
Very cold: ≤ P05
Cold: P05–P25
Normal: P25–P75
Hot: P75–P95
Extreme hot: ≥ P95
Severe extreme: ≥ P99

```

This prevents arbitrary scenario selection.

---

## Step 27 — Define wind regimes

For example:

```
Very low wind: ≤P05
Low wind: ≤P10
Normal wind: P10–P90
High wind: ≥P90
Extreme high wind: ≥P99

```

Low-wind periods are especially important for DLR.

---

## Step 28 — Define solar regimes

Use daily PV energy and instantaneous PV power.

For example:

```
Low PV day ≤ P10 daily energy
Normal PV P25–P75
High PV ≥ P90
Extreme PV ≥ P99

```

Also calculate ramping:

[
Ramp\_{PV,t}=P\_{PV,t}-P\_{PV,t-1}
]

Identify extreme PV ramp events.

---

## Step 29 — Define EV-demand regimes

Use:

```
15-minute EV power
daily EV energy
number of connected EVs
arrival count
departure count

```

Classify:

```
Low EV ≤P10
Normal EV P25–P75
High EV ≥P90
Extreme EV ≥P99

```

Also distinguish:

```
weekday
weekend
holiday

```

where reliable calendar metadata are available.

---

## Step 30 — Identify compound extreme events

This is particularly important for EPSR.

Create flags such as:

### Extreme thermal stress

[
T\_a\geq P\_{95}
]

AND

[
V\_w\leq P\_{10}
]

### Extreme thermal + solar stress

[
T\_a\geq P\_{95}
]

AND

[
V\_w\leq P\_{10}
]

AND

[
GHI\geq P\_{75}
]

### Grid-demand stress

[
EV\geq P\_{90}
]

AND

[
PV\leq P\_{10}
]

### Reverse-flow stress

[
PV\geq P\_{90}
]

AND

[
EV\leq P\_{25}
]

These are much more meaningful than randomly choosing difficult days.

---

## Step 31 — Produce a correlation and dependence audit

Calculate associations among:

[
EV,\ PV,\ T,\ wind,\ DLR,\ system\ load
]

But do not assume independence.

Investigate:

- temperature–DLR;
- wind–DLR;
- solar–DLR;
- temperature–system load;
- time-of-day–EV;
- PV–net load.

This helps justify stochastic scenario construction.

---

## Step 32 — Split forecasting data chronologically

Never randomly shuffle time-series samples.

Use a chronological split such as:

[
70%\ training
]

[
15%\ validation
]

[
15%\ test
]

or another justified temporal scheme.

The final test set must remain completely untouched during model development.

---

## Step 33 — Ensure every season appears in evaluation

A single final 33.75-hour period is no longer sufficient.

Evaluation should intentionally include:

- winter;
- spring;
- summer;
- autumn;
- extreme heat;
- low wind;
- high wind;
- high EV;
- low PV;
- high PV.

---

## Step 34 — Benchmark forecasting models properly

Do not automatically use LSTM.

For every variable compare against simple baselines.

EV:

```
Persistence
Seasonal persistence
Historical mean
LSTM
possibly another suitable model

```

PV:

```
Persistence
Clear-sky/physical baseline where appropriate
LSTM or another selected model

```

Select the model that performs best on validation data.

If persistence beats LSTM, use persistence.

---

## Step 35 — Use multiple forecasting metrics

Report:

[
RMSE
]

[
MAE
]

[
NRMSE
]

and appropriate statistical comparisons.

Also examine performance separately for:

- normal periods;
- extreme conditions;
- different seasons.

Average RMSE alone is not enough.

---

## Step 36 — Calibrate uncertainty scenarios

Your previous nominal 90% intervals substantially under-covered EV and PV.

The revised uncertainty framework should target approximately calibrated coverage.

For nominal:

[
90%
]

evaluate observed empirical coverage independently.

Report:

```
nominal coverage
empirical coverage
interval width
coverage by season
coverage during extremes

```

Do not claim probabilistic guarantees unless calibration supports them.

---

## Step 37 — Perform scenario-number sensitivity

Continue testing:

[
5,\quad10,\quad20
]

but consider adding:

[
30\text{ or }50
]

for selected periods if computationally practical.

Evaluate:

```
solution quality
solve time
constraint violations
EV service
DLR utilisation

```

Select the final number based on convergence and computational burden.

---

## Step 38 — Perform objective-weight sensitivity

Vary important SMPC weights systematically.

Particularly:

```
EV unserved-energy penalty
PV curtailment penalty
thermal penalty
voltage penalty
energy cost
ramping penalty

```

Show that the main DLR conclusion does not disappear because of one arbitrary weight choice.

---

## Step 39 — Correct the EV service formulation

Do not allow the optimized controller to serve dramatically less EV energy than uncontrolled charging without strong justification.

Test:

[
E\_i(t\_{departure})
\geq
E\_i^{required}
]

as a hard constraint where feasible.

If slack is retained:

## [ E\_i^{required}

E\_i^{served}
\leq
s\_i
]

report slack explicitly.

Compare multiple MPC horizons:

```
2 h
4 h
8 h
possibly 12 h

```

---

## Step 40 — Build representative simulation periods

You do not necessarily need to execute expensive SMPC simulations across every 15-minute period of three years.

Use the full historical dataset for statistical characterization and forecasting.

Then select representative weeks such as:

```
normal winter
cold/high-wind winter
low-wind winter

normal spring
high-PV spring

normal summer
extreme-heat summer
extreme-heat + low-wind summer
high-EV summer

normal autumn
low-solar/high-EV autumn
high-wind autumn

extreme EV week
extreme PV week
extreme compound-weather week

```

Approximately 12–16 representative periods could be highly defensible if selected transparently.

---

## Step 41 — Separate selection and testing

Do not select “interesting” extreme periods after looking at simulation outcomes.

Select periods solely from dataset statistics first.

Freeze:

`selected_periods.csv`

before running the final MATPOWER/OpenDSS simulations.

This prevents selection bias.

---

## Step 42 — Run STR, seasonal-rating and DLR cases identically

For every selected operating period run:

[
STR
]

[
Seasonal\ Rating
]

[
DLR
]

with identical:

```
EV data
PV data
grid load
controller structure
forecast information
random seeds
objective weights
initial conditions

```

Only the line-rating strategy should change in the central causal comparison.

---

## Step 43 — Run AC validation

Do not validate only the easiest points.

At minimum include:

- highest loading;
- lowest DLR;
- maximum EV;
- maximum PV;
- extreme heat;
- low-wind periods;
- large power-transfer periods.

Where feasible increase ACOPF validation substantially beyond the previous 54 selected points.

---

## Step 44 — Add N-1 security tests

Select important contingencies such as:

```
critical transmission-line outage
transformer outage
generator outage

```

Compare:

[
STR,\ Seasonal,\ DLR
]

under those contingencies.

This will make the manuscript much more power-system oriented.

---

## Step 45 — Use an external EV dataset only for robustness

After the California study is complete, optionally use:

**Optimise Prime**

or an appropriate Norwegian EV charging dataset.

Do not merge these observations into the California timeline.

Use them as:

[
\boxed{\text{external behavioural robustness tests}}
]

For example:

> Does the proposed EV scheduling framework still perform reasonably when EV arrival and charging distributions come from an independent fleet?

---

## Step 46 — Produce automatic quality-control reports

Your final processing script should generate:

```
missing_values_report.csv
duplicate_report.csv
timestamp_report.csv
ev_energy_balance_report.csv
weather_validation_report.csv
pv_validation_report.csv
dlr_validation_report.csv
outlier_report.csv
source_manifest.csv
dataset_summary.csv

```

Nothing should rely purely on manual inspection.

---

## Step 47 — Create automatic physical sanity tests

Your Python pipeline should fail if any of these occur:

```
EV power < 0
PV power < 0
PV > physical maximum without explanation
connected EV = 0 but charging power > 0
wind speed < 0
wind direction outside valid range
DLR <= 0
duplicate timestamps
missing mandatory timestamps
invalid branch rating
NaN in critical variables
infinite values

```

This is effectively a test suite for the research data.

---

## Step 48 — Visually inspect the data

Automated checks are not enough.

Plot:

1. full-year temperature;
2. full-year wind;
3. full-year PV;
4. full-year EV;
5. full-year DLR;
6. representative winter week;
7. representative summer week;
8. extreme heat event;
9. low-wind event;
10. extreme EV event.

Many errors are easier to identify visually than statistically.

---

## Step 49 — Freeze a versioned final dataset

When all checks pass, create:

```
master_dataset_v1.0.csv

```

Never change it silently.

If corrections occur:

```
master_dataset_v1.1.csv

```

and maintain:

`CHANGELOG.md`

---

## Step 50 — Freeze the simulation configuration

Create a machine-readable configuration such as:

```
config_final.json

```

containing:

```
dataset version
date ranges
PCC bus
DLR branch
conductor
EV scaling
PV capacity
MPC horizon
scenario count
random seeds
objective weights
voltage limits
solver tolerances
STR assumptions
seasonal-rating assumptions

```

This prevents accidental mismatch between reported and simulated results.

---

# Final acceptance gates

I would not begin the final EPSR simulations until the dataset satisfies these checks:

**Temporal integrity**

[
Duplicates=0
]

[
Unexplained\ missing\ intervals=0
]

**EV integrity**

[
Connected=0\Rightarrow EV\ power=0
]

Energy accounting closes within a predefined tolerance.

**Geographic integrity**

Primary EV, weather, solar and system-load data describe the same regional system.

**Weather integrity**

No impossible values and NSRDB has been checked against independent observational data.

**PV integrity**

[
0\leq P\_{PV}\leq P\_{physical,max}
]

with physically appropriate seasonal variation.

**DLR integrity**

DLR is independently computed from meteorological inputs using IEEE 738.

**Benchmark integrity**

STR is independently calculated and is not the minimum DLR from the experiment.

**Seasonal integrity**

Winter, spring, summer and autumn are represented.

**Extreme-condition integrity**

Extreme heat, low/high wind, extreme EV and solar conditions are represented.

**Forecast integrity**

Forecast models are selected based on validation—not because LSTM is more sophisticated.

**Uncertainty integrity**

Prediction/scenario coverage is explicitly calibrated and tested.

**Reproducibility**

Raw data + processing code + configuration + seeds + final dataset version are preserved.

---

# Recommended final research pipeline

The complete pipeline should become:

```
Caltech ACN raw EV data
          ↓
EV cleaning and reconstruction
          ↓
NREL NSRDB weather + solar
          ↓
NOAA weather validation
          ↓
CAISO/EIA grid demand
          ↓
15-minute synchronization
          ↓
Physical PV calculation
          ↓
IEEE-738 STR calculation
          ↓
IEEE-738 seasonal rating
          ↓
IEEE-738 DLR calculation
          ↓
Master historical dataset
          ↓
Quality-control tests
          ↓
Season/extreme-event classification
          ↓
Train/validation/test split
          ↓
Forecast benchmarking
          ↓
Calibrated uncertainty scenarios
          ↓
SMPC
          ↓
OpenDSS
          ↓
PCC exchange
          ↓
MATPOWER
          ↓
ACOPF
          ↓
N-1 tests
          ↓
Statistical comparison
          ↓
EPSR results

```

## Most important first action

Before doing any new simulation, I recommend beginning with only **three tasks**:

**First:** re-download and reconstruct the ACN EV data correctly.

**Second:** obtain matching Southern California NSRDB weather/solar data.

**Third:** create the first clean synchronized 15-minute master dataset.

Only after these three pass the quality checks should we move to PV, STR/DLR calculation and eventually MATPOWER/OpenDSS.

This prevents us from spending days rerunning simulations only to discover later that the input data contain another problem.

gcan you search online and write code to download all these datas and follow the these steps Publication-Grade Dataset Preparation Workflow for EPSR  ## Objective  Develop a geographically and temporally consistent real-world dataset for:  \*\*DLR + EV charging + PV generation + transmission/distribution operation + stochastic MPC\*\*  with sufficient coverage of:  - winter and summer; - spring and autumn; - high and low temperature; - extreme heat; - high and low wind; - high and low solar generation; - high and low EV demand; - weekday/weekend differences; - combined critical operating conditions.  The recommended primary geographical region is:  \*\*Southern California / Pasadena / Caltech\*\*  because the existing EV data originate from ACN-Data.  ---  ## Step 1 — Preserve the existing dataset  Do not delete the current seven-day dataset.  Create:  \`01\_legacy\_dataset/\`  and store the current files exactly as received.  Purpose:  - retain reproducibility; - reproduce the rejected-paper results; - compare old and new results; - demonstrate how the revised dataset improves the study.  Never overwrite original raw files.  ---  ## Step 2 — Create a formal dataset structure  Use the following directory structure:  \`\`\` paper3\_data/ │ ├── 00\_documentation/ ├── 01\_raw/ │   ├── acn\_ev/ │   ├── nsrdb/ │   ├── noaa/ │   ├── eia930/ │   └── caiso/ │ ├── 02\_cleaned/ ├── 03\_processed/ ├── 04\_master/ ├── 05\_quality\_control/ ├── 06\_scenarios/ ├── 07\_forecasts/ ├── 08\_dlr/ ├── 09\_simulation\_inputs/ └── 10\_reproducibility/  \`\`\`  Do not modify files inside \`01\_raw\`.  ---  ## Step 3 — Create a data-provenance manifest  Before processing anything, create:  \`data\_sources.csv\`  with fields such as:  \`\`\` variable source dataset website location latitude longitude start\_date end\_date original\_resolution download\_date timezone processing\_method license notes  \`\`\`  For example:  | VariableSourceLocation |                       |                             | | ---------------------- | --------------------- | --------------------------- | | EV charging            | Caltech ACN-Data      | Pasadena                    | | GHI/DNI/DHI            | NREL NSRDB            | Pasadena                    | | Temperature            | NREL NSRDB            | Pasadena                    | | Wind                   | NREL NSRDB            | Pasadena                    | | Weather validation     | NOAA                  | nearest appropriate station | | System demand          | EIA-930 / CAISO       | California                  | | DLR                    | Calculated by authors | IEEE 738                    | | PV                     | Calculated by authors | NSRDB weather               |  This single file will substantially improve reproducibility.  ---  ## Step 4 — Select one primary geographical system  The new primary experiment should not combine:  \*\*California EV + Abuja weather + German grid load.\*\*  Instead use:  [ \boxed{\text{Southern California for the complete primary dataset}} ]  Therefore:  \*\*EV:\*\* Caltech/Pasadena \*\*Weather:\*\* Pasadena/Southern California \*\*Solar:\*\* Pasadena/Southern California \*\*Grid load:\*\* California ISO \*\*DLR weather:\*\* Pasadena/Southern California  Other countries can later be used as independent sensitivity tests.  ---  ## Step 5 — Determine the longest reliable ACN period  Do not first decide that the study will use exactly 2019–2021.  Instead:  1. Query the current ACN API. 2. Determine available sessions by year and month. 3. Count valid sessions per month. 4. Identify gaps. 5. Determine changes in station availability. 6. Identify abnormal periods. 7. Select the longest defensible period.  Prefer:  [ \boxed{\geq 1\text{ complete year}} ]  and, if available:  [ \boxed{2-3\text{ years}} ]  One year at 15-minute resolution gives:  [ 365\times24\times4=35,040 ]  time steps.  That is vastly stronger than the current 672 samples.  ---  ## Step 6 — Re-download ACN EV data from the official current API  This is important because the existing May-2019 EV profile showed inconsistencies.  Download the raw information required to reconstruct EV charging:  \`\`\` session\_id station\_id connection\_time disconnect\_time done\_charging\_time energy\_delivered chargingCurrent pilotSignal userInputs  \`\`\`  Do not use interpolated charging power from the existing \`ev\_profile.csv\`.  Reconstruct it.  ---  ## Step 7 — Perform basic EV-session cleaning  Reject or flag sessions with:  \`\`\` disconnect\_time < connection\_time energy\_delivered < 0 missing session\_id duplicate session\_id invalid timestamp negative charging current unrealistic charging duration  \`\`\`  Do not silently remove records.  Create:  \`ev\_quality\_flags.csv\`  containing the reason every rejected or questionable record was flagged.  ---  ## Step 8 — Reconstruct 15-minute EV charging correctly  Generate the aggregate EV load directly from the underlying charging-current/time-series records.  For every 15-minute interval:  # [ P\\\_{EV}(t)  \sum\\\_{i=1}^{N\\\_t}P\\\_{EV,i}(t) ]  Calculate:  \`\`\` ev\_power\_kw ev\_energy\_kwh connected\_ev\_count charging\_ev\_count arrivals departures  \`\`\`  Never use linear interpolation across intervals where no EV is connected.  Enforce:  [ N\\\_{charging}>0 \Rightarrow N\\\_{connected}>0 ]  and:  [ N\\\_{connected}=0 \Rightarrow P\\\_{EV}=0 ]  unless a documented measurement exception exists.  ---  ## Step 9 — Validate EV energy conservation  For every session:  # [ E\\\_i^{reconstructed}  \sum\\\_t P\\\_i(t)\Delta t ]  Compare with reported:  [ E\\\_i^{reported} ]  Then calculate:  [ Error\\\_i= \frac{|E\\\_i^{reconstructed}-E\\\_i^{reported}|} {E\\\_i^{reported}}\times100 ]  Recommended objective:  \*\*median error very close to zero\*\*  and approximately:  [ \boxed{<1%} ]  where measurement resolution permits.  Investigate every major discrepancy.  Also verify aggregate energy:  [ \sum E\\\_{interval} \approx \sum E\\\_{sessions} ]  after accounting for sessions crossing dataset boundaries.  ---  ## Step 10 — Keep measured and assumed EV variables separate  Do not mix assumptions with observations.  Use names such as:  \`\`\` measured\_energy\_delivered\_kwh measured\_connection\_time measured\_charging\_current\_a  derived\_ev\_power\_kw derived\_session\_duration\_h  assumed\_battery\_capacity\_kwh assumed\_initial\_soc assumed\_target\_soc assumed\_v2g\_eligibility  \`\`\`  This is particularly important for battery SOC.  Do not call estimated SOC “measured SOC”.  ---  ## Step 11 — Download matching NSRDB weather and solar data  Use coordinates corresponding to the selected Southern California location.  Acquire at least:  \`\`\` timestamp air\_temperature wind\_speed wind\_direction GHI DNI DHI surface\_pressure relative\_humidity  \`\`\`  If 5-minute NSRDB observations/products are available for the selected period, use them.  Do not interpolate hourly weather to 15 minutes if higher-resolution data are available.  ---  ## Step 12 — Validate weather independently with NOAA  Select the nearest technically appropriate NOAA station.  Download overlapping:  \`\`\` temperature wind\_speed wind\_direction pressure wind\_gust  \`\`\`  NSRDB remains the continuous primary meteorological driver.  NOAA becomes an independent validation source.  Calculate, where appropriate:  [ RMSE ]  [ MAE ]  [ Bias ]  [ R^2 ]  for temperature and wind.  For wind direction use circular statistics rather than ordinary linear error where possible.  ---  ## Step 13 — Perform meteorological quality control  Check:  \`\`\` duplicate timestamps missing timestamps negative wind speed wind direction outside 0–360° unrealistic temperature negative nighttime irradiance impossible irradiance pressure anomalies long constant-value periods  \`\`\`  Every corrected value must be traceable.  Create:  \`weather\_qc\_report.csv\`  ---  ## Step 14 — Convert all datasets to the same timezone  Keep two timestamps:  \`\`\` timestamp\_utc timestamp\_local  \`\`\`  Internally use:  [ \boxed{\text{UTC}} ]  for synchronization.  Preserve local time for interpreting EV behaviour and seasons.  This prevents daylight-saving-time errors.  ---  ## Step 15 — Resample everything to exactly 15 minutes  The final operational time base remains:  [ \Delta t=15\text{ min} ]  For 5-minute meteorological data, aggregate appropriately.  Examples:  Temperature:  [ T\\\_{15}=\operatorname{mean}(T\\\_5) ]  Wind speed:  [ V\\\_{15}=\operatorname{mean}(V\\\_5) ]  GHI:  use correct irradiance/energy aggregation rather than blindly summing instantaneous power values.  EV energy:  [ E\\\_{15}= \sum E\\\_{subinterval} ]  Grid load:  use time-weighted aggregation or carefully justified interpolation if the original resolution is coarser.  Document the method variable by variable.  ---  ## Step 16 — Download geographically consistent California system demand  Replace German demand in the primary experiment.  Use:  \*\*EIA-930 California ISO / CISO\*\*  and supplement with CAISO data where useful.  Store:  \`\`\` system\_load\_mw load\_forecast\_mw net\_interchange\_mw solar\_generation\_mw wind\_generation\_mw  \`\`\`  where available and required.  ---  ## Step 17 — Build a proper PV model  Do not continue using only:  [ PV\\\_{pu}=GHI/1000. ]  Use:  \`\`\` GHI DNI DHI ambient temperature wind speed tilt azimuth module characteristics inverter characteristics system losses  \`\`\`  Calculate:  [ G\\\_{POA} ]  then cell/module temperature:  [ T\\\_c=f(T\\\_a,G\\\_{POA},V\\\_w) ]  and:  [ P\\\_{DC}=f(G\\\_{POA},T\\\_c) ]  then:  [ P\\\_{AC}=\eta\\\_{inv}P\\\_{DC} ]  with clipping and relevant losses.  The output should include:  \`\`\` pv\_available\_kw pv\_dc\_kw pv\_ac\_kw pv\_curtailment\_possible\_kw  \`\`\`  ---  ## Step 18 — Validate the PV model  Check:  [ P\\\_{PV}=0 ]  during nighttime.  Verify:  [ 0\leq P\\\_{PV}\leq P\\\_{rated} ]  unless documented inverter oversizing permits a different relationship.  Plot representative:  - winter day; - summer day; - cloudy day; - clear day; - highly variable day.  Inspect the curves visually.  ---  ## Step 19 — Calculate DLR from raw weather yourself  This is critical.  Use IEEE Std 738 and your selected conductor parameters.  At each timestamp solve the heat balance:  # [ q\\\_c(t)+q\\\_r(t)  q\\\_s(t)+I^2(t)R(T\\\_c) ]  therefore:  # [ I\\\_{DLR}(t)  \sqrt{ \frac{q\\\_c(t)+q\\\_r(t)-q\\\_s(t)} {R(T\\\_c)} } ]  Inputs should include:  \`\`\` ambient temperature wind speed wind direction solar conditions conductor diameter emissivity absorptivity conductor resistance maximum conductor temperature  \`\`\`  Do not rely on the old precomputed DLR series for the primary experiment.  ---  ## Step 20 — Calculate a genuine Static Thermal Rating  Create an independent conventional rating:  # [ I\\\_{STR}  f(T\\\_{design},V\\\_{wind,design},G\\\_{design},T\\\_{c,max}) ]  using documented conservative design weather.  The STR must not be:  [ \min(I\\\_{DLR}) ]  from your evaluation period.  That is one of the most important scientific corrections.  ---  ## Step 21 — Add seasonal ratings  Create:  \`\`\` winter\_static\_rating spring\_static\_rating summer\_static\_rating autumn\_static\_rating  \`\`\`  using defensible seasonal assumptions.  Your main comparison becomes:  [ \boxed{ STR \quad vs\quad Seasonal\ Rating \quad vs\quad DLR } ]  This is much more powerful scientifically.  ---  ## Step 22 — Independently verify DLR calculations  Select approximately 20–50 representative timestamps covering:  - cold/high wind; - cold/low wind; - normal conditions; - hot/high wind; - hot/low wind; - extreme heat; - high solar; - low solar.  Manually or independently recompute conductor ampacity.  Ensure:  [ Error\\\_{DLR} ]  is negligible between implementations.  ---  ## Step 23 — Create one master dataset  Join everything strictly by timestamp.  Recommended fields:  \`\`\` timestamp\_utc timestamp\_local  year month season weekday hour  ev\_power\_kw ev\_energy\_kwh ev\_connected\_count ev\_arrivals ev\_departures  temperature\_c wind\_speed\_ms wind\_direction\_deg wind\_gust\_ms ghi\_wm2 dni\_wm2 dhi\_wm2 pressure\_pa relative\_humidity  pv\_available\_kw pv\_ac\_kw  caiso\_load\_mw  str\_ampacity\_a seasonal\_ampacity\_a dlr\_ampacity\_a  str\_mva seasonal\_rating\_mva dlr\_mva  temperature\_regime wind\_regime solar\_regime ev\_regime critical\_weather\_flag  quality\_flag  \`\`\`  ---  ## Step 24 — Audit timestamp coverage  For every expected 15-minute interval verify exactly one record exists.  Acceptance target:  [ \boxed{Duplicate\ timestamps=0} ]  and preferably:  [ \boxed{Unexplained\ missing\ timestamps=0} ]  Every unavoidable gap must be identified explicitly.  ---  ## Step 25 — Define seasons objectively  For Northern Hemisphere Southern California:  \`\`\` Winter: December–February Spring: March–May Summer: June–August Autumn: September–November  \`\`\`  Report the number of observations in each season.  ---  ## Step 26 — Define temperature regimes statistically  Using the complete historical dataset, calculate:  [ P\\\_{5},P\\\_{10},P\\\_{25},P\\\_{50},P\\\_{75},P\\\_{90},P\\\_{95},P\\\_{99} ]  Then define, for example:  \`\`\` Very cold: ≤ P05 Cold: P05–P25 Normal: P25–P75 Hot: P75–P95 Extreme hot: ≥ P95 Severe extreme: ≥ P99  \`\`\`  This prevents arbitrary scenario selection.  ---  ## Step 27 — Define wind regimes  For example:  \`\`\` Very low wind: ≤P05 Low wind: ≤P10 Normal wind: P10–P90 High wind: ≥P90 Extreme high wind: ≥P99  \`\`\`  Low-wind periods are especially important for DLR.  ---  ## Step 28 — Define solar regimes  Use daily PV energy and instantaneous PV power.  For example:  \`\`\` Low PV day ≤ P10 daily energy Normal PV P25–P75 High PV ≥ P90 Extreme PV ≥ P99  \`\`\`  Also calculate ramping:  [ Ramp\\\_{PV,t}=P\\\_{PV,t}-P\\\_{PV,t-1} ]  Identify extreme PV ramp events.  ---  ## Step 29 — Define EV-demand regimes  Use:  \`\`\` 15-minute EV power daily EV energy number of connected EVs arrival count departure count  \`\`\`  Classify:  \`\`\` Low EV ≤P10 Normal EV P25–P75 High EV ≥P90 Extreme EV ≥P99  \`\`\`  Also distinguish:  \`\`\` weekday weekend holiday  \`\`\`  where reliable calendar metadata are available.  ---  ## Step 30 — Identify compound extreme events  This is particularly important for EPSR.  Create flags such as:  ### Extreme thermal stress  [ T\\\_a\geq P\\\_{95} ]  AND  [ V\\\_w\leq P\\\_{10} ]  ### Extreme thermal + solar stress  [ T\\\_a\geq P\\\_{95} ]  AND  [ V\\\_w\leq P\\\_{10} ]  AND  [ GHI\geq P\\\_{75} ]  ### Grid-demand stress  [ EV\geq P\\\_{90} ]  AND  [ PV\leq P\\\_{10} ]  ### Reverse-flow stress  [ PV\geq P\\\_{90} ]  AND  [ EV\leq P\\\_{25} ]  These are much more meaningful than randomly choosing difficult days.  ---  ## Step 31 — Produce a correlation and dependence audit  Calculate associations among:  [ EV,\ PV,\ T,\ wind,\ DLR,\ system\ load ]  But do not assume independence.  Investigate:  - temperature–DLR; - wind–DLR; - solar–DLR; - temperature–system load; - time-of-day–EV; - PV–net load.  This helps justify stochastic scenario construction.  ---  ## Step 32 — Split forecasting data chronologically  Never randomly shuffle time-series samples.  Use a chronological split such as:  [ 70%\ training ]  [ 15%\ validation ]  [ 15%\ test ]  or another justified temporal scheme.  The final test set must remain completely untouched during model development.  ---  ## Step 33 — Ensure every season appears in evaluation  A single final 33.75-hour period is no longer sufficient.  Evaluation should intentionally include:  - winter; - spring; - summer; - autumn; - extreme heat; - low wind; - high wind; - high EV; - low PV; - high PV.  ---  ## Step 34 — Benchmark forecasting models properly  Do not automatically use LSTM.  For every variable compare against simple baselines.  EV:  \`\`\` Persistence Seasonal persistence Historical mean LSTM possibly another suitable model  \`\`\`  PV:  \`\`\` Persistence Clear-sky/physical baseline where appropriate LSTM or another selected model  \`\`\`  Select the model that performs best on validation data.  If persistence beats LSTM, use persistence.  ---  ## Step 35 — Use multiple forecasting metrics  Report:  [ RMSE ]  [ MAE ]  [ NRMSE ]  and appropriate statistical comparisons.  Also examine performance separately for:  - normal periods; - extreme conditions; - different seasons.  Average RMSE alone is not enough.  ---  ## Step 36 — Calibrate uncertainty scenarios  Your previous nominal 90% intervals substantially under-covered EV and PV.  The revised uncertainty framework should target approximately calibrated coverage.  For nominal:  [ 90% ]  evaluate observed empirical coverage independently.  Report:  \`\`\` nominal coverage empirical coverage interval width coverage by season coverage during extremes  \`\`\`  Do not claim probabilistic guarantees unless calibration supports them.  ---  ## Step 37 — Perform scenario-number sensitivity  Continue testing:  [ 5,\quad10,\quad20 ]  but consider adding:  [ 30\text{ or }50 ]  for selected periods if computationally practical.  Evaluate:  \`\`\` solution quality solve time constraint violations EV service DLR utilisation  \`\`\`  Select the final number based on convergence and computational burden.  ---  ## Step 38 — Perform objective-weight sensitivity  Vary important SMPC weights systematically.  Particularly:  \`\`\` EV unserved-energy penalty PV curtailment penalty thermal penalty voltage penalty energy cost ramping penalty  \`\`\`  Show that the main DLR conclusion does not disappear because of one arbitrary weight choice.  ---  ## Step 39 — Correct the EV service formulation  Do not allow the optimized controller to serve dramatically less EV energy than uncontrolled charging without strong justification.  Test:  [ E\\\_i(t\\\_{departure}) \geq E\\\_i^{required} ]  as a hard constraint where feasible.  If slack is retained:  ## [ E\\\_i^{required}  E\\\_i^{served} \leq s\\\_i ]  report slack explicitly.  Compare multiple MPC horizons:  \`\`\` 2 h 4 h 8 h possibly 12 h  \`\`\`  ---  ## Step 40 — Build representative simulation periods  You do not necessarily need to execute expensive SMPC simulations across every 15-minute period of three years.  Use the full historical dataset for statistical characterization and forecasting.  Then select representative weeks such as:  \`\`\` normal winter cold/high-wind winter low-wind winter  normal spring high-PV spring  normal summer extreme-heat summer extreme-heat + low-wind summer high-EV summer  normal autumn low-solar/high-EV autumn high-wind autumn  extreme EV week extreme PV week extreme compound-weather week  \`\`\`  Approximately 12–16 representative periods could be highly defensible if selected transparently.  ---  ## Step 41 — Separate selection and testing  Do not select “interesting” extreme periods after looking at simulation outcomes.  Select periods solely from dataset statistics first.  Freeze:  \`selected\_periods.csv\`  before running the final MATPOWER/OpenDSS simulations.  This prevents selection bias.  ---  ## Step 42 — Run STR, seasonal-rating and DLR cases identically  For every selected operating period run:  [ STR ]  [ Seasonal\ Rating ]  [ DLR ]  with identical:  \`\`\` EV data PV data grid load controller structure forecast information random seeds objective weights initial conditions  \`\`\`  Only the line-rating strategy should change in the central causal comparison.  ---  ## Step 43 — Run AC validation  Do not validate only the easiest points.  At minimum include:  - highest loading; - lowest DLR; - maximum EV; - maximum PV; - extreme heat; - low-wind periods; - large power-transfer periods.  Where feasible increase ACOPF validation substantially beyond the previous 54 selected points.  ---  ## Step 44 — Add N-1 security tests  Select important contingencies such as:  \`\`\` critical transmission-line outage transformer outage generator outage  \`\`\`  Compare:  [ STR,\ Seasonal,\ DLR ]  under those contingencies.  This will make the manuscript much more power-system oriented.  ---  ## Step 45 — Use an external EV dataset only for robustness  After the California study is complete, optionally use:  \*\*Optimise Prime\*\*  or an appropriate Norwegian EV charging dataset.  Do not merge these observations into the California timeline.  Use them as:  [ \boxed{\text{external behavioural robustness tests}} ]  For example:  > Does the proposed EV scheduling framework still perform reasonably when EV arrival and charging distributions come from an independent fleet?  ---  ## Step 46 — Produce automatic quality-control reports  Your final processing script should generate:  \`\`\` missing\_values\_report.csv duplicate\_report.csv timestamp\_report.csv ev\_energy\_balance\_report.csv weather\_validation\_report.csv pv\_validation\_report.csv dlr\_validation\_report.csv outlier\_report.csv source\_manifest.csv dataset\_summary.csv  \`\`\`  Nothing should rely purely on manual inspection.  ---  ## Step 47 — Create automatic physical sanity tests  Your Python pipeline should fail if any of these occur:  \`\`\` EV power < 0 PV power < 0 PV > physical maximum without explanation connected EV = 0 but charging power > 0 wind speed < 0 wind direction outside valid range DLR <= 0 duplicate timestamps missing mandatory timestamps invalid branch rating NaN in critical variables infinite values  \`\`\`  This is effectively a test suite for the research data.  ---  ## Step 48 — Visually inspect the data  Automated checks are not enough.  Plot:  1. full-year temperature; 2. full-year wind; 3. full-year PV; 4. full-year EV; 5. full-year DLR; 6. representative winter week; 7. representative summer week; 8. extreme heat event; 9. low-wind event; 10. extreme EV event.  Many errors are easier to identify visually than statistically.  ---  ## Step 49 — Freeze a versioned final dataset  When all checks pass, create:  \`\`\` master\_dataset\_v1.0.csv  \`\`\`  Never change it silently.  If corrections occur:  \`\`\` master\_dataset\_v1.1.csv  \`\`\`  and maintain:  \`CHANGELOG.md\`  ---  ## Step 50 — Freeze the simulation configuration  Create a machine-readable configuration such as:  \`\`\` config\_final.json  \`\`\`  containing:  \`\`\` dataset version date ranges PCC bus DLR branch conductor EV scaling PV capacity MPC horizon scenario count random seeds objective weights voltage limits solver tolerances STR assumptions seasonal-rating assumptions  \`\`\`  This prevents accidental mismatch between reported and simulated results.  ---  # Final acceptance gates  I would not begin the final EPSR simulations until the dataset satisfies these checks:  \*\*Temporal integrity\*\*  [ Duplicates=0 ]  [ Unexplained\ missing\ intervals=0 ]  \*\*EV integrity\*\*  [ Connected=0\Rightarrow EV\ power=0 ]  Energy accounting closes within a predefined tolerance.  \*\*Geographic integrity\*\*  Primary EV, weather, solar and system-load data describe the same regional system.  \*\*Weather integrity\*\*  No impossible values and NSRDB has been checked against independent observational data.  \*\*PV integrity\*\*  [ 0\leq P\\\_{PV}\leq P\\\_{physical,max} ]  with physically appropriate seasonal variation.  \*\*DLR integrity\*\*  DLR is independently computed from meteorological inputs using IEEE 738.  \*\*Benchmark integrity\*\*  STR is independently calculated and is not the minimum DLR from the experiment.  \*\*Seasonal integrity\*\*  Winter, spring, summer and autumn are represented.  \*\*Extreme-condition integrity\*\*  Extreme heat, low/high wind, extreme EV and solar conditions are represented.  \*\*Forecast integrity\*\*  Forecast models are selected based on validation—not because LSTM is more sophisticated.  \*\*Uncertainty integrity\*\*  Prediction/scenario coverage is explicitly calibrated and tested.  \*\*Reproducibility\*\*  Raw data + processing code + configuration + seeds + final dataset version are preserved.  ---  # Recommended final research pipeline  The complete pipeline should become:  \`\`\` Caltech ACN raw EV data           ↓ EV cleaning and reconstruction           ↓ NREL NSRDB weather + solar           ↓ NOAA weather validation           ↓ CAISO/EIA grid demand           ↓ 15-minute synchronization           ↓ Physical PV calculation           ↓ IEEE-738 STR calculation           ↓ IEEE-738 seasonal rating           ↓ IEEE-738 DLR calculation           ↓ Master historical dataset           ↓ Quality-control tests           ↓ Season/extreme-event classification           ↓ Train/validation/test split           ↓ Forecast benchmarking           ↓ Calibrated uncertainty scenarios           ↓ SMPC           ↓ OpenDSS           ↓ PCC exchange           ↓ MATPOWER           ↓ ACOPF           ↓ N-1 tests           ↓ Statistical comparison           ↓ EPSR results  \`\`\`  ## Most important first action  Before doing any new simulation, I recommend beginning with only \*\*three tasks\*\*:  \*\*First:\*\* re-download and reconstruct the ACN EV data correctly.  \*\*Second:\*\* obtain matching Southern California NSRDB weather/solar data.  \*\*Third:\*\* create the first clean synchronized 15-minute master dataset.  Only after these three pass the quality checks should we move to PV, STR/DLR calculation and eventually MATPOWER/OpenDSS.  This prevents us from spending days rerunning simulations only to discover later that the input data contain another problem.