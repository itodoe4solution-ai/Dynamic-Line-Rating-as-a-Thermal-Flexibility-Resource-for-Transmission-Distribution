# Phase-2 EPSR Simulation Checklist

After the input dataset passes the QC gate:

1. Freeze `selected_periods.csv` before simulation.
2. Run STR, seasonal and DLR cases with identical exogenous data and common seeds.
3. Replace/augment deadline-only EV service with a hard departure-energy formulation where feasible.
4. Compare MPC horizons: 2 h, 4 h, 8 h, optionally 12 h.
5. Perform objective-weight sensitivity.
6. Perform scenario-count sensitivity: 5, 10, 20, optionally 30/50.
7. Select the best EV/PV forecast model by validation performance rather than model complexity.
8. Report uncertainty coverage by season and extreme regime.
9. Add additional monitored constraints/branches if feasible.
10. Expand ACOPF validation beyond only peak-loading samples.
11. Add selected N-1 line/transformer/generator contingencies.
12. Use paired common-seed statistics and confidence intervals.
13. Keep claims limited to what the network and security validation actually support.
