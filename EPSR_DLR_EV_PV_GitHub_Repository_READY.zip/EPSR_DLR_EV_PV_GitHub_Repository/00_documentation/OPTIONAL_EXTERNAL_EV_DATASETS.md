# Optional external EV robustness datasets

These are **not** merged into the California primary timeline.

## Norway residential EV dataset (recommended first external test)

Zenodo v2 record: https://zenodo.org/records/13896176

- over 35,000 residential charging sessions;
- 267 user IDs;
- 12 locations;
- plug-in/plug-out time and charged energy;
- companion predicted battery/SoC/power fields and hourly data.

Download with:

```powershell
python scripts/16_optional_download_norway_ev.py
```

## Optimise Prime commercial-fleet data

London Datastore: https://data.london.gov.uk/dataset/optimise-prime-e16lp

The project reports data from more than 6,000 commercial EVs across home, depot and private-hire trial workstreams. Use it only as an independently labelled commercial-fleet robustness study because it is a different country, climate and user population.
