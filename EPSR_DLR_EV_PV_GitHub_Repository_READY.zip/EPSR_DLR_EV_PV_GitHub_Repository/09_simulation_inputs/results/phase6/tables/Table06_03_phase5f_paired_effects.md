# Paired STR–DLR effects after voltage control

 control_case                                            metric  pairs  mean_DLR_minus_STR  median_DLR_minus_STR  min_DLR_minus_STR  max_DLR_minus_STR
     BASELINE            distribution_voltage_violation_feeders     17            0.000000              0.000000           0.000000           0.000000
     BASELINE               ieee118_bus_voltage_violation_count     17            0.000000              0.000000           0.000000           0.000000
     BASELINE          ieee118_selected_corridor_max_loading_pu     17           -0.323308             -0.358051          -0.613949          -0.116442
     BASELINE ieee118_selected_corridor_thermal_violation_count     17           -0.588235             -1.000000          -1.000000           0.000000
     BASELINE                   weighted_bus_voltage_violations     17           30.411765              0.000000         -70.000000         199.000000
         OLTC            distribution_voltage_violation_feeders     17            0.000000              0.000000           0.000000           0.000000
         OLTC               ieee118_bus_voltage_violation_count     17            0.000000              0.000000           0.000000           0.000000
         OLTC          ieee118_selected_corridor_max_loading_pu     17           -0.323308             -0.358051          -0.613949          -0.116442
         OLTC ieee118_selected_corridor_thermal_violation_count     17           -0.588235             -1.000000          -1.000000           0.000000
         OLTC                   weighted_bus_voltage_violations     17            0.000000              0.000000           0.000000           0.000000
OLTC_VOLT_VAR            distribution_voltage_violation_feeders     17            0.000000              0.000000           0.000000           0.000000
OLTC_VOLT_VAR               ieee118_bus_voltage_violation_count     17            0.000000              0.000000           0.000000           0.000000
OLTC_VOLT_VAR          ieee118_selected_corridor_max_loading_pu     17           -0.291402             -0.299485          -0.576019          -0.089048
OLTC_VOLT_VAR ieee118_selected_corridor_thermal_violation_count     17           -0.647059             -1.000000          -1.000000           0.000000
OLTC_VOLT_VAR                   weighted_bus_voltage_violations     17            0.000000              0.000000           0.000000           0.000000
     VOLT_VAR            distribution_voltage_violation_feeders     17            1.058824              0.000000          -9.000000          18.000000
     VOLT_VAR               ieee118_bus_voltage_violation_count     17            0.000000              0.000000           0.000000           0.000000
     VOLT_VAR          ieee118_selected_corridor_max_loading_pu     17           -0.291148             -0.298150          -0.576019          -0.089048
     VOLT_VAR ieee118_selected_corridor_thermal_violation_count     17           -0.647059             -1.000000          -1.000000           0.000000
     VOLT_VAR                   weighted_bus_voltage_violations     17           58.647059              0.000000        -168.000000         407.000000

**Note.** Negative corridor-loading effects indicate lower loading under DLR.
