# Phase-5 AC-security validation summary

stage                              model  evaluations  successful_or_converged  execution_exceptions  voltage_clean_evaluations  thermal_clean_evaluations  combined_security_clean_evaluations  success_fraction  combined_security_clean_fraction
   5A                       IEEE118_ACPF           34                       34                     0                          0                       22.0                                    0          1.000000                          0.000000
   5A         IEEE33_exact_BFS_0.95_1.05           34                       34                     0                          2                        NaN                                    2          1.000000                          0.058824
   5B                      IEEE118_ACOPF           34                       28                     0                         28                       28.0                                   28          0.823529                          0.823529
   5C                    IEEE118_N1_ACPF          170                      170                     0                          0                      122.0                                    0          1.000000                          0.000000
   5D  IEEE39_ACPF_normalized_robustness           34                       34                     0                          0                       34.0                                    0          1.000000                          0.000000
   5D IEEE39_ACOPF_normalized_robustness           34                       34                     0                         34                       34.0                                   34          1.000000                          1.000000

**Note.** Computational success is distinct from voltage/thermal security compliance.
