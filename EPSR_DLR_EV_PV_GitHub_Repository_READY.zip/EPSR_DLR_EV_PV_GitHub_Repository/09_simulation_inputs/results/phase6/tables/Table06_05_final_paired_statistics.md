# Final paired validation statistics

          section stage  control_case                                            metric  n_pairs  mean_DLR_minus_STR  median_DLR_minus_STR  min_DLR_minus_STR  max_DLR_minus_STR  fraction_DLR_lower
Phase5_validation    5A                                acpf_bus_voltage_violation_count       17            0.000000              0.000000           0.000000           0.000000            0.000000
Phase5_validation    5A                           acpf_selected_corridor_max_loading_pu       17           -0.323308             -0.358051          -0.613949          -0.116442            1.000000
Phase5_validation    5B                               acopf_bus_voltage_violation_count       17           -1.882353              0.000000          -9.000000           0.000000            0.352941
Phase5_validation    5B                          acopf_selected_corridor_max_loading_pu       17           -0.242281             -0.227757          -0.484452          -0.038600            1.000000
Phase5_validation    5C                                  n1_bus_voltage_violation_count       85            0.000000              0.000000           0.000000           0.000000            0.000000
Phase5_validation    5C                   n1_remaining_selected_corridor_max_loading_pu       85           -0.297316             -0.313578          -0.595411          -0.100183            1.000000
Phase5_validation    5D                     ieee39_acopf_selected_branch_max_loading_pu       17           -0.291491             -0.318792          -0.496074          -0.128534            1.000000
Phase5_validation    5D                         ieee39_acpf_bus_voltage_violation_count       17            0.000000              0.000000          -1.000000           1.000000            0.058824
Phase5_validation    5D                      ieee39_acpf_selected_branch_max_loading_pu       17           -0.247908             -0.268512          -0.420629          -0.112220            1.000000
          Phase5F    5F      BASELINE            distribution_voltage_violation_feeders       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F      BASELINE               ieee118_bus_voltage_violation_count       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F      BASELINE          ieee118_selected_corridor_max_loading_pu       17           -0.323308             -0.358051          -0.613949          -0.116442            1.000000
          Phase5F    5F      BASELINE ieee118_selected_corridor_thermal_violation_count       17           -0.588235             -1.000000          -1.000000           0.000000            0.588235
          Phase5F    5F      BASELINE                   weighted_bus_voltage_violations       17           30.411765              0.000000         -70.000000         199.000000            0.176471
          Phase5F    5F          OLTC            distribution_voltage_violation_feeders       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F          OLTC               ieee118_bus_voltage_violation_count       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F          OLTC          ieee118_selected_corridor_max_loading_pu       17           -0.323308             -0.358051          -0.613949          -0.116442            1.000000
          Phase5F    5F          OLTC ieee118_selected_corridor_thermal_violation_count       17           -0.588235             -1.000000          -1.000000           0.000000            0.588235
          Phase5F    5F          OLTC                   weighted_bus_voltage_violations       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F OLTC_VOLT_VAR            distribution_voltage_violation_feeders       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F OLTC_VOLT_VAR               ieee118_bus_voltage_violation_count       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F OLTC_VOLT_VAR          ieee118_selected_corridor_max_loading_pu       17           -0.291402             -0.299485          -0.576019          -0.089048            1.000000
          Phase5F    5F OLTC_VOLT_VAR ieee118_selected_corridor_thermal_violation_count       17           -0.647059             -1.000000          -1.000000           0.000000            0.647059
          Phase5F    5F OLTC_VOLT_VAR                   weighted_bus_voltage_violations       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F      VOLT_VAR            distribution_voltage_violation_feeders       17            1.058824              0.000000          -9.000000          18.000000            0.058824
          Phase5F    5F      VOLT_VAR               ieee118_bus_voltage_violation_count       17            0.000000              0.000000           0.000000           0.000000            0.000000
          Phase5F    5F      VOLT_VAR          ieee118_selected_corridor_max_loading_pu       17           -0.291148             -0.298150          -0.576019          -0.089048            1.000000
          Phase5F    5F      VOLT_VAR ieee118_selected_corridor_thermal_violation_count       17           -0.647059             -1.000000          -1.000000           0.000000            0.647059
          Phase5F    5F      VOLT_VAR                   weighted_bus_voltage_violations       17           58.647059              0.000000        -168.000000         407.000000            0.235294

**Note.** Values are consolidated directly from frozen Phase-5/5F paired outputs.
