# Phase 6 — Publication Evidence Draft

## Central finding

The final evidence supports a bounded interpretation of dynamic line rating
(DLR) as a **thermal-flexibility resource** rather than a standalone
voltage-control mechanism. The stochastic scheduling, AC validation,
contingency analysis, cross-network robustness test and voltage-control
sensitivity collectively separate thermal flexibility from voltage-security
management.

## AC-security validation

The mean paired DLR-minus-STR maximum-loading effects extracted from the frozen
Phase-5 evidence are:

- IEEE-118 ACPF: -0.323 pu.
- IEEE-118 ACOPF: -0.242 pu.
- Selected IEEE-118 N-1 contingencies: -0.297 pu.
- Normalized IEEE-39 ACPF robustness test: -0.248 pu.

A negative value indicates lower selected-corridor or selected-branch loading
under DLR relative to STR. These results must be reported as stress-targeted
validation evidence, not as an annual exhaustive AC guarantee.

## Phase-5F distribution voltage-control sensitivity

OLTC achieved a minimum grouped IEEE-33 voltage-clean fraction of
1.000 across the selected operating states. Volt-VAR alone
achieved a maximum grouped voltage-clean fraction of
0.091, showing that reactive support reduced voltage
severity but did not universally restore the 0.95–1.05 pu criterion.

The combined OLTC + Volt-VAR strategy achieved a minimum grouped IEEE-33
voltage-clean fraction of 1.000. Importantly, the DLR
thermal advantage remained after combined voltage control: the mean paired
DLR-minus-STR selected-corridor loading effect was
-0.291 pu.

Under the high-stress combined-control condition, the IEEE-118 thermal-clean
fraction was 1.000 for DLR and
0.364 for STR.

## Interpretation

The results support complementary roles:

1. DLR expands thermal operating flexibility.
2. OLTC provides the dominant distribution-voltage correction in the selected
   Phase-5F sensitivity.
3. Volt-VAR provides additional voltage margin and reactive support, but does
   not replace OLTC in the tested conditions.
4. Transmission-level voltage/security issues require AC redispatch,
   generator/reactive-power control, transformer control, FACTS or other
   transmission-security mechanisms as appropriate.

## Publication boundary

Do not state that DLR guarantees voltage security. Do not state that the
stress-targeted AC validation proves annual security. Do not present the
normalized IEEE-39 test as physical conductor-specific DLR.
