# Abstract Evidence Notes

Use the following evidence when rewriting the abstract:

- Phase-4 true receding-horizon analysis distinguishes nominal operating
  headroom from high-stress feasibility restoration.
- Phase-5 AC validation preserves the direction of the DLR thermal advantage.
- IEEE-118 ACPF mean paired loading effect:
  -0.323 pu.
- IEEE-118 ACOPF mean paired loading effect:
  -0.242 pu.
- Selected N-1 mean paired loading effect:
  -0.297 pu.
- Normalized IEEE-39 ACPF mean paired loading effect:
  -0.248 pu.
- OLTC achieved a minimum grouped IEEE-33 voltage-clean fraction of
  1.000.
- Combined OLTC + Volt-VAR preserved the DLR loading advantage:
  -0.291 pu mean paired DLR-minus-STR loading.
- DLR should be described primarily as a thermal-flexibility resource.
- Do not describe the annual EV series as one year of fully measured
  15-minute charging demand.
