# Limitations and Claim Boundaries

1. The annual EV series is an empirical reconstruction based on observed
   charging-session arrival/departure and delivered-energy information.
   It should not be described as one year of fully measured 15-minute
   charging-current demand.

2. The main study is a benchmark-system study driven by Southern California
   data. It is not a calibrated physical model of the California grid.

3. The frozen IEEE-118 DLR corridors use a controlled common conductor/weather
   basis for comparison rather than a claim about actual IEEE-118 hardware.

4. Phase-4 distribution-voltage screening is reduced-order. Phase 5/5F
   provides the stricter exact IEEE-33 voltage sensitivity used for the final
   voltage-control interpretation.

5. Phase-5 AC validation is stress-targeted and therefore should not be
   described as exhaustive annual AC validation.

6. The N-1 validation covers the selected frozen corridor contingencies rather
   than every possible IEEE-118 outage.

7. The IEEE-39 robustness experiment transfers a dimensionless DLR/STR
   uplift ratio. It is not conductor-specific IEEE-39 DLR.

8. Phase-5F OLTC and Volt-VAR controls are sensitivity assumptions rather than
   field-calibrated device-control trajectories. The state-wise OLTC analysis
   does not establish real mechanical tap-switching duty over a chronological
   year.

9. DLR is primarily a thermal-flexibility resource. Voltage security must be
   treated separately using explicit distribution and/or transmission voltage
   controls.

10. Phase 6 must not be used to retrospectively retune the frozen Phase-4 or
    Phase-5 parameters.
