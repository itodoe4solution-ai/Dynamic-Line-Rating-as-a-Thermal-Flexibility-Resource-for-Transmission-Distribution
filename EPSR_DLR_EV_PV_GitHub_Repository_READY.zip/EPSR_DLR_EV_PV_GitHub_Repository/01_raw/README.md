# Raw data are not redistributed in this repository

The study uses third-party source data from the providers below. To keep the public repository compact and to respect each provider's distribution/usage terms, the original raw downloads are not included here. Retrieval and processing scripts are included in `scripts/`.

- **Caltech ACN-Data** — EV charging sessions: https://ev.caltech.edu/dataset.html
- **NSRDB GOES CONUS PSM v4** — meteorology and solar irradiance: https://developer.nlr.gov/docs/solar/nsrdb/
- **NOAA/NCEI ISD** — independent weather validation: https://www.ncei.noaa.gov/products/land-based-station/integrated-surface-database
- **EIA-930** — California ISO system-demand chronology: https://www.eia.gov/opendata/

See `00_documentation/data_sources.csv` and `config.yaml` for the study period, geographic reference, resolution, and processing choices. Users who download the source data are responsible for complying with the providers' applicable terms.
