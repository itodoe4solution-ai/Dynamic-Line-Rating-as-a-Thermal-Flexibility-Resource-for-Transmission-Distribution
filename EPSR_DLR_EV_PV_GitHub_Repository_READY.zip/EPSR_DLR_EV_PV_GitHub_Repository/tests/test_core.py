import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from epsr_pipeline.common import load_config
from epsr_pipeline.ev import build_ev_profile_from_jsonl
from epsr_pipeline.dlr import build_dlr, static_rating
from epsr_pipeline.noaa import validate_against_nsrdb
from epsr_pipeline.qc import missing_values_report, timestamp_qc


class CoreTests(unittest.TestCase):
    def test_ev_energy_conservation_and_connection_invariant(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "s.jsonl"
            sess = {
                "sessionID": "s1",
                "connectionTime": "Wed, 01 May 2019 00:05:00 GMT",
                "disconnectTime": "Wed, 01 May 2019 01:05:00 GMT",
                "doneChargingTime": "Wed, 01 May 2019 01:00:00 GMT",
                "kWhDelivered": 6.0,
                "chargingCurrent": {
                    "timestamps": [
                        "Wed, 01 May 2019 00:05:00 GMT",
                        "Wed, 01 May 2019 00:20:00 GMT",
                        "Wed, 01 May 2019 00:35:00 GMT",
                        "Wed, 01 May 2019 00:50:00 GMT",
                    ],
                    "current": [10, 10, 10, 10],
                },
            }
            p.write_text(json.dumps(sess) + "\n", encoding="utf-8")
            start = pd.Timestamp("2019-05-01T00:00:00Z")
            end = pd.Timestamp("2019-05-01T02:00:00Z")
            prof, _, bal = build_ev_profile_from_jsonl(p, start, end, 15)
            self.assertAlmostEqual(prof.ev_energy_kwh.sum(), 6.0, places=10)
            self.assertFalse(((prof.ev_connected_count == 0) & (prof.ev_power_kw > 0)).any())
            self.assertTrue((prof.ev_charging_count <= prof.ev_connected_count).all())
            self.assertAlmostEqual(float(bal.error_percent.dropna().iloc[0]), 0.0, places=10)

    def test_ev_template_fallback_is_used_when_current_trace_missing(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "s.jsonl"
            measured_short = {
                "sessionID": "measured",
                "connectionTime": "Wed, 01 May 2019 00:05:00 GMT",
                "disconnectTime": "Wed, 01 May 2019 01:05:00 GMT",
                "doneChargingTime": "Wed, 01 May 2019 01:00:00 GMT",
                "kWhDelivered": 6.0,
                "chargingCurrent": {
                    "timestamps": [
                        "Wed, 01 May 2019 00:05:00 GMT",
                        "Wed, 01 May 2019 00:20:00 GMT",
                        "Wed, 01 May 2019 00:35:00 GMT",
                        "Wed, 01 May 2019 00:50:00 GMT",
                    ],
                    "current": [10, 10, 10, 10],
                },
            }
            measured_mid = {
                "sessionID": "measured_mid",
                "connectionTime": "Wed, 01 May 2019 02:00:00 GMT",
                "disconnectTime": "Wed, 01 May 2019 04:30:00 GMT",
                "doneChargingTime": "Wed, 01 May 2019 04:15:00 GMT",
                "kWhDelivered": 6.0,
                "chargingCurrent": {
                    "timestamps": [
                        "Wed, 01 May 2019 02:00:00 GMT",
                        "Wed, 01 May 2019 02:30:00 GMT",
                        "Wed, 01 May 2019 03:00:00 GMT",
                        "Wed, 01 May 2019 03:30:00 GMT",
                        "Wed, 01 May 2019 04:00:00 GMT",
                    ],
                    "current": [8, 9, 10, 9, 8],
                },
            }
            fallback = {
                "sessionID": "fallback",
                "connectionTime": "Wed, 01 May 2019 05:00:00 GMT",
                "disconnectTime": "Wed, 01 May 2019 07:30:00 GMT",
                "doneChargingTime": "Wed, 01 May 2019 07:15:00 GMT",
                "kWhDelivered": 3.0,
            }
            p.write_text(
                json.dumps(measured_short) + "\n" + json.dumps(measured_mid) + "\n" + json.dumps(fallback) + "\n",
                encoding="utf-8",
            )
            start = pd.Timestamp("2019-05-01T00:00:00Z")
            end = pd.Timestamp("2019-05-01T08:00:00Z")
            prof, qc, bal = build_ev_profile_from_jsonl(p, start, end, 15)
            self.assertAlmostEqual(prof.ev_energy_kwh.sum(), 15.0, places=10)
            fallback_row = bal.loc[bal.session_id.eq("fallback")].iloc[0]
            self.assertEqual(fallback_row.reconstruction_method, "template_shape")
            self.assertEqual(fallback_row.duration_bucket, "2-4h")
            self.assertEqual(fallback_row.template_bucket, "2-4h")
            self.assertTrue(qc.loc[qc.session_id.eq("fallback"), "reasons"].iloc[0].startswith("energy_only_template_fallback"))

    def test_dlr_positive_and_static_independent(self):
        cfg = load_config()
        idx = pd.date_range("2019-01-01", periods=96, freq="15min", tz="UTC")
        weather = pd.DataFrame({
            "timestamp_utc": idx,
            "temperature_c": 25.0,
            "wind_speed_ms": 2.0,
            "wind_direction_deg": 90.0,
            "ghi_wm2": np.maximum(0, 800 * np.sin(np.linspace(-np.pi/2, 3*np.pi/2, len(idx)))),
            "pressure_pa": 101325.0,
            "relative_humidity_pct": 50.0,
        })
        dlr = build_dlr(weather, cfg)
        self.assertTrue((dlr.dlr_ampacity_a > 0).all())
        sr = static_rating(cfg)
        self.assertGreater(sr["str_ampacity_a"], 0)
        self.assertNotAlmostEqual(sr["str_ampacity_a"], float(dlr.dlr_ampacity_a.min()), places=4)

    def test_timestamp_qc(self):
        start = pd.Timestamp("2019-01-01T00:00:00Z")
        end = pd.Timestamp("2019-01-02T00:00:00Z")
        idx = pd.date_range(start, end - pd.Timedelta(minutes=15), freq="15min", tz="UTC")
        df = pd.DataFrame({"timestamp_utc": idx})
        summary, missing = timestamp_qc(df, start, end, 15)
        self.assertEqual(int(summary.missing_timestamps.iloc[0]), 0)
        self.assertEqual(int(summary.duplicate_timestamp_rows.iloc[0]), 0)
        self.assertTrue(missing.empty)

    def test_missing_values_report_ignores_qc_flags(self):
        df = pd.DataFrame({
            "value": [1.0, np.nan, 3.0],
            "system_load_mw_qc_flag": ["pass", "pass", "source_gap"],
        })
        report = missing_values_report(df)
        self.assertListEqual(report["column"].tolist(), ["value"])

    def test_noaa_validation_uses_hourly_alignment(self):
        idx = pd.date_range("2019-01-01", periods=8, freq="15min", tz="UTC")
        nsrdb = pd.DataFrame({
            "timestamp_utc": idx,
            "temperature_c": [10.0, 11.0, 12.0, 13.0, 20.0, 21.0, 22.0, 23.0],
            "wind_speed_ms": [1.0, 2.0, 3.0, 4.0, 2.0, 3.0, 4.0, 5.0],
            "wind_direction_deg": [10.0, 10.0, 10.0, 10.0, 100.0, 100.0, 100.0, 100.0],
            "ghi_wm2": [0.0] * 8,
            "dni_wm2": [0.0] * 8,
            "dhi_wm2": [0.0] * 8,
            "pressure_pa": [101325.0] * 8,
            "relative_humidity_pct": [50.0] * 8,
        })
        noaa = pd.DataFrame({
            "timestamp_utc": pd.date_range("2019-01-01", periods=2, freq="h", tz="UTC"),
            "noaa_temperature_c": [11.5, 21.5],
            "noaa_wind_speed_ms": [2.5, 3.5],
            "noaa_wind_direction_deg": [10.0, 100.0],
        })
        report = validate_against_nsrdb(nsrdb, noaa)
        self.assertEqual(set(report["variable"]), {"temperature_c", "wind_speed_ms", "wind_direction_deg_circular"})
        self.assertTrue((report["rmse"] < 1e-9).all())


if __name__ == "__main__":
    unittest.main()

class ResearchStageOneTests(unittest.TestCase):
    def test_ieee33_independent_reference(self):
        from epsr_pipeline.ieee33 import backward_forward_sweep
        summary, bus, loss = backward_forward_sweep()
        self.assertEqual(int(summary['total_native_load_kw']), 3715)
        self.assertEqual(int(summary['total_native_load_kvar']), 2300)
        self.assertEqual(int(summary['minimum_voltage_bus']), 18)
        self.assertAlmostEqual(float(summary['minimum_voltage_pu']), 0.91309048, places=6)
        self.assertAlmostEqual(float(summary['total_line_loss_kw']), 202.67713, places=4)
        self.assertEqual(len(bus), 33)
        self.assertEqual(len(loss), 32)

    def test_ev_template_cv_small_synthetic(self):
        from epsr_pipeline.ev_validation import MeasuredSessionShape, repeated_stratified_kfold_template_validation
        base = pd.Timestamp('2018-01-01T00:00:00Z')
        sessions=[]
        for i in range(10):
            shape=np.zeros(24); shape[:12]=1/12
            sessions.append(MeasuredSessionShape(
                session_id=f's{i}', connection_time=base+pd.Timedelta(hours=i), disconnect_time=base+pd.Timedelta(hours=i+1),
                active_end=base+pd.Timedelta(hours=i+1), duration_h=1.0, duration_bucket='1-2h', delivered_kwh=5.0,
                shape=shape, energy_bins_raw=shape.copy(), duration_bins=np.ones(24),
            ))
        out=repeated_stratified_kfold_template_validation(sessions,n_splits=5,repeats=2,seed=1)
        self.assertEqual(out.session_id.nunique(),10)
        self.assertIn('duration_bucket_template', set(out.model))
        self.assertTrue((out.loc[out.model.eq('duration_bucket_template'),'rmse_share'] < 1e-12).all())
