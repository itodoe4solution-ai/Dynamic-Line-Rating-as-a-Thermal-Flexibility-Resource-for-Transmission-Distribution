import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
steps=[
    ROOT/'scripts/20_validate_ev_templates.py',
    ROOT/'scripts/21_build_ieee33_opendss.py',
    ROOT/'scripts/22_validate_ieee33_opendss.py',
]
for s in steps:
    print('\n===',s.name,'===')
    rc=subprocess.call([sys.executable,str(s)],cwd=ROOT)
    if rc != 0:
        raise SystemExit(rc)
print('\nResearch Stage 1 completed successfully.')
