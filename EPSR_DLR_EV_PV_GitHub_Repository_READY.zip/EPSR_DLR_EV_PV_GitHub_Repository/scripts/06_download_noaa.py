import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.noaa import (
    download_isd_lite_station_year,
    download_station_history,
    nearest_stations_with_coverage,
    read_isd_lite_gz,
    validate_against_nsrdb,
)
from epsr_pipeline.nsrdb import aggregate_to_15min, read_nsrdb_csv


def _load_validation_reference(start: pd.Timestamp, end: pd.Timestamp, interval_minutes: int) -> pd.DataFrame | None:
    processed = ROOT / "03_processed/weather_solar_15min.csv"
    cleaned = ROOT / "02_cleaned/nsrdb_5min_clean.csv"
    raw_candidates = [
        ROOT / f"01_raw/nsrdb/nsrdb_goes_conus_{year}_{interval_minutes}min.csv"
        for year in range(start.year, (end - pd.Timedelta(nanoseconds=1)).year + 1)
    ]
    if processed.exists():
        ref = pd.read_csv(processed, parse_dates=["timestamp_utc"])
    elif cleaned.exists():
        ref = aggregate_to_15min(pd.read_csv(cleaned, parse_dates=["timestamp_utc"]))
    else:
        frames = []
        for path in raw_candidates:
            if path.exists():
                frames.append(read_nsrdb_csv(path))
        if not frames:
            return None
        ref = aggregate_to_15min(pd.concat(frames, ignore_index=True))
    ref = ref[(ref.timestamp_utc >= start) & (ref.timestamp_utc < end)].copy()
    return ref if not ref.empty else None


def _validation_score(report: pd.DataFrame) -> tuple[float, float, float, float]:
    def _rmse(name: str) -> float:
        if report.empty or "variable" not in report or "rmse" not in report:
            return np.nan
        z = report.loc[report["variable"] == name, "rmse"]
        return float(z.iloc[0]) if len(z) else np.nan

    temp_rmse = _rmse("temperature_c")
    wind_speed_rmse = _rmse("wind_speed_ms")
    wind_dir_rmse = _rmse("wind_direction_deg_circular")
    if np.isfinite(temp_rmse) and np.isfinite(wind_speed_rmse):
        score = temp_rmse + wind_speed_rmse + (0.02 * wind_dir_rmse if np.isfinite(wind_dir_rmse) else 0.0)
    else:
        score = np.nan
    return score, temp_rmse, wind_speed_rmse, wind_dir_rmse

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
if not cfg["noaa"].get("validation_enabled",True):
    print("NOAA validation disabled in config.yaml"); raise SystemExit(0)
loc=cfg["location"]; nc=cfg["noaa"]
history=download_station_history(ROOT/"01_raw/noaa/isd-history.csv")
candidates=nearest_stations_with_coverage(history,float(loc["latitude"]),float(loc["longitude"]),start,end,float(nc["station_search_radius_km"]))
if candidates.empty:
    raise RuntimeError("No NOAA ISD station with full temporal coverage found within configured radius.")
reference = _load_validation_reference(start, end, int(cfg["nsrdb"]["interval_minutes"]))
rows=[]
chosen=None
for _,row in candidates.head(int(nc.get("max_stations_to_try",5))).iterrows():
    ok=True
    frames=[]
    for year in range(start.year, (end - pd.Timedelta(nanoseconds=1)).year + 1):
        p=ROOT/f"01_raw/noaa/{row.USAF}-{row.WBAN}-{year}.gz"
        try:
            if not p.exists():
                download_isd_lite_station_year(str(row.USAF),str(row.WBAN),year,p)
            frames.append(read_isd_lite_gz(p))
        except FileNotFoundError:
            ok=False
            break
    if not ok or not frames:
        rows.append({
            "USAF": row.USAF, "WBAN": row.WBAN, "station_name": row["STATION NAME"],
            "distance_km": float(row.distance_km), "status": "missing_file", "observed_hours": 0,
            "expected_hours": int(((end - start) / pd.Timedelta(hours=1))),
            "coverage_fraction": 0.0,
            "validation_available": False,
            "validation_score": np.nan,
            "temperature_rmse": np.nan,
            "wind_speed_rmse": np.nan,
            "wind_direction_rmse": np.nan,
        })
        continue
    obs = pd.concat(frames, ignore_index=True)
    obs = obs[(obs.timestamp_utc >= start) & (obs.timestamp_utc < end)]
    observed_hours = int(obs["timestamp_utc"].nunique())
    expected_hours = int(((end - start) / pd.Timedelta(hours=1)))
    coverage_fraction = observed_hours / expected_hours if expected_hours else 0.0
    temp_valid = int(obs["noaa_temperature_c"].notna().sum()) if "noaa_temperature_c" in obs else 0
    wind_valid = int(obs["noaa_wind_speed_ms"].notna().sum()) if "noaa_wind_speed_ms" in obs else 0
    rows.append({
        "USAF": row.USAF, "WBAN": row.WBAN, "station_name": row["STATION NAME"],
        "distance_km": float(row.distance_km), "status": "ok", "observed_hours": observed_hours,
        "expected_hours": expected_hours, "coverage_fraction": coverage_fraction,
        "temperature_valid_hours": temp_valid, "wind_valid_hours": wind_valid,
    })
    if reference is not None:
        report = validate_against_nsrdb(reference, obs)
        score, temp_rmse, wind_speed_rmse, wind_dir_rmse = _validation_score(report)
        rows[-1].update({
            "validation_available": bool(np.isfinite(score)),
            "validation_score": score,
            "temperature_rmse": temp_rmse,
            "wind_speed_rmse": wind_speed_rmse,
            "wind_direction_rmse": wind_dir_rmse,
        })
    else:
        rows[-1].update({
            "validation_available": False,
            "validation_score": np.nan,
            "temperature_rmse": np.nan,
            "wind_speed_rmse": np.nan,
            "wind_direction_rmse": np.nan,
        })
    if chosen is None:
        chosen = rows[-1]
    else:
        current = rows[-1]
        if current.get("validation_available") and chosen.get("validation_available"):
            current_key = (
                float(current.get("validation_score", np.nan)),
                -float(current.get("coverage_fraction", 0.0)),
                -float(current.get("temperature_valid_hours", 0)),
                -float(current.get("wind_valid_hours", 0)),
                float(current.get("distance_km", np.inf)),
            )
            chosen_key = (
                float(chosen.get("validation_score", np.nan)),
                -float(chosen.get("coverage_fraction", 0.0)),
                -float(chosen.get("temperature_valid_hours", 0)),
                -float(chosen.get("wind_valid_hours", 0)),
                float(chosen.get("distance_km", np.inf)),
            )
            if current_key < chosen_key:
                chosen = current
        elif current.get("validation_available") and not chosen.get("validation_available"):
            chosen = current
        elif not current.get("validation_available") and not chosen.get("validation_available"):
            if (coverage_fraction, temp_valid, wind_valid, -float(row.distance_km)) > (
                float(chosen["coverage_fraction"]), float(chosen["temperature_valid_hours"]), float(chosen["wind_valid_hours"]), -float(chosen["distance_km"])
            ):
                chosen = current
report = pd.DataFrame(rows)
sort_cols = ["validation_available", "validation_score", "coverage_fraction", "temperature_valid_hours", "wind_valid_hours", "distance_km"]
report = report.sort_values(sort_cols, ascending=[False, True, False, False, False, True], na_position="last")
report.to_csv(ROOT/"05_quality_control/noaa_station_candidates.csv",index=False)
if chosen is None:
    raise RuntimeError("Nearest candidate NOAA stations did not have downloadable ISD-Lite files for all study years.")
chosen["selection_basis"] = "validation_score" if chosen.get("validation_available") else "coverage_fraction"
pd.DataFrame([chosen]).to_csv(ROOT/"05_quality_control/noaa_station_selected.csv",index=False)
print("Selected NOAA station:")
cols = ["USAF","WBAN","station_name","distance_km","coverage_fraction","observed_hours","validation_score","temperature_rmse","wind_speed_rmse","wind_direction_rmse","selection_basis"]
cols = [c for c in cols if c in chosen]
print(pd.DataFrame([chosen])[cols].to_string(index=False))
