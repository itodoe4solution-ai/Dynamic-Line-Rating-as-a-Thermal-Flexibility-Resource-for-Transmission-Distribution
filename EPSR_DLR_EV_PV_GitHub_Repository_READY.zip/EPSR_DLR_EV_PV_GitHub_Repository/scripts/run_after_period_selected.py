"""Run the complete data build after study.start_utc/end_utc are set and .env contains keys."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import subprocess, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
steps=[
    "03_download_acn.py","04_build_ev_profile.py","05_download_nsrdb.py","06_download_noaa.py",
    "07_download_eia930.py","08_build_weather_and_validate.py","09_build_pv.py","10_build_dlr_ratings.py",
    "11_build_master.py","12_qc_regimes.py","13_select_periods.py","14_forecast_baselines.py",
]
for s in steps:
    print(f"\n=== {s} ===")
    subprocess.run([sys.executable,str(HERE/s)],check=True)
print("\nData pipeline complete. Inspect 05_quality_control before running 15_freeze_release.py.")
