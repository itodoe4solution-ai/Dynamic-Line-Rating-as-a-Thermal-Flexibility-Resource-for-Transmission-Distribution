
from __future__ import annotations

"""PHASE 6C — HIGH-RESOLUTION PUBLICATION FIGURES (TIMES NEW ROMAN)."""

from pathlib import Path
import importlib.util
import json
import math
import os

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager


def load_common():
    path = Path(__file__).resolve().parent / "36_phase6_common.py"
    spec = importlib.util.spec_from_file_location("phase6_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
R = ROOT / "09_simulation_inputs" / "results"
OUTDIR = c.ensure_dir(R / "phase6")
FIGDIR = c.ensure_dir(OUTDIR / "figures")
INDEX_OUT = OUTDIR / "phase6c_figure_index.csv"
GATE_OUT = OUTDIR / "phase6c_gate_summary.csv"
META_OUT = OUTDIR / "phase6c_metadata.json"

# -------------------------------------------------------------------------
# Typography and export policy
# -------------------------------------------------------------------------
try:
    font_manager.findfont("Times New Roman", fallback_to_default=False)
    font_ok = True
except Exception:
    font_ok = False

if not font_ok:
    raise RuntimeError(
        "Times New Roman was not found by Matplotlib. "
        "On Windows it is normally available. Install/enable Times New Roman "
        "before generating final journal figures so the requested typography "
        "is actually embedded."
    )

plt.rcParams.update(
    {
        "font.family": "Times New Roman",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "figure.titlesize": 11,
        "axes.linewidth": 0.8,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)

DPI = 600
WIDTH_SINGLE = 3.50
WIDTH_DOUBLE = 7.16

figure_records = []

def save_all(fig, stem, caption, width_class="single"):
    files = []
    for ext in ["png", "tiff", "pdf", "svg"]:
        path = FIGDIR / f"{stem}.{ext}"
        kwargs = {"bbox_inches": "tight"}
        if ext in ("png", "tiff"):
            kwargs["dpi"] = DPI
        fig.savefig(path, **kwargs)
        files.append(str(path))
    figure_records.append(
        {
            "figure_id": stem,
            "caption": caption,
            "width_class": width_class,
            "dpi_raster": DPI,
            "formats": "PNG; TIFF; PDF; SVG",
            "files": "; ".join(files),
        }
    )
    plt.close(fig)

def label_bars(ax, bars, fmt="{:.2f}", ypad=3):
    for b in bars:
        h = b.get_height()
        if np.isfinite(h):
            ax.annotate(
                fmt.format(h),
                xy=(b.get_x() + b.get_width() / 2, h),
                xytext=(0, ypad),
                textcoords="offset points",
                ha="center",
                va="bottom",
                fontsize=8,
            )

# -------------------------------------------------------------------------
# Load results
# -------------------------------------------------------------------------
p4feas = pd.read_csv(R / "phase4c_pair_feasibility.csv")
p4stats = pd.read_csv(R / "phase4e_primary_statistics.csv")
p5pair = pd.read_csv(R / "phase5e_paired_validation_effects.csv")
p5pub = pd.read_csv(R / "phase5e_publication_summary.csv")
p5f = pd.read_csv(R / "phase5f_voltage_control_summary.csv")
p5fp = pd.read_csv(R / "phase5f_paired_str_dlr_effects.csv")

# FIGURE 1 — Phase 4C feasibility restoration rate.
g = p4feas[p4feas["stress_regime"].astype(str).eq("high")].copy()
g = g.groupby("mpc_horizon_h", as_index=False).agg(
    pairs=("seed", "size"),
    restored=("dlr_restores_feasibility", lambda s: int(c.boolify(s).sum())),
)
g["rate"] = g["restored"] / g["pairs"]
fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 2.8))
bars = ax.bar(g["mpc_horizon_h"].astype(str), 100 * g["rate"])
ax.set_xlabel("MPC horizon (h)")
ax.set_ylabel("DLR feasibility restoration (%)")
ax.set_title("High-stress feasibility restoration")
ax.set_ylim(0, max(20, 100 * g["rate"].max() * 1.25))
label_bars(ax, bars, fmt="{:.1f}")
ax.grid(axis="y", linewidth=0.4, alpha=0.35)
save_all(
    fig,
    "Fig06_01_phase4c_feasibility_restoration",
    "High-stress Phase-4C feasibility-restoration rate under DLR relative to STR.",
)

# FIGURE 2 — Phase 4C paired loading effects.
m = p4stats[
    p4stats["metric"].astype(str).eq("max_loading_pu")
].copy()
if not m.empty:
    m["label"] = (
        m["stress_regime"].astype(str)
        + "\nH="
        + m["mpc_horizon_h"].astype(str)
        + " h"
    )
    fig, ax = plt.subplots(figsize=(WIDTH_DOUBLE, 3.2))
    bars = ax.bar(
        np.arange(len(m)),
        pd.to_numeric(m["window_equal_weight_mean_effect"], errors="coerce"),
    )
    ax.axhline(0, linewidth=0.8)
    ax.set_xticks(np.arange(len(m)))
    ax.set_xticklabels(m["label"], rotation=0)
    ax.set_ylabel("Mean paired effect, DLR − STR (pu)")
    ax.set_title("Phase-4C maximum-loading effect")
    ax.grid(axis="y", linewidth=0.4, alpha=0.35)
    save_all(
        fig,
        "Fig06_02_phase4c_loading_effect",
        "Window-equal-weight Phase-4C paired effect of DLR on maximum corridor loading.",
        "double",
    )

# FIGURE 3 — Cross-stage AC validation loading.
metric_map = [
    ("5A", "acpf_selected_corridor_max_loading_pu", "IEEE-118 ACPF"),
    ("5B", "acpf_selected_corridor_max_loading_pu", "IEEE-118 ACOPF"),
    ("5C", "n1_remaining_selected_corridor_max_loading_pu", "IEEE-118 N-1"),
    ("5D", "ieee39_acpf_selected_branch_max_loading_pu", "IEEE-39 ACPF"),
    ("5D", "ieee39_acopf_selected_branch_max_loading_pu", "IEEE-39 ACOPF"),
]
rows = []
for stage, metric, label in metric_map:
    z = p5pair[
        p5pair["stage"].astype(str).eq(stage)
        & p5pair["metric"].astype(str).eq(metric)
    ].copy()
    if len(z):
        rows.append(
            {
                "label": label,
                "STR": pd.to_numeric(z["STR"], errors="coerce").mean(),
                "DLR": pd.to_numeric(z["DLR"], errors="coerce").mean(),
            }
        )
z = pd.DataFrame(rows)
if not z.empty:
    x = np.arange(len(z))
    w = 0.36
    fig, ax = plt.subplots(figsize=(WIDTH_DOUBLE, 3.3))
    b1 = ax.bar(x - w/2, z["STR"], width=w, label="STR")
    b2 = ax.bar(x + w/2, z["DLR"], width=w, label="DLR")
    ax.set_xticks(x)
    ax.set_xticklabels(z["label"], rotation=18, ha="right")
    ax.set_ylabel("Mean normalized loading (pu)")
    ax.set_title("AC-security validation of thermal loading")
    ax.legend(frameon=False)
    ax.grid(axis="y", linewidth=0.4, alpha=0.35)
    label_bars(ax, b1, fmt="{:.2f}")
    label_bars(ax, b2, fmt="{:.2f}")
    save_all(
        fig,
        "Fig06_03_cross_stage_ac_loading",
        "Mean STR and DLR loading across IEEE-118 ACPF, ACOPF, selected N-1, and normalized IEEE-39 robustness validation.",
        "double",
    )

# FIGURE 4 — Phase 5F IEEE-33 voltage-clean fraction by control.
v = (
    p5f.groupby(["control_case"], as_index=False)
    .agg(
        clean=("ieee33_voltage_clean_evaluations", "sum"),
        n=("evaluations", "sum"),
    )
)
v["fraction"] = v["clean"] / v["n"]
order = ["BASELINE", "VOLT_VAR", "OLTC", "OLTC_VOLT_VAR"]
v["order"] = v["control_case"].map({x:i for i,x in enumerate(order)})
v = v.sort_values("order")
fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 3.0))
bars = ax.bar(v["control_case"], 100 * v["fraction"])
ax.set_ylabel("IEEE-33 voltage-clean states (%)")
ax.set_xlabel("Voltage-control case")
ax.set_title("Distribution voltage-security sensitivity")
ax.set_ylim(0, 110)
ax.tick_params(axis="x", rotation=25)
ax.grid(axis="y", linewidth=0.4, alpha=0.35)
label_bars(ax, bars, fmt="{:.1f}")
save_all(
    fig,
    "Fig06_04_phase5f_voltage_clean_fraction",
    "Share of selected Phase-5F states satisfying the 0.95–1.05 pu IEEE-33 voltage criterion.",
)

# FIGURE 5 — Worst IEEE-33 minimum voltage by control.
vmin = (
    p5f.groupby(["control_case"], as_index=False)
    .agg(worst_vmin=("worst_ieee33_vmin_pu", "min"))
)
vmin["order"] = vmin["control_case"].map({x:i for i,x in enumerate(order)})
vmin = vmin.sort_values("order")
fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 3.0))
bars = ax.bar(vmin["control_case"], vmin["worst_vmin"])
ax.axhline(0.95, linestyle="--", linewidth=1.0, label="0.95 pu limit")
ax.set_ylim(min(0.88, vmin["worst_vmin"].min() - 0.01), 1.01)
ax.set_ylabel("Worst IEEE-33 minimum voltage (pu)")
ax.set_xlabel("Voltage-control case")
ax.set_title("Worst-case distribution voltage")
ax.tick_params(axis="x", rotation=25)
ax.legend(frameon=False)
ax.grid(axis="y", linewidth=0.4, alpha=0.35)
label_bars(ax, bars, fmt="{:.3f}")
save_all(
    fig,
    "Fig06_05_phase5f_worst_vmin",
    "Worst IEEE-33 minimum voltage under baseline, Volt-VAR, OLTC, and combined voltage control.",
)

# FIGURE 6 — Thermal-clean fraction under combined control, high stress.
tc = p5f[
    p5f["stress_regime"].astype(str).eq("high")
    & p5f["control_case"].astype(str).eq("OLTC_VOLT_VAR")
].copy()
if not tc.empty:
    fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 2.8))
    vals = 100 * pd.to_numeric(tc["ieee118_thermal_clean_fraction"], errors="coerce")
    bars = ax.bar(tc["case"].str.replace("-SMPC", "", regex=False), vals)
    ax.set_ylim(0, 110)
    ax.set_ylabel("Thermally clean states (%)")
    ax.set_title("High-stress combined voltage control")
    ax.grid(axis="y", linewidth=0.4, alpha=0.35)
    label_bars(ax, bars, fmt="{:.1f}")
    save_all(
        fig,
        "Fig06_06_high_stress_thermal_clean_combined",
        "High-stress IEEE-118 thermal-compliance fraction under combined OLTC + Volt-VAR control.",
    )

# FIGURE 7 — DLR minus STR loading under each Phase-5F control.
lf = p5fp[
    p5fp["metric"].astype(str).eq("ieee118_selected_corridor_max_loading_pu")
].copy()
lf = (
    lf.groupby("control_case", as_index=False)["DLR_minus_STR"]
    .mean()
)
lf["order"] = lf["control_case"].map({x:i for i,x in enumerate(order)})
lf = lf.sort_values("order")
fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 3.0))
bars = ax.bar(lf["control_case"], lf["DLR_minus_STR"])
ax.axhline(0, linewidth=0.8)
ax.set_ylabel("Mean loading effect, DLR − STR (pu)")
ax.set_xlabel("Voltage-control case")
ax.set_title("DLR thermal advantage after voltage control")
ax.tick_params(axis="x", rotation=25)
ax.grid(axis="y", linewidth=0.4, alpha=0.35)
for b in bars:
    ax.annotate(
        f"{b.get_height():.3f}",
        xy=(b.get_x()+b.get_width()/2, b.get_height()),
        xytext=(0, -14 if b.get_height() < 0 else 3),
        textcoords="offset points",
        ha="center",
        va="bottom",
        fontsize=8,
    )
save_all(
    fig,
    "Fig06_07_phase5f_dlr_loading_advantage",
    "Mean paired DLR-minus-STR loading effect under each Phase-5F voltage-control case.",
)

# FIGURE 8 — IEEE-118 process/security clean fractions by stage.
if {"model", "combined_security_clean_fraction"}.issubset(p5pub.columns):
    z = p5pub.dropna(subset=["combined_security_clean_fraction"]).copy()
    fig, ax = plt.subplots(figsize=(WIDTH_DOUBLE, 3.2))
    bars = ax.bar(
        z["model"].astype(str),
        100 * pd.to_numeric(z["combined_security_clean_fraction"], errors="coerce"),
    )
    ax.set_ylabel("Combined security-clean evaluations (%)")
    ax.set_title("Phase-5 AC validation security outcomes")
    ax.tick_params(axis="x", rotation=22)
    ax.grid(axis="y", linewidth=0.4, alpha=0.35)
    label_bars(ax, bars, fmt="{:.1f}")
    save_all(
        fig,
        "Fig06_08_phase5_security_clean_fraction",
        "Combined voltage-and-thermal security-clean fraction across Phase-5 validation models.",
        "double",
    )

# FIGURE 9 — Phase 5F mean weighted voltage violations.
wv_rows = []
for control_case, g in p5f.groupby("control_case", dropna=False):
    vals = pd.to_numeric(
        g["mean_weighted_bus_voltage_violations"],
        errors="coerce",
    )
    weights = pd.to_numeric(
        g["evaluations"],
        errors="coerce",
    )
    valid = vals.notna() & weights.notna() & weights.gt(0)
    if valid.any():
        mean_weighted = float(
            np.average(
                vals.loc[valid].to_numpy(dtype=float),
                weights=weights.loc[valid].to_numpy(dtype=float),
            )
        )
    else:
        mean_weighted = np.nan
    wv_rows.append(
        {
            "control_case": control_case,
            "mean_weighted_violations": mean_weighted,
        }
    )
wv = pd.DataFrame(wv_rows)
wv["order"] = wv["control_case"].map({x:i for i,x in enumerate(order)})
wv = wv.sort_values("order")
fig, ax = plt.subplots(figsize=(WIDTH_SINGLE, 3.0))
bars = ax.bar(wv["control_case"], wv["mean_weighted_violations"])
ax.set_ylabel("Mean weighted bus-voltage violations")
ax.set_xlabel("Voltage-control case")
ax.set_title("Voltage-violation burden")
ax.tick_params(axis="x", rotation=25)
ax.grid(axis="y", linewidth=0.4, alpha=0.35)
label_bars(ax, bars, fmt="{:.1f}")
save_all(
    fig,
    "Fig06_09_voltage_violation_burden",
    "Mean feeder-count-weighted IEEE-33 bus-voltage violation burden under each voltage-control case.",
)

index = pd.DataFrame(figure_records)
index.to_csv(INDEX_OUT, index=False)

gates = pd.DataFrame(
    [
        {"gate": "times_new_roman_available", "status": font_ok, "note": "Matplotlib resolved Times New Roman without fallback."},
        {"gate": "minimum_seven_publication_figures_created", "status": len(index) >= 7, "note": f"{len(index)} figures created."},
        {"gate": "all_raster_figures_600dpi", "status": bool((index["dpi_raster"] == 600).all()), "note": "PNG and TIFF exported at 600 dpi."},
        {"gate": "vector_formats_created", "status": bool(index["formats"].str.contains("PDF").all() and index["formats"].str.contains("SVG").all()), "note": "PDF/SVG vector versions created."},
    ]
)
gates.to_csv(GATE_OUT, index=False)

c.write_json(
    META_OUT,
    {
        "stage": "6C",
        "font": "Times New Roman",
        "raster_dpi": DPI,
        "single_column_width_in": WIDTH_SINGLE,
        "double_column_width_in": WIDTH_DOUBLE,
        "figure_count": len(index),
        "index": str(INDEX_OUT),
    },
)

print("\nPHASE-6C FIGURE INDEX")
print(index[["figure_id", "width_class", "dpi_raster", "caption"]].to_string(index=False))
print("\nPHASE-6C GATE")
print(gates.to_string(index=False))

if not c.boolify(gates["status"]).all():
    raise RuntimeError("Phase 6C figure-generation gates failed.")

print("\nPASS: PHASE 6C HIGH-RESOLUTION FIGURES COMPLETE.")
