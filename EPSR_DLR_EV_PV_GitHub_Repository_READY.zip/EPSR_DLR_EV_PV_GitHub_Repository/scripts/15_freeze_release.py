import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import hashlib, json, shutil
from pathlib import Path
import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories, write_json

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
src=ROOT/"04_master/master_dataset_classified.csv"
dst=ROOT/"04_master/master_dataset_v1.0.csv"
if dst.exists():
    raise RuntimeError(f"{dst.name} already exists. Never overwrite a frozen dataset; create v1.1 instead.")
shutil.copy2(src,dst)
sha=hashlib.sha256(dst.read_bytes()).hexdigest()
manifest={"dataset_file":dst.name,"sha256":sha,"study_start_utc":start.isoformat(),"study_end_utc_exclusive":end.isoformat(),"config":cfg}
write_json(manifest,ROOT/"10_reproducibility/release_v1.0.json")
(ROOT/"10_reproducibility/CHANGELOG.md").write_text("# Dataset changelog\n\n## v1.0\n- Initial frozen publication-grade master dataset.\n",encoding="utf-8")
print(f"Frozen {dst.name}\nSHA256: {sha}")
