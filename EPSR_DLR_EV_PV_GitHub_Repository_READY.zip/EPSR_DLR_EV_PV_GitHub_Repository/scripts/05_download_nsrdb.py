import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.nsrdb import download_nsrdb_year

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
n=cfg["nsrdb"]; loc=cfg["location"]
for year in range(start.year, (end - pd.Timedelta(nanoseconds=1)).year + 1):
    if year < 2018 or year > 2024:
        raise RuntimeError(f"Configured NSRDB GOES CONUS v4 years currently documented as 2018-2024; got {year}.")
    out=ROOT/f"01_raw/nsrdb/nsrdb_goes_conus_{year}_{n['interval_minutes']}min.csv"
    if out.exists():
        print(f"Exists, skipping: {out.name}")
        continue
    download_nsrdb_year(
        year, float(loc["latitude"]), float(loc["longitude"]), n["endpoint"],
        list(n["attributes"]), int(n["interval_minutes"]), out,
        bool(n.get("leap_day",True)), bool(n.get("utc",True))
    )
    print(f"Downloaded {out}")
