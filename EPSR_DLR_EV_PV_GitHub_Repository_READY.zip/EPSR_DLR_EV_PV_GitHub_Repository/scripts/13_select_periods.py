import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, ensure_directories, require_study_period
from epsr_pipeline.scenarios import select_representative_periods

ensure_directories(); cfg=load_config()
m=pd.read_csv(ROOT/"04_master/master_dataset_classified.csv",parse_dates=["timestamp_utc","timestamp_local"])
start,end=require_study_period(cfg)
periods=select_representative_periods(m,cfg["project"]["timezone_local"],days=7,study_start_utc=start,study_end_utc=end)
periods.to_csv(ROOT/"06_scenarios/selected_periods.csv",index=False)
print(periods.to_string(index=False))
print("Freeze this file before final MATPOWER/OpenDSS/SMPC experiments.")
