from __future__ import annotations

"""
Phase 4E — Statistical consolidation and publication freeze
===========================================================

Purpose
-------
Consolidate Phase 4A/4B/4C/4D into publication-ready statistical tables
without retuning the controller or changing any frozen scenario definitions.

Primary inferential layer
-------------------------
The true hourly receding-horizon Phase 4C STR-SMPC versus DLR-SMPC comparison
is treated as the final confirmatory controller result. Continuous effects are
computed only for STR/DLR pairs that are strictly feasible in both cases.

Dependence handling
-------------------
Ten random seeds within the same evaluation window are not treated as ten fully
independent physical experiments. Inference therefore clusters by frozen
`window_id`:

1. paired seed-level effects are averaged within each window;
2. the point estimate gives each window equal weight;
3. 95% confidence intervals use a nonparametric cluster bootstrap over windows;
4. a two-sided paired sign-flip test is performed on window-level effects;
5. standardized effect size is reported as mean(window effect)/SD(window effect).

Feasibility
-----------
Feasibility restoration is analyzed as a paired binary endpoint. For each
window/seed pair, restoration means STR is infeasible while DLR remains feasible.
Cluster-bootstrap confidence intervals again resample windows rather than seeds.

Ablations
---------
Phase 4D effects are comparator minus full DLR-SMPC. The noPV case is explicitly
labeled "PV-absent sensitivity" because it removes PV generation itself rather
than isolating active PV curtailment control.

Scientific boundary
-------------------
Phase 4 remains a reduced-order stochastic T-D operational screen using the
provisional 0.90–1.10 pu IEEE-33 BFS envelope. Definitive AC voltage/security,
ACOPF, N-1, and IEEE-39 conclusions belong to Phase 5.
"""

from pathlib import Path
import hashlib
import itertools
import json
import os
import time
from typing import Iterable

import numpy as np
import pandas as pd


# =============================================================================
# 1. Repository and paths
# =============================================================================

def _resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path.cwd(),
        Path(__file__).resolve().parent.parent,
        Path(__file__).resolve().parent,
    ])
    for p in candidates:
        p = p.resolve()
        if (
            (p / "06_scenarios" / "selected_periods.csv").exists()
            and (p / "09_simulation_inputs" / "results").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate EPSR repository root. Run from the repository root "
        "or set EPSR_ROOT to that folder."
    )


ROOT = _resolve_root()
RESULT_DIR = ROOT / "09_simulation_inputs" / "results"
OUT_DIR = RESULT_DIR
OUT_DIR.mkdir(parents=True, exist_ok=True)

INPUTS = {
    "phase4a_primary": RESULT_DIR / "phase4_primary_results.csv",
    "phase4b_classified": RESULT_DIR / "phase4_sensitivity_results_classified.csv",
    "phase4b_pair_feasibility": RESULT_DIR / "phase4b_pair_feasibility.csv",
    "phase4b_paired": RESULT_DIR / "phase4b_strict_feasible_paired_effects.csv",
    "phase4c_results": RESULT_DIR / "phase4c_receding_horizon_results.csv",
    "phase4c_pair_feasibility": RESULT_DIR / "phase4c_pair_feasibility.csv",
    "phase4c_paired": RESULT_DIR / "phase4c_strict_feasible_paired_effects.csv",
    "phase4d_results": RESULT_DIR / "phase4d_ablation_results.csv",
    "phase4d_paired": RESULT_DIR / "phase4d_paired_effects.csv",
    "phase4d_feasibility": RESULT_DIR / "phase4d_feasibility_summary.csv",
    "selected_periods": ROOT / "06_scenarios" / "selected_periods.csv",
}

OUT_PRIMARY = OUT_DIR / "phase4e_primary_statistics.csv"
OUT_FEAS = OUT_DIR / "phase4e_feasibility_statistics.csv"
OUT_ABL = OUT_DIR / "phase4e_ablation_statistics.csv"
OUT_WINDOW = OUT_DIR / "phase4e_window_level_effects.csv"
OUT_PUBLICATION = OUT_DIR / "phase4e_publication_summary.csv"
OUT_GATE = OUT_DIR / "phase4e_gate_summary.csv"
OUT_META = OUT_DIR / "phase4e_metadata.json"

BOOTSTRAP_REPS = int(os.environ.get("PHASE4E_BOOTSTRAP_REPS", "20000"))
BASE_SEED = int(os.environ.get("PHASE4E_RANDOM_SEED", "20260821"))
ALPHA = 0.05

PRIMARY_METRICS = [
    "ev_unserved_mwh",
    "ev_service_ratio",
    "pv_curtailment_mwh",
    "pcc_energy_mwh",
    "mean_loading_pu",
    "max_loading_pu",
    "binding_hours",
    "thermal_violation_count",
    "voltage_violation_count",
    "cost",
]

LOWER_IS_BETTER = {
    "ev_unserved_mwh",
    "pv_curtailment_mwh",
    "mean_loading_pu",
    "max_loading_pu",
    "binding_hours",
    "thermal_violation_count",
    "voltage_violation_count",
    "cost",
}
HIGHER_IS_BETTER = {"ev_service_ratio"}
CONTEXT_ONLY = {"pcc_energy_mwh"}


# =============================================================================
# 2. Utilities
# =============================================================================

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _stable_seed(*parts: object) -> int:
    text = "|".join(str(x) for x in parts)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return (BASE_SEED + int(digest[:12], 16)) % (2**32 - 1)


def _boolify(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().map(
        {"true": True, "false": False, "1": True, "0": False}
    ).fillna(False).astype(bool)


def _bootstrap_mean_ci(window_values: np.ndarray, reps: int, seed: int) -> tuple[float, float]:
    x = np.asarray(window_values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan, np.nan
    if len(x) == 1 or np.allclose(x, x[0], rtol=0.0, atol=1e-15):
        return float(x.mean()), float(x.mean())
    rng = np.random.default_rng(seed)
    # Resample whole evaluation windows. Seeds remain nested within windows.
    idx = rng.integers(0, len(x), size=(reps, len(x)))
    boot = x[idx].mean(axis=1)
    lo, hi = np.quantile(boot, [ALPHA / 2, 1 - ALPHA / 2])
    return float(lo), float(hi)


_SIGN_CACHE: dict[int, np.ndarray] = {}


def _signflip_p(window_values: np.ndarray, seed: int) -> float:
    x = np.asarray(window_values, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n == 0:
        return np.nan
    obs = abs(float(x.mean()))
    if np.allclose(x, 0.0, atol=1e-15):
        return 1.0

    # Exact paired randomization is inexpensive for the 13 frozen windows.
    if n <= 16:
        if n not in _SIGN_CACHE:
            signs = np.array(list(itertools.product([-1.0, 1.0], repeat=n)), dtype=float)
            _SIGN_CACHE[n] = signs
        null = np.abs((_SIGN_CACHE[n] * x[None, :]).mean(axis=1))
        return float(np.mean(null >= obs - 1e-15))

    # Fallback Monte Carlo if the number of windows is later expanded.
    rng = np.random.default_rng(seed)
    reps = max(50000, BOOTSTRAP_REPS)
    signs = rng.choice([-1.0, 1.0], size=(reps, n))
    null = np.abs((signs * x[None, :]).mean(axis=1))
    return float((1 + np.sum(null >= obs)) / (reps + 1))


def _direction(metric: str, effect: float, comparison: str) -> tuple[str, object]:
    if metric in CONTEXT_ONLY or not np.isfinite(effect):
        return "context_only", np.nan
    if abs(effect) <= 1e-15:
        return "no_difference", False

    # comparison describes effect sign, e.g. DLR_minus_STR or ablation_minus_full.
    if comparison == "DLR_minus_STR":
        if metric in LOWER_IS_BETTER:
            return ("favors_DLR" if effect < 0 else "favors_STR"), bool(effect < 0)
        if metric in HIGHER_IS_BETTER:
            return ("favors_DLR" if effect > 0 else "favors_STR"), bool(effect > 0)

    if comparison == "ablation_minus_full":
        if metric in LOWER_IS_BETTER:
            return ("favors_full_DLR_SMPC" if effect > 0 else "favors_ablation"), bool(effect > 0)
        if metric in HIGHER_IS_BETTER:
            return ("favors_full_DLR_SMPC" if effect < 0 else "favors_ablation"), bool(effect < 0)

    return "context_only", np.nan


def _cluster_effect_stats(
    df: pd.DataFrame,
    effect_col: str,
    metric: str,
    group_values: dict,
    comparison: str,
    reference_col: str | None = None,
    treatment_col: str | None = None,
) -> tuple[dict, pd.DataFrame]:
    z = df.copy()
    z[effect_col] = pd.to_numeric(z[effect_col], errors="coerce")
    z = z[np.isfinite(z[effect_col])].copy()
    if z.empty:
        raise RuntimeError(f"No finite values for {effect_col} in group {group_values}")

    win = (
        z.groupby("window_id", as_index=False)
        .agg(
            window_effect_mean=(effect_col, "mean"),
            window_effect_median=(effect_col, "median"),
            seed_pairs=(effect_col, "size"),
        )
    )

    if reference_col and reference_col in z.columns:
        refw = z.groupby("window_id")[reference_col].mean().rename("window_reference_mean")
        win = win.merge(refw, on="window_id", how="left")
    if treatment_col and treatment_col in z.columns:
        trtw = z.groupby("window_id")[treatment_col].mean().rename("window_treatment_mean")
        win = win.merge(trtw, on="window_id", how="left")

    wv = win["window_effect_mean"].to_numpy(float)
    point = float(np.mean(wv))
    ci_low, ci_high = _bootstrap_mean_ci(
        wv,
        BOOTSTRAP_REPS,
        _stable_seed(comparison, metric, *group_values.values()),
    )
    pval = _signflip_p(wv, _stable_seed("sign", comparison, metric, *group_values.values()))
    sdw = float(np.std(wv, ddof=1)) if len(wv) > 1 else np.nan
    dz = float(point / sdw) if np.isfinite(sdw) and sdw > 0 else (0.0 if abs(point) <= 1e-15 else np.nan)
    label, favors = _direction(metric, point, comparison)

    ref_mean = np.nan
    trt_mean = np.nan
    relative_pct = np.nan
    if "window_reference_mean" in win.columns:
        ref_mean = float(win["window_reference_mean"].mean())
    if "window_treatment_mean" in win.columns:
        trt_mean = float(win["window_treatment_mean"].mean())
    if np.isfinite(ref_mean) and abs(ref_mean) > 1e-12 and metric not in CONTEXT_ONLY:
        relative_pct = float(100.0 * point / abs(ref_mean))

    row = {
        **group_values,
        "comparison": comparison,
        "metric": metric,
        "n_pairs": int(len(z)),
        "n_windows": int(len(win)),
        "window_equal_weight_mean_effect": point,
        "pair_median_effect": float(z[effect_col].median()),
        "window_median_effect": float(win["window_effect_mean"].median()),
        "window_effect_sd": sdw,
        "ci95_low_cluster_bootstrap": ci_low,
        "ci95_high_cluster_bootstrap": ci_high,
        "ci95_excludes_zero": bool((ci_low > 0) or (ci_high < 0)),
        "cluster_signflip_p_value": pval,
        "effect_size_dz_window": dz,
        "window_fraction_positive": float(np.mean(wv > 1e-15)),
        "window_fraction_negative": float(np.mean(wv < -1e-15)),
        "pair_fraction_exact_zero": float(np.mean(np.isclose(z[effect_col].to_numpy(float), 0.0, atol=1e-12))),
        "reference_window_equal_mean": ref_mean,
        "treatment_window_equal_mean": trt_mean,
        "relative_effect_pct_of_abs_reference": relative_pct,
        "directional_interpretation": label,
        "favors_proposed_method": favors,
        "inference_unit": "frozen evaluation window",
        "bootstrap_reps": int(BOOTSTRAP_REPS),
    }

    for k, v in group_values.items():
        win[k] = v
    win["comparison"] = comparison
    win["metric"] = metric
    return row, win


def _paired_pivot(
    results: pd.DataFrame,
    valid_keys: pd.DataFrame,
    pair_keys: list[str],
    metric: str,
    a: str,
    b: str,
    case_col: str = "case",
) -> pd.DataFrame:
    z = results.merge(valid_keys[pair_keys].drop_duplicates(), on=pair_keys, how="inner")
    p = (
        z.pivot_table(index=pair_keys, columns=case_col, values=metric, aggfunc="first")
        .reset_index()
    )
    p.columns.name = None
    if a not in p.columns or b not in p.columns:
        raise RuntimeError(f"Missing paired cases {a}/{b} for metric {metric}")
    p[f"{metric}__{b}_minus_{a}"] = p[b] - p[a]
    return p


# =============================================================================
# 3. Validation and loading
# =============================================================================

def _load_required() -> dict[str, pd.DataFrame]:
    missing = [str(p) for p in INPUTS.values() if not p.exists()]
    if missing:
        raise FileNotFoundError(
            "Phase 4E requires all frozen Phase 4A–4D artifacts. Missing:\n- "
            + "\n- ".join(missing)
        )
    return {k: pd.read_csv(v) for k, v in INPUTS.items() if v.suffix.lower() == ".csv"}


def _validate_cross_phase(data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    gates: list[dict] = []
    periods = data["selected_periods"]
    n_windows = len(periods)

    p4a = data["phase4a_primary"]
    p4b = data["phase4b_classified"]
    p4c = data["phase4c_results"]
    p4d = data["phase4d_results"]

    def gate(name: str, status: bool, detail: str = ""):
        gates.append({"gate": name, "status": bool(status), "detail": detail})

    gate("frozen_windows_present", n_windows >= 1, f"windows={n_windows}")
    gate("phase4a_primary_present", len(p4a) > 0, f"rows={len(p4a)}")
    gate("phase4b_expected_rows", len(p4b) == 3 * 3 * n_windows * 10 * 2, f"rows={len(p4b)}")
    gate("phase4c_expected_rows", len(p4c) == 2 * 3 * n_windows * 10 * 2, f"rows={len(p4c)}")
    gate("phase4d_expected_rows", len(p4d) == 2 * n_windows * 10 * 5, f"rows={len(p4d)}")

    gate(
        "phase4c_true_hourly_receding_horizon",
        (p4c["reoptimization_interval_h"].eq(1).all()
         and p4c["actions_executed_per_solve"].eq(1).all()),
        "reoptimization_interval_h=1; actions_executed_per_solve=1",
    )
    gate(
        "phase4c_no_other_solver_failures",
        int(pd.to_numeric(p4c["solver_other_failure_count"], errors="coerce").fillna(0).sum()) == 0,
    )
    gate(
        "phase4d_no_other_solver_failures",
        int(pd.to_numeric(p4d["solver_other_failure_count"], errors="coerce").fillna(0).sum()) == 0,
    )

    # Phase 4D reference must reproduce Phase 4C DLR-SMPC at H=4 h.
    keys = ["stress_regime", "feeder_count", "network", "window_id", "seed"]
    metrics = [
        "ev_unserved_mwh", "ev_service_ratio", "pv_curtailment_mwh",
        "pcc_energy_mwh", "mean_loading_pu", "max_loading_pu", "binding_hours",
        "thermal_violation_count", "voltage_violation_count", "cost",
        "solver_fail_count", "solver_infeasible_count", "solver_other_failure_count",
    ]
    c = p4c[(p4c["case"] == "DLR-SMPC") & (p4c["mpc_horizon_h"] == 4)][keys + metrics].copy()
    d = p4d[p4d["case"] == "DLR-SMPC"][keys + metrics].copy()
    merged = c.merge(d, on=keys, suffixes=("__4c", "__4d"), how="outer", indicator=True)
    same_keys = merged["_merge"].eq("both").all() and len(merged) == 2 * n_windows * 10
    max_diff = 0.0
    if same_keys:
        for m in metrics:
            a = pd.to_numeric(merged[f"{m}__4c"], errors="coerce").to_numpy(float)
            b = pd.to_numeric(merged[f"{m}__4d"], errors="coerce").to_numpy(float)
            diff = np.nanmax(np.abs(a - b)) if len(a) else np.inf
            if np.isfinite(diff):
                max_diff = max(max_diff, float(diff))
            else:
                max_diff = np.inf
    gate(
        "phase4d_reference_reproduces_phase4c_4h_DLR",
        bool(same_keys and max_diff <= 1e-6),
        f"max_abs_diff={max_diff:.3g}",
    )

    # Five-case ablation design.
    expected_cases = {
        "DLR-SMPC", "DLR-DMPC", "DLR-SMPC-noPV",
        "DLR-SMPC-uncalibrated", "uncontrolled",
    }
    gate("phase4d_five_cases_present", set(p4d["case"]) == expected_cases)

    return pd.DataFrame(gates)


# =============================================================================
# 4. Phase 4C final primary paired statistics
# =============================================================================

def build_primary_statistics(data: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    results = data["phase4c_results"].copy()
    feas = data["phase4c_pair_feasibility"].copy()
    for c in ["both_strict_feasible", "dlr_restores_feasibility", "str_only_feasible", "neither_feasible"]:
        if c in feas.columns:
            feas[c] = _boolify(feas[c])

    pair_keys = [
        "stress_regime", "feeder_count", "mpc_horizon_h",
        "network", "window_id", "seed",
    ]
    valid = feas.loc[_boolify(feas["both_strict_feasible"]), pair_keys].copy()

    rows = []
    windows = []
    group_cols = ["stress_regime", "feeder_count", "mpc_horizon_h"]
    for group, _ in results.groupby(group_cols):
        gv = dict(zip(group_cols, group if isinstance(group, tuple) else (group,)))
        vk = valid.copy()
        for k, v in gv.items():
            vk = vk[vk[k] == v]
        if vk.empty:
            continue
        for metric in PRIMARY_METRICS:
            p = _paired_pivot(results, vk, pair_keys, metric, "STR-SMPC", "DLR-SMPC")
            effect_col = f"{metric}__DLR-SMPC_minus_STR-SMPC"
            row, win = _cluster_effect_stats(
                p,
                effect_col,
                metric,
                {"analysis_source": "Phase4C_true_receding_horizon", **gv},
                "DLR_minus_STR",
                reference_col="STR-SMPC",
                treatment_col="DLR-SMPC",
            )
            row["publication_role"] = "final confirmatory paired effect"
            rows.append(row)
            win["analysis_source"] = "Phase4C_true_receding_horizon"
            windows.append(win)

    return pd.DataFrame(rows), pd.concat(windows, ignore_index=True)


# =============================================================================
# 5. Feasibility restoration: 4B robustness + 4C confirmatory
# =============================================================================

def _feasibility_table(pair_df: pd.DataFrame, source: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    z = pair_df.copy()
    bool_cols = [
        "str_strict_feasible", "dlr_strict_feasible", "both_strict_feasible",
        "dlr_restores_feasibility", "str_only_feasible", "neither_feasible",
    ]
    for c in bool_cols:
        if c in z.columns:
            z[c] = _boolify(z[c])

    # Compatibility normalization across Phase 4B and Phase 4C pair tables.
    # Phase 4B's original export does not contain `neither_feasible`, while
    # Phase 4C does. Derive any missing classification columns from the two
    # strict-feasibility flags when available; otherwise derive `neither` from
    # the mutually exclusive pair-classification columns. This does not alter
    # any scientific result; it only makes the schema explicit.
    if "str_strict_feasible" in z.columns and "dlr_strict_feasible" in z.columns:
        sf = _boolify(z["str_strict_feasible"])
        df = _boolify(z["dlr_strict_feasible"])
        if "both_strict_feasible" not in z.columns:
            z["both_strict_feasible"] = sf & df
        if "dlr_restores_feasibility" not in z.columns:
            z["dlr_restores_feasibility"] = (~sf) & df
        if "str_only_feasible" not in z.columns:
            z["str_only_feasible"] = sf & (~df)
        if "neither_feasible" not in z.columns:
            z["neither_feasible"] = (~sf) & (~df)
    elif "neither_feasible" not in z.columns:
        required = {"both_strict_feasible", "dlr_restores_feasibility", "str_only_feasible"}
        missing = required.difference(z.columns)
        if missing:
            raise KeyError(
                "Cannot derive pair-feasibility classes; missing columns: "
                + ", ".join(sorted(missing))
            )
        z["neither_feasible"] = ~(
            _boolify(z["both_strict_feasible"])
            | _boolify(z["dlr_restores_feasibility"])
            | _boolify(z["str_only_feasible"])
        )

    # Normalize all classification columns after derivation.
    for c in [
        "both_strict_feasible", "dlr_restores_feasibility",
        "str_only_feasible", "neither_feasible"
    ]:
        z[c] = _boolify(z[c])

    group_cols = ["stress_regime", "feeder_count", "mpc_horizon_h"]
    rows = []
    windows = []
    for group, g in z.groupby(group_cols, dropna=False):
        gv = dict(zip(group_cols, group if isinstance(group, tuple) else (group,)))
        if "str_strict_feasible" in g.columns and "dlr_strict_feasible" in g.columns:
            g = g.copy()
            g["feasibility_advantage_DLR_minus_STR"] = (
                g["dlr_strict_feasible"].astype(int) - g["str_strict_feasible"].astype(int)
            )
        else:
            # Derive from pair-classification columns if necessary.
            g = g.copy()
            g["feasibility_advantage_DLR_minus_STR"] = (
                g["dlr_restores_feasibility"].astype(int) - g["str_only_feasible"].astype(int)
            )

        wg = (
            g.groupby("window_id", as_index=False)
            .agg(
                window_restoration_rate=("dlr_restores_feasibility", "mean"),
                window_both_feasible_rate=("both_strict_feasible", "mean"),
                window_feasibility_advantage=("feasibility_advantage_DLR_minus_STR", "mean"),
                seed_pairs=("seed", "size"),
            )
        )
        wv = wg["window_restoration_rate"].to_numpy(float)
        adv = wg["window_feasibility_advantage"].to_numpy(float)
        lo, hi = _bootstrap_mean_ci(wv, BOOTSTRAP_REPS, _stable_seed(source, "restoration", *gv.values()))
        alo, ahi = _bootstrap_mean_ci(adv, BOOTSTRAP_REPS, _stable_seed(source, "adv", *gv.values()))
        p = _signflip_p(adv, _stable_seed(source, "adv_sign", *gv.values()))

        rows.append({
            "analysis_source": source,
            **gv,
            "n_pairs": int(len(g)),
            "n_windows": int(len(wg)),
            "dlr_restores_feasibility_pairs": int(g["dlr_restores_feasibility"].sum()),
            "str_only_feasible_pairs": int(g["str_only_feasible"].sum()),
            "both_strict_feasible_pairs": int(g["both_strict_feasible"].sum()),
            "neither_feasible_pairs": int(g["neither_feasible"].sum()),
            "restoration_rate_pair_weighted": float(g["dlr_restores_feasibility"].mean()),
            "restoration_rate_window_equal": float(wv.mean()),
            "restoration_ci95_low_cluster_bootstrap": lo,
            "restoration_ci95_high_cluster_bootstrap": hi,
            "feasibility_advantage_DLR_minus_STR_window_equal": float(adv.mean()),
            "feasibility_advantage_ci95_low": alo,
            "feasibility_advantage_ci95_high": ahi,
            "feasibility_advantage_signflip_p": p,
            "window_fraction_with_any_DLR_restoration": float(np.mean(wv > 0)),
            "inference_unit": "frozen evaluation window",
            "bootstrap_reps": int(BOOTSTRAP_REPS),
        })
        for k, v in gv.items():
            wg[k] = v
        wg["analysis_source"] = source
        wg["comparison"] = "DLR_feasibility_vs_STR"
        windows.append(wg)

    return pd.DataFrame(rows), pd.concat(windows, ignore_index=True)


def build_feasibility_statistics(data: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    b, bw = _feasibility_table(data["phase4b_pair_feasibility"], "Phase4B_block_sensitivity")
    c, cw = _feasibility_table(data["phase4c_pair_feasibility"], "Phase4C_true_receding_horizon")
    return pd.concat([b, c], ignore_index=True), pd.concat([bw, cw], ignore_index=True)


# =============================================================================
# 6. Phase 4D ablation statistics
# =============================================================================

def build_ablation_statistics(data: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    paired = data["phase4d_paired"].copy()
    paired["pair_valid_for_continuous_effect"] = _boolify(paired["pair_valid_for_continuous_effect"])
    paired = paired[paired["pair_valid_for_continuous_effect"]].copy()

    group_cols = ["stress_regime", "feeder_count", "comparator_case"]
    rows = []
    windows = []
    for group, g in paired.groupby(group_cols, dropna=False):
        gv = dict(zip(group_cols, group if isinstance(group, tuple) else (group,)))
        comparator = str(gv["comparator_case"])
        label = {
            "DLR-DMPC": "deterministic MPC ablation",
            "DLR-SMPC-noPV": "PV-absent sensitivity",
            "DLR-SMPC-uncalibrated": "uncalibrated uncertainty ablation",
            "uncontrolled": "uncontrolled contextual benchmark",
        }.get(comparator, comparator)

        for metric in PRIMARY_METRICS:
            effect_col = f"{metric}__ablation_minus_full"
            if effect_col not in g.columns:
                continue
            row, win = _cluster_effect_stats(
                g,
                effect_col,
                metric,
                {
                    "analysis_source": "Phase4D_ablation",
                    "stress_regime": gv["stress_regime"],
                    "feeder_count": gv["feeder_count"],
                    "mpc_horizon_h": 4,
                    "comparator_case": comparator,
                    "ablation_label": label,
                },
                "ablation_minus_full",
                reference_col=f"reference__{metric}",
                treatment_col=metric,
            )
            row["reference_case"] = "DLR-SMPC"
            rows.append(row)
            win["analysis_source"] = "Phase4D_ablation"
            windows.append(win)

    return pd.DataFrame(rows), pd.concat(windows, ignore_index=True)


# =============================================================================
# 7. Publication summary selection
# =============================================================================

def build_publication_summary(
    primary: pd.DataFrame,
    feasibility: pd.DataFrame,
    ablation: pd.DataFrame,
) -> pd.DataFrame:
    rows = []

    # Final receding-horizon primary effects at nominal and high stress.
    key_metrics = [
        "ev_unserved_mwh",
        "ev_service_ratio",
        "max_loading_pu",
        "binding_hours",
        "thermal_violation_count",
        "voltage_violation_count",
    ]
    p = primary[
        (primary["analysis_source"] == "Phase4C_true_receding_horizon")
        & (primary["metric"].isin(key_metrics))
    ].copy()
    for _, r in p.iterrows():
        rows.append({
            "section": "STR-vs-DLR receding-horizon effect",
            "stress_regime": r["stress_regime"],
            "feeder_count": r["feeder_count"],
            "mpc_horizon_h": r["mpc_horizon_h"],
            "comparison": "DLR-SMPC minus STR-SMPC",
            "metric": r["metric"],
            "estimate": r["window_equal_weight_mean_effect"],
            "ci95_low": r["ci95_low_cluster_bootstrap"],
            "ci95_high": r["ci95_high_cluster_bootstrap"],
            "p_value_cluster_signflip": r["cluster_signflip_p_value"],
            "n_windows": r["n_windows"],
            "n_pairs": r["n_pairs"],
            "interpretation": r["directional_interpretation"],
            "note": "continuous effect restricted to pairs strictly feasible under both STR and DLR",
        })

    # Feasibility restoration is a separate endpoint and includes infeasible STR pairs.
    f = feasibility[
        (feasibility["analysis_source"] == "Phase4C_true_receding_horizon")
        & (feasibility["stress_regime"].astype(str) == "high")
        & (feasibility["feeder_count"].astype(int) == 43)
    ].copy()
    for _, r in f.iterrows():
        rows.append({
            "section": "DLR feasibility restoration",
            "stress_regime": r["stress_regime"],
            "feeder_count": r["feeder_count"],
            "mpc_horizon_h": r["mpc_horizon_h"],
            "comparison": "STR infeasible / DLR feasible",
            "metric": "feasibility_restoration_rate",
            "estimate": r["restoration_rate_window_equal"],
            "ci95_low": r["restoration_ci95_low_cluster_bootstrap"],
            "ci95_high": r["restoration_ci95_high_cluster_bootstrap"],
            "p_value_cluster_signflip": r["feasibility_advantage_signflip_p"],
            "n_windows": r["n_windows"],
            "n_pairs": r["n_pairs"],
            "interpretation": "DLR_expands_feasible_region" if r["restoration_rate_window_equal"] > 0 else "no_restoration_observed",
            "note": f"restored_pairs={int(r['dlr_restores_feasibility_pairs'])}",
        })

    # Focused ablations at the frozen 4-h setting.
    abl_metrics = ["max_loading_pu", "thermal_violation_count", "voltage_violation_count", "cost"]
    a = ablation[ablation["metric"].isin(abl_metrics)].copy()
    for _, r in a.iterrows():
        rows.append({
            "section": "Ablation minus full DLR-SMPC",
            "stress_regime": r["stress_regime"],
            "feeder_count": r["feeder_count"],
            "mpc_horizon_h": 4,
            "comparison": str(r["comparator_case"]) + " minus DLR-SMPC",
            "metric": r["metric"],
            "estimate": r["window_equal_weight_mean_effect"],
            "ci95_low": r["ci95_low_cluster_bootstrap"],
            "ci95_high": r["ci95_high_cluster_bootstrap"],
            "p_value_cluster_signflip": r["cluster_signflip_p_value"],
            "n_windows": r["n_windows"],
            "n_pairs": r["n_pairs"],
            "interpretation": r["directional_interpretation"],
            "note": r["ablation_label"],
        })

    return pd.DataFrame(rows)


# =============================================================================
# 8. Main
# =============================================================================

def main() -> None:
    t0 = time.perf_counter()
    print("EPSR ROOT:", ROOT)
    print("Phase 4E statistical consolidation")
    print("Cluster unit: frozen evaluation window")
    print("Bootstrap reps:", BOOTSTRAP_REPS)

    data = _load_required()
    gate = _validate_cross_phase(data)
    if not gate["status"].all():
        print("\nPHASE 4E PRE-FREEZE GATE FAILED")
        print(gate.to_string(index=False))
        failed = gate.loc[~gate["status"], "gate"].tolist()
        raise RuntimeError("Phase 4E pre-freeze validation failed: " + ", ".join(failed))

    primary, primary_windows = build_primary_statistics(data)
    feas, feas_windows = build_feasibility_statistics(data)
    ablation, ablation_windows = build_ablation_statistics(data)

    # Standardize window-level export columns before concatenation.
    window_frames = []
    for w, source_kind in [
        (primary_windows, "continuous_primary_effect"),
        (ablation_windows, "continuous_ablation_effect"),
    ]:
        x = w.copy()
        x["window_effect_type"] = source_kind
        window_frames.append(x)

    # Feasibility window table has different columns; preserve in the same long CSV.
    fw = feas_windows.copy()
    fw["window_effect_type"] = "feasibility_endpoint"
    window_frames.append(fw)
    window_effects = pd.concat(window_frames, ignore_index=True, sort=False)

    publication = build_publication_summary(primary, feas, ablation)

    # Final freeze gates after statistical generation.
    post_gates = [
        {"gate": "primary_statistics_created", "status": len(primary) > 0, "detail": f"rows={len(primary)}"},
        {"gate": "feasibility_statistics_created", "status": len(feas) > 0, "detail": f"rows={len(feas)}"},
        {"gate": "ablation_statistics_created", "status": len(ablation) > 0, "detail": f"rows={len(ablation)}"},
        {"gate": "window_level_effects_created", "status": len(window_effects) > 0, "detail": f"rows={len(window_effects)}"},
        {"gate": "publication_summary_created", "status": len(publication) > 0, "detail": f"rows={len(publication)}"},
        {"gate": "primary_has_95pct_CI", "status": primary[["ci95_low_cluster_bootstrap", "ci95_high_cluster_bootstrap"]].notna().all().all(), "detail": "cluster bootstrap"},
        {"gate": "ablation_has_95pct_CI", "status": ablation[["ci95_low_cluster_bootstrap", "ci95_high_cluster_bootstrap"]].notna().all().all(), "detail": "cluster bootstrap"},
        {"gate": "inference_clustered_by_window", "status": bool((primary["inference_unit"] == "frozen evaluation window").all()), "detail": "avoids treating seeds as independent physical experiments"},
    ]
    final_gate = pd.concat([gate, pd.DataFrame(post_gates)], ignore_index=True)

    primary.to_csv(OUT_PRIMARY, index=False)
    feas.to_csv(OUT_FEAS, index=False)
    ablation.to_csv(OUT_ABL, index=False)
    window_effects.to_csv(OUT_WINDOW, index=False)
    publication.to_csv(OUT_PUBLICATION, index=False)
    final_gate.to_csv(OUT_GATE, index=False)

    runtime = time.perf_counter() - t0
    meta = {
        "phase": "4E statistical consolidation",
        "runtime_s": float(runtime),
        "random_seed": int(BASE_SEED),
        "bootstrap_reps": int(BOOTSTRAP_REPS),
        "confidence_level": 0.95,
        "cluster_unit": "frozen evaluation window",
        "point_estimator": "equal-weight mean of window-level paired effects",
        "bootstrap": "nonparametric resampling of complete frozen evaluation windows",
        "hypothesis_test": "two-sided paired sign-flip randomization on window-level effects",
        "effect_size": "mean(window-level effect) / SD(window-level effect)",
        "primary_comparison": "Phase 4C true hourly receding-horizon DLR-SMPC minus STR-SMPC",
        "continuous_effect_rule": "include only pairs strictly feasible under both STR and DLR",
        "feasibility_rule": "STR infeasible + DLR feasible is retained as DLR feasibility restoration",
        "ablation_effect_sign": "comparator minus full DLR-SMPC",
        "noPV_interpretation": "PV-absent sensitivity; not proof of active PV curtailment coordination value",
        "cost_interpretation": "penalty units, not monetary dollars",
        "phase5_boundary": "reduced-order 0.90–1.10 pu voltage screen; final AC/ACOPF/N-1/IEEE-39 validation pending",
        "input_sha256": {k: _sha256(v) for k, v in INPUTS.items()},
        "outputs": {
            "primary_statistics": str(OUT_PRIMARY),
            "feasibility_statistics": str(OUT_FEAS),
            "ablation_statistics": str(OUT_ABL),
            "window_level_effects": str(OUT_WINDOW),
            "publication_summary": str(OUT_PUBLICATION),
            "gate_summary": str(OUT_GATE),
        },
    }
    OUT_META.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nPHASE-4E RESEARCH GATE")
    print(final_gate.to_string(index=False))
    if not final_gate["status"].all():
        failed = final_gate.loc[~final_gate["status"], "gate"].tolist()
        raise RuntimeError("Phase 4E final gate failed: " + ", ".join(failed))

    print("\nPASS: PHASE 4E STATISTICAL CONSOLIDATION COMPLETE.")
    print("\nKey publication summary:")
    print(publication.to_string(index=False))
    print("\nSaved outputs:")
    for p in [OUT_PRIMARY, OUT_FEAS, OUT_ABL, OUT_WINDOW, OUT_PUBLICATION, OUT_GATE, OUT_META]:
        print(p)


if __name__ == "__main__":
    main()
