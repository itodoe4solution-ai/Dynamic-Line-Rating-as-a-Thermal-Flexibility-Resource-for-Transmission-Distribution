import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.eia import download_eia930_region, process_eia930_region, resample_eia930_to_15min

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg); ec=cfg["eia930"]
raw_path = ROOT/"01_raw/eia930/eia930_ciso_raw.csv"
if raw_path.exists():
    raw = pd.read_csv(raw_path)
else:
    raw = download_eia930_region(ec["balancing_authority"],start,end,raw_path)
proc=process_eia930_region(raw)
proc.to_csv(ROOT/"02_cleaned/eia930_ciso_hourly.csv",index=False)
if "system_load_mw_qc_flag" in proc.columns:
    qc_mask = proc["system_load_mw_qc_flag"].fillna("pass").ne("pass")
    anomalies = proc.loc[qc_mask, [
        "timestamp_utc", "system_load_mw_raw", "system_load_mw", "system_load_mw_qc_flag"
    ]].copy()
    anomalies.to_csv(ROOT/"05_quality_control/eia_anomaly_report.csv", index=False)
    source_gaps = proc.loc[proc["system_load_mw_qc_flag"].eq("source_gap"), [
        "timestamp_utc", "system_load_mw_raw", "system_load_mw", "system_load_mw_qc_flag"
    ]].copy()
    source_gaps.to_csv(ROOT/"05_quality_control/eia_source_gap_report.csv", index=False)
r15=resample_eia930_to_15min(proc,ec.get("resample_method","ffill"),end=end)
r15.to_csv(ROOT/"03_processed/eia930_ciso_15min.csv",index=False)
print(f"EIA-930 raw rows: {len(raw)}, hourly rows: {len(proc)}, 15-min rows: {len(r15)}")
if "system_load_mw_qc_flag" in proc.columns:
    print(proc["system_load_mw_qc_flag"].value_counts(dropna=False).to_string())
