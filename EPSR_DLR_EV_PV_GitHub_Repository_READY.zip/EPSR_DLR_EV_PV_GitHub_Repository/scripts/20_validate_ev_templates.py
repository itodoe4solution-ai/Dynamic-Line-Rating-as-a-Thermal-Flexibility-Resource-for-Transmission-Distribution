import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, ensure_directories
from epsr_pipeline.ev_validation import (
    extract_measured_session_shapes,
    repeated_stratified_kfold_template_validation,
    summarize_template_validation,
)

ensure_directories()
jsonl = ROOT/'01_raw/acn_ev/acn_sessions_timeseries.jsonl'
sessions = extract_measured_session_shapes(jsonl, n_bins=24)
if len(sessions) < 20:
    raise SystemExit(f'Only {len(sessions)} usable measured-current sessions found; validation cannot proceed.')

inventory = pd.DataFrame([{
    'session_id':s.session_id,
    'connection_time_utc':s.connection_time,
    'disconnect_time_utc':s.disconnect_time,
    'duration_h':s.duration_h,
    'duration_bucket':s.duration_bucket,
    'reported_kwh':s.delivered_kwh,
} for s in sessions])
inventory.to_csv(ROOT/'05_quality_control/ev_measured_current_inventory.csv', index=False)

detail = repeated_stratified_kfold_template_validation(sessions, n_splits=5, repeats=10, seed=20260819)
summary = summarize_template_validation(detail)
detail.to_csv(ROOT/'05_quality_control/ev_template_cross_validation.csv', index=False)
summary.to_csv(ROOT/'05_quality_control/ev_template_cross_validation_summary.csv', index=False)

bucket_counts = inventory.groupby('duration_bucket').agg(
    measured_sessions=('session_id','nunique'),
    measured_energy_kwh=('reported_kwh','sum'),
    median_duration_h=('duration_h','median'),
    start_utc=('connection_time_utc','min'),
    end_utc=('connection_time_utc','max'),
).reset_index()
bucket_counts.to_csv(ROOT/'05_quality_control/ev_measured_current_bucket_inventory.csv', index=False)

print(f'Usable measured-current sessions: {len(sessions)}')
print(f'Measured-current date range: {inventory.connection_time_utc.min()} -> {inventory.connection_time_utc.max()}')
print('\nMeasured sessions by duration bucket:')
print(bucket_counts.to_string(index=False))
print('\nCross-validation summary (ALL buckets):')
print(summary[summary.duration_bucket.eq('ALL')].to_string(index=False))
