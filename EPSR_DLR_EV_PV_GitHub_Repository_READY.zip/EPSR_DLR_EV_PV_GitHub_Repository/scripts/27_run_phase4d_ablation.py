from __future__ import annotations

"""
Phase 4D — Ablation analysis for the DLR-SMPC framework
========================================================

Purpose
-------
Quantify which elements of the proposed Phase-4 controller matter after the
primary STR-vs-DLR comparison (4A), stress sensitivity (4B), and true hourly
receding-horizon confirmation (4C).

Frozen Phase-4D design
----------------------
- feeder regimes: nominal 37 and high-stress 43
- MPC horizon: 4 h (primary ablation horizon; 2/4/8 h robustness already in 4C)
- control/re-optimization interval: 1 h
- frozen windows: all selected periods
- common seeds: 0..9
- cases:
    1. DLR-SMPC                  full proposed framework
    2. DLR-DMPC                  deterministic point-forecast MPC
    3. DLR-SMPC-noPV             PV resource disabled
    4. DLR-SMPC-uncalibrated     stochastic Gaussian residuals without
                                  empirical residual-distribution calibration
    5. uncontrolled              immediate charging / no optimization context

For 13 frozen windows:
    2 regimes × 13 windows × 10 seeds × 5 cases = 1300 rows.

Scientific boundaries
---------------------
- All ablation cases are evaluated against DLR thermal ratings so differences
  isolate controller/resource/uncertainty components rather than rating policy.
- The noPV case removes PV generation itself; its PV-curtailment metric is
  therefore structurally zero and must not be interpreted as an improvement.
- The uncontrolled case is contextual. It uses no optimizer and immediately
  serves realized reconstructed EV energy subject only to the physical class
  charge ceiling. Network violations are reported ex post.
- Reduced-order 0.90–1.10 pu voltage screening remains Phase 4 only. Definitive
  AC 0.95–1.05 pu / ACOPF / N-1 / IEEE-39 validation belongs to Phase 5.
"""

from pathlib import Path
from collections import Counter
import importlib.util
import json
import os
import time

import numpy as np
import pandas as pd
from scipy.optimize import linprog


# =============================================================================
# 1. Repository discovery and Phase-4C foundation import
# =============================================================================

def _resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path.cwd(),
        Path(__file__).resolve().parent.parent,
        Path(__file__).resolve().parent,
    ])
    for p in candidates:
        p = p.resolve()
        if (
            (p / "04_master" / "master_dataset_classified.csv").exists()
            and (p / "06_scenarios" / "selected_periods.csv").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate EPSR repository root. Run from the repository root "
        "or set EPSR_ROOT to that folder."
    )


ROOT = _resolve_root()
PHASE4C_ENGINE = ROOT / "scripts" / "26_run_phase4c_receding.py"
if not PHASE4C_ENGINE.exists():
    raise FileNotFoundError(
        f"Required Phase-4C engine not found: {PHASE4C_ENGINE}\n"
        "Copy 26_run_phase4c_receding.py into ROOT/scripts first."
    )

spec = importlib.util.spec_from_file_location("phase4c_engine", PHASE4C_ENGINE)
if spec is None or spec.loader is None:
    raise RuntimeError("Could not import Phase-4C engine.")
p4c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p4c)
p4b = p4c.p4b
p4 = p4c.p4


# =============================================================================
# 2. Outputs
# =============================================================================

OUTDIR = ROOT / "09_simulation_inputs" / "results"
OUTDIR.mkdir(parents=True, exist_ok=True)

OUT = OUTDIR / "phase4d_ablation_results.csv"
SUMMARY_OUT = OUTDIR / "phase4d_ablation_summary.csv"
PAIRED_OUT = OUTDIR / "phase4d_paired_effects.csv"
FEAS_OUT = OUTDIR / "phase4d_feasibility_summary.csv"
META_OUT = OUTDIR / "phase4d_metadata.json"


# =============================================================================
# 3. Frozen Phase-4D design
# =============================================================================

REGIMES = ["nominal", "high"]
MPC_HORIZON_H = 4
COMMON_SEEDS = list(range(10))

CASES = [
    "DLR-SMPC",
    "DLR-DMPC",
    "DLR-SMPC-noPV",
    "DLR-SMPC-uncalibrated",
    "uncontrolled",
]

CASE_CONFIG = {
    "DLR-SMPC": {
        "controller": "SMPC",
        "uncertainty": "empirical_calibration_residual_bootstrap",
        "pv_enabled": True,
        "optimization_applicable": True,
        "stochastic_seed_used": True,
        "role": "full_reference",
    },
    "DLR-DMPC": {
        "controller": "deterministic MPC",
        "uncertainty": "point_forecast_only",
        "pv_enabled": True,
        "optimization_applicable": True,
        "stochastic_seed_used": False,
        "role": "ablation_stochastic_control",
    },
    "DLR-SMPC-noPV": {
        "controller": "SMPC",
        "uncertainty": "empirical_calibration_residual_bootstrap",
        "pv_enabled": False,
        "optimization_applicable": True,
        "stochastic_seed_used": True,
        "role": "ablation_pv_resource",
    },
    "DLR-SMPC-uncalibrated": {
        "controller": "SMPC",
        "uncertainty": "zero_mean_gaussian_residual_scenarios",
        "pv_enabled": True,
        "optimization_applicable": True,
        "stochastic_seed_used": True,
        "role": "ablation_uncertainty_calibration",
    },
    "uncontrolled": {
        "controller": "none",
        "uncertainty": "none",
        "pv_enabled": True,
        "optimization_applicable": False,
        "stochastic_seed_used": False,
        "role": "context_only",
    },
}

SMOKE_TEST = os.environ.get("PHASE4D_SMOKE_TEST", "0").strip() == "1"

SCENARIO_COUNT = p4b.SCENARIO_COUNT
VLOW, VHIGH = p4b.VLOW, p4b.VHIGH
BINDING_THRESHOLD = p4b.BINDING_THRESHOLD
W_DUE = p4b.W_DUE
W_CURTAIL = p4b.W_CURTAIL
W_BACKLOG = p4b.W_BACKLOG
W_RAMP = p4b.W_RAMP
RNG_BASE = p4b.RNG_BASE
CLASSES = p4b.CLASSES
C = len(CLASSES)

hourly = p4b.hourly
periods_all = p4.periods.copy()
regime_rows = p4b.regime_rows

for regime in REGIMES:
    if regime not in regime_rows:
        raise RuntimeError(f"Missing frozen Phase-2 feeder regime: {regime}")

if regime_rows["nominal"]["feeder_count"] != 37:
    raise RuntimeError("Frozen nominal feeder population is not 37.")
if regime_rows["high"]["feeder_count"] != 43:
    raise RuntimeError("Frozen high-stress feeder population is not 43.")


# =============================================================================
# 4. Forecast helpers for the ablation variants
# =============================================================================

def _point_forecasts(origin_i: int, H: int):
    """Return deterministic current-observation + future selected-model forecasts."""
    ev = np.zeros(H, dtype=float)
    pv = np.zeros(H, dtype=float)
    ev[0] = max(0.0, float(hourly.loc[origin_i, "ev_power_kw"]))
    pv[0] = max(0.0, float(hourly.loc[origin_i, "pv_ac_kw"]))

    for k in range(1, H):
        ti = origin_i + k
        if ti >= len(hourly):
            continue
        evhat = float(p4b.forecast["ev_power_kw"][k][ti])
        pvhat = float(p4b.forecast["pv_ac_kw"][k][ti])
        ev[k] = max(0.0, evhat) if np.isfinite(evhat) else 0.0
        pv[k] = max(0.0, pvhat) if np.isfinite(pvhat) else 0.0
    return ev, pv


def _gaussian_uncalibrated_scenarios(origin_i: int, seed: int, H: int):
    """Stochastic but deliberately uncalibrated residual model.

    Future selected-model point forecasts are perturbed with zero-mean Gaussian
    noise whose scale is the calibration-residual standard deviation. This keeps
    uncertainty stochastic but removes the empirical residual-distribution /
    quantile calibration used by the full DLR-SMPC case.
    """
    rng = np.random.default_rng(seed)
    ev_point, pv_point = _point_forecasts(origin_i, H)

    ev_s = np.repeat(ev_point[None, :], SCENARIO_COUNT, axis=0)
    pv_s = np.repeat(pv_point[None, :], SCENARIO_COUNT, axis=0)

    for k in range(1, H):
        er = np.asarray(p4b.resid_pool["ev_power_kw"][k], dtype=float)
        pr = np.asarray(p4b.resid_pool["pv_ac_kw"][k], dtype=float)
        er = er[np.isfinite(er)]
        pr = pr[np.isfinite(pr)]
        esd = float(np.std(er, ddof=1)) if len(er) > 1 else 0.0
        psd = float(np.std(pr, ddof=1)) if len(pr) > 1 else 0.0
        ev_s[:, k] = np.maximum(
            0.0,
            ev_point[k] + rng.normal(0.0, esd, size=SCENARIO_COUNT),
        )
        pv_s[:, k] = np.maximum(
            0.0,
            pv_point[k] + rng.normal(0.0, psd, size=SCENARIO_COUNT),
        )

    return ev_s, pv_s


def _forecast_envelope(origin_i: int, seed: int, case: str, H: int):
    """Build the EV/PV planning envelope appropriate to one ablation case."""
    cfg = CASE_CONFIG[case]

    if case == "DLR-DMPC":
        ev, pv = _point_forecasts(origin_i, H)
        if not cfg["pv_enabled"]:
            pv[:] = 0.0
        return {
            "ev_med": ev,
            "ev_hi": ev,
            "pv_lo": pv,
            "pv_hi": pv,
        }

    if case == "DLR-SMPC-uncalibrated":
        ev_s, pv_s = _gaussian_uncalibrated_scenarios(origin_i, seed, H)
    else:
        ev_s, pv_s = p4b.scenario_forecasts_h(origin_i, seed, H)

    if not cfg["pv_enabled"]:
        pv_s[:] = 0.0

    return {
        "ev_med": np.quantile(ev_s, 0.50, axis=0),
        "ev_hi": np.quantile(ev_s, 0.90, axis=0),
        "pv_lo": np.quantile(pv_s, 0.10, axis=0),
        "pv_hi": np.quantile(pv_s, 0.90, axis=0),
    }


# =============================================================================
# 5. Generalized DLR receding-horizon LP for the optimized ablations
# =============================================================================

def _solve_ablation_plan(
    *,
    win: pd.DataFrame,
    local_t: int,
    seed: int,
    case: str,
    regime: str,
    queues: dict[str, dict[int, float]],
    prev_x: dict[str, float],
):
    cfg = CASE_CONFIG[case]
    if not cfg["optimization_applicable"]:
        raise ValueError("_solve_ablation_plan called for non-optimization case.")

    reg = regime_rows[regime]
    counts = reg["counts"]
    H = int(min(MPC_HORIZON_H, len(win) - local_t))
    _, NVAR, vid = p4b.make_lp_index(H)

    ts0 = win.iloc[local_t].timestamp_utc
    gi0 = p4.h_index[ts0]

    scenario_seed = (
        RNG_BASE
        + seed * 100_000
        + local_t * 97
        + MPC_HORIZON_H * 1_009
    )
    env = _forecast_envelope(gi0, scenario_seed, case, H)
    ev_med = env["ev_med"]
    ev_hi = env["ev_hi"]
    pv_lo = env["pv_lo"]
    pv_hi = env["pv_hi"]

    A, b = [], []
    cobj = np.zeros(NVAR, dtype=float)
    bounds_lp = []

    for ci, c in enumerate(CLASSES):
        for k in range(H):
            cobj[vid("x", ci, k)] = -W_BACKLOG * counts[c]
            cobj[vid("cur", ci, k)] = W_CURTAIL * counts[c]
            cobj[vid("slack", ci, k)] = W_DUE * counts[c]
            cobj[vid("ramp", ci, k)] = W_RAMP * counts[c]

    for block in ["x", "cur", "slack", "ramp"]:
        for ci, c in enumerate(CLASSES):
            for k in range(H):
                if block == "x":
                    ub = p4.pmax_mw[c]
                elif block == "cur":
                    ub = max(0.0, float(pv_hi[k]) * p4.pv_scale[c] / 1000.0)
                else:
                    ub = None
                bounds_lp.append((0.0, ub))

    # EV availability, deadlines, and ramping.
    for ci, c in enumerate(CLASSES):
        B0 = p4.queue_energy(queues[c])
        qlist = list(queues[c].items())

        for k in range(H):
            avail = B0
            for jj in range(1, k + 1):
                avail += max(0.0, float(ev_med[jj])) * p4.ev_scale[c] / 1000.0

            p4b.add_ub(
                A,
                b,
                NVAR,
                {vid("x", ci, jj): 1.0 for jj in range(k + 1)},
                avail,
            )

            due = sum(amt for due_t, amt in qlist if due_t <= local_t + k)
            for jj in range(1, k + 1):
                future_arr = max(0.0, float(ev_hi[jj])) * p4.ev_scale[c] / 1000.0
                for d, prob in p4.DURATION_PROB[c].items():
                    if local_t + jj + d <= local_t + k:
                        due += future_arr * prob

            coef = {vid("x", ci, jj): -1.0 for jj in range(k + 1)}
            coef[vid("slack", ci, k)] = -1.0
            p4b.add_ub(A, b, NVAR, coef, -due)

            if k == 0:
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {vid("x", ci, 0): 1.0, vid("ramp", ci, 0): -1.0},
                    prev_x[c],
                )
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {vid("x", ci, 0): -1.0, vid("ramp", ci, 0): -1.0},
                    -prev_x[c],
                )
            else:
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, k): 1.0,
                        vid("x", ci, k - 1): -1.0,
                        vid("ramp", ci, k): -1.0,
                    },
                    0.0,
                )
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, k): -1.0,
                        vid("x", ci, k - 1): 1.0,
                        vid("ramp", ci, k): -1.0,
                    },
                    0.0,
                )

    # Reduced-order feeder voltage + IEEE-118 DLR corridor constraints.
    for k in range(H):
        ti = min(gi0 + k, len(hourly) - 1)
        future_ts = hourly.loc[ti, "timestamp_utc"]

        lf = float(hourly.loc[ti, "load_forecast_mw"])
        native_lo_factor = max(0.0, (lf + p4.load_q10) / p4.annual_system_max)
        native_hi_factor = max(0.0, (lf + p4.load_q90) / p4.annual_system_max)
        native_lo = 3.715 * native_lo_factor
        native_hi = 3.715 * native_hi_factor

        for ci, c in enumerate(CLASSES):
            pmin, _ = p4.voltage_bounds(native_lo_factor)
            _, pmaxv = p4.voltage_bounds(native_hi_factor)

            pvlow = max(0.0, float(pv_lo[k])) * p4.pv_scale[c] / 1000.0
            pvhigh = max(0.0, float(pv_hi[k])) * p4.pv_scale[c] / 1000.0

            p4b.add_ub(
                A,
                b,
                NVAR,
                {vid("x", ci, k): 1.0, vid("cur", ci, k): 1.0},
                pmaxv - native_hi + pvlow,
            )
            p4b.add_ub(
                A,
                b,
                NVAR,
                {vid("x", ci, k): -1.0, vid("cur", ci, k): -1.0},
                native_lo - pvhigh - pmin,
            )

        const_hi = 0.0
        const_lo = 0.0
        coeff = {}
        for ci, c in enumerate(CLASSES):
            n = counts[c]
            pvlow = max(0.0, float(pv_lo[k])) * p4.pv_scale[c] / 1000.0
            pvhigh = max(0.0, float(pv_hi[k])) * p4.pv_scale[c] / 1000.0
            const_hi += n * (native_hi - pvlow)
            const_lo += n * (native_lo - pvhigh)
            coeff[vid("x", ci, k)] = coeff.get(vid("x", ci, k), 0.0) + n
            coeff[vid("cur", ci, k)] = coeff.get(vid("cur", ci, k), 0.0) + n

        for cor in p4.corridors:
            rr = p4.rating_lookup[cor["cid"]]
            rating = float(rr.loc[future_ts, "dlr_mva"])
            base = cor["base"]
            ptdf = cor["ptdf"]

            coef_hi = {j: (-ptdf) * v for j, v in coeff.items()}
            p4b.add_ub(A, b, NVAR, coef_hi, rating - base + ptdf * const_hi)
            p4b.add_ub(A, b, NVAR, coef_hi, rating - base + ptdf * const_lo)

            coef_lo = {j: ptdf * v for j, v in coeff.items()}
            p4b.add_ub(A, b, NVAR, coef_lo, rating + base - ptdf * const_hi)
            p4b.add_ub(A, b, NVAR, coef_lo, rating + base - ptdf * const_lo)

    t0 = time.perf_counter()
    res = linprog(
        cobj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=bounds_lp,
        method="highs",
    )
    solve_s = time.perf_counter() - t0

    if res.success:
        first_x = np.asarray([res.x[vid("x", ci, 0)] for ci in range(C)], dtype=float)
        first_cur = np.asarray([res.x[vid("cur", ci, 0)] for ci in range(C)], dtype=float)
    else:
        first_x = np.zeros(C, dtype=float)
        first_cur = np.zeros(C, dtype=float)

    return {
        "success": bool(res.success),
        "status": int(res.status),
        "message": str(res.message),
        "solve_time_s": float(solve_s),
        "first_x": first_x,
        "first_cur": first_cur,
        "effective_horizon_h": H,
    }


# =============================================================================
# 6. One week / seed / ablation case
# =============================================================================

def _required_due_energy(win: pd.DataFrame, counts: dict[str, int]) -> float:
    total = 0.0
    for j, row in win.iterrows():
        for c in CLASSES:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if row.timestamp_utc > p4.ev_support_end_ts:
                arr = 0.0
            for d, prob in p4.DURATION_PROB[c].items():
                if j + d <= len(win) - 1:
                    total += arr * prob * counts[c]
    return float(total)


def run_case_ablation(window_row, seed: int, case: str, regime: str):
    if case not in CASE_CONFIG:
        raise ValueError(case)
    if regime not in REGIMES:
        raise ValueError(regime)

    cfg = CASE_CONFIG[case]
    reg = regime_rows[regime]
    counts = reg["counts"]
    feeder_count = reg["feeder_count"]

    start = pd.Timestamp(window_row.start_utc)
    end = pd.Timestamp(window_row.end_utc_exclusive)
    win = hourly[
        (hourly.timestamp_utc >= start)
        & (hourly.timestamp_utc < end)
    ].copy().reset_index(drop=True)

    if len(win) != 168:
        raise RuntimeError(
            f"{window_row.scenario}: expected 168 hourly rows, got {len(win)}"
        )

    queues = {c: {} for c in CLASSES}
    prev_x = {c: 0.0 for c in CLASSES}

    required_due = _required_due_energy(win, counts)
    unserved = 0.0
    curtail_total = 0.0
    pcc_energy = 0.0
    ramp_total = 0.0
    solver_time = 0.0
    solver_fail = 0
    infeasible_count = 0
    other_failure_count = 0
    failure_status_counts = Counter()
    first_failure_hour = None
    first_failure_timestamp = None

    all_loadings = []
    binding_hours = 0
    thermal_viol = 0
    voltage_viol = 0

    for local_t, row in win.iterrows():
        ts = row.timestamp_utc

        # Same empirical EV-energy arrival process for every case.
        for c in CLASSES:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if ts > p4.ev_support_end_ts:
                arr = 0.0
            if arr > 0.0:
                p4.add_energy_arrival(queues[c], local_t, arr, c)

        if cfg["optimization_applicable"]:
            sol = _solve_ablation_plan(
                win=win,
                local_t=local_t,
                seed=seed,
                case=case,
                regime=regime,
                queues=queues,
                prev_x=prev_x,
            )
            solver_time += sol["solve_time_s"]
            if not sol["success"]:
                solver_fail += 1
                failure_status_counts[sol["status"]] += 1
                if sol["status"] == 2:
                    infeasible_count += 1
                else:
                    other_failure_count += 1
                if first_failure_hour is None:
                    first_failure_hour = int(local_t)
                    first_failure_timestamp = str(ts)
            first_x = sol["first_x"]
            first_cur = sol["first_cur"]
        else:
            # Context-only uncontrolled policy: immediately serve the realized
            # reconstructed EV energy profile (subject to the same class charge
            # ceiling), with PV uncurtailed. It does not enforce network limits.
            first_x = np.zeros(C, dtype=float)
            first_cur = np.zeros(C, dtype=float)
            for ci, c in enumerate(CLASSES):
                requested = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
                if ts > p4.ev_support_end_ts:
                    requested = 0.0
                first_x[ci] = min(requested, p4.pmax_mw[c], p4.queue_energy(queues[c]))

        actual_factor = float(row.system_load_mw) / p4.annual_system_max
        native_actual = 3.715 * actual_factor
        pcc = 0.0
        hour_vviol = 0

        for ci, c in enumerate(CLASSES):
            if cfg["pv_enabled"]:
                actual_pv = max(
                    0.0,
                    float(row.pv_ac_kw) * p4.pv_scale[c] / 1000.0,
                )
            else:
                actual_pv = 0.0

            cur = min(float(first_cur[ci]), actual_pv)
            avail = p4.queue_energy(queues[c])
            x = min(float(first_x[ci]), p4.pmax_mw[c], avail)
            x = p4.serve_fifo(queues[c], x)
            lost = p4.expire_due(queues[c], local_t)

            unserved += lost * counts[c]
            curtail_total += cur * counts[c]
            ramp_total += abs(x - prev_x[c]) * counts[c]
            prev_x[c] = x

            net = native_actual + x - (actual_pv - cur)
            pcc += counts[c] * net

            pmin, pmaxv = p4.voltage_bounds(actual_factor)
            if net < pmin - 1e-6 or net > pmaxv + 1e-6:
                hour_vviol += counts[c]

        voltage_viol += hour_vviol
        pcc_energy += pcc

        hour_binding = False
        for cor in p4.corridors:
            rr = p4.rating_lookup[cor["cid"]]
            rating = float(rr.loc[ts, "dlr_mva"])
            flow = cor["base"] - cor["ptdf"] * pcc
            loading = abs(flow) / rating
            all_loadings.append(loading)
            if loading >= BINDING_THRESHOLD:
                hour_binding = True
            if loading > 1.000001:
                thermal_viol += 1
        if hour_binding:
            binding_hours += 1

    last = len(win) - 1
    for c in CLASSES:
        unserved += p4.expire_due(queues[c], last) * counts[c]

    service_ratio = (
        1.0
        if required_due <= 1e-12
        else max(0.0, 1.0 - unserved / required_due)
    )
    cost = W_DUE * unserved + W_CURTAIL * curtail_total + W_RAMP * ramp_total
    ev_support_fraction = float(np.mean(win.timestamp_utc <= p4.ev_support_end_ts))

    strict_feasible = bool(solver_fail == 0) if cfg["optimization_applicable"] else True
    realized_security_clean = bool(thermal_viol == 0 and voltage_viol == 0)

    return {
        "network": f"IEEE118+{feeder_count}xIEEE33",
        "window_id": window_row.scenario,
        "seed": int(seed),
        "case": case,
        "role": cfg["role"],
        "controller": cfg["controller"],
        "rating_policy": "DLR",
        "pv_enabled": bool(cfg["pv_enabled"]),
        "optimization_applicable": bool(cfg["optimization_applicable"]),
        "stochastic_seed_used": bool(cfg["stochastic_seed_used"]),
        "ev_unserved_mwh": float(unserved),
        "ev_service_ratio": float(service_ratio),
        "pv_curtailment_mwh": float(curtail_total),
        "pcc_energy_mwh": float(pcc_energy),
        "mean_loading_pu": float(np.mean(all_loadings)),
        "max_loading_pu": float(np.max(all_loadings)),
        "binding_hours": int(binding_hours),
        "voltage_violation_count": int(voltage_viol),
        "thermal_violation_count": int(thermal_viol),
        "realized_security_clean": realized_security_clean,
        "cost": float(cost),
        "solve_time_s": float(solver_time),
        "stress_regime": regime,
        "target_loading_pu": float(reg["target_loading_pu"]),
        "phase2_predicted_loading_pu": float(reg["predicted_loading_pu"]),
        "feeder_count": int(feeder_count),
        "class_A_count": int(counts["A"]),
        "class_B_count": int(counts["B"]),
        "class_C_count": int(counts["C"]),
        "class_D_count": int(counts["D"]),
        "class_E_count": int(counts["E"]),
        "required_ev_due_mwh": float(required_due),
        "served_ev_due_mwh": float(max(0.0, required_due - unserved)),
        "pcc_bus": 78,
        "slack_bus": 69,
        "critical_branch_id": 121,
        "mpc_horizon_h": int(MPC_HORIZON_H),
        "control_interval_h": 1,
        "reoptimization_interval_h": 1 if cfg["optimization_applicable"] else 0,
        "actions_executed_per_solve": 1 if cfg["optimization_applicable"] else 0,
        "scenario_count": (
            int(SCENARIO_COUNT)
            if case in ["DLR-SMPC", "DLR-SMPC-noPV", "DLR-SMPC-uncalibrated"]
            else (1 if case == "DLR-DMPC" else 0)
        ),
        "uncertainty_method": cfg["uncertainty"],
        "uncertainty_calibrated": case in ["DLR-SMPC", "DLR-SMPC-noPV"],
        "voltage_limit_low_pu": float(VLOW),
        "voltage_limit_high_pu": float(VHIGH),
        "voltage_check_method": (
            "IEEE-33 balanced BFS-derived reduced-order active-power envelope; "
            "Phase-5 AC check pending"
        ),
        "rating_forecast_assumption": (
            "short-horizon DLR rating chronology treated as known; "
            "DLR weather-forecast uncertainty deferred"
        ),
        "ev_support_fraction": float(ev_support_fraction),
        "solver_fail_count": int(solver_fail),
        "solver_infeasible_count": int(infeasible_count),
        "solver_other_failure_count": int(other_failure_count),
        "strict_security_feasible": strict_feasible,
        "first_failure_hour": first_failure_hour,
        "first_failure_timestamp_utc": first_failure_timestamp,
        "solver_status_counts_json": json.dumps(
            {str(k): int(v) for k, v in sorted(failure_status_counts.items())}
        ),
        "cost_units": (
            "penalty units = 1e6*unserved_MWh + 1e3*curtail_MWh + 0.1*ramp_MW"
        ),
        "phase4d_status": (
            "4-h true-hourly receding-horizon DLR ablation; reduced-order T-D screen; "
            "Phase-5 AC/N-1 validation pending"
        ),
    }


# =============================================================================
# 7. Feasibility and paired-effect exports
# =============================================================================

PAIR_KEYS = [
    "stress_regime",
    "feeder_count",
    "network",
    "window_id",
    "seed",
]

METRICS = [
    "ev_unserved_mwh",
    "ev_service_ratio",
    "pv_curtailment_mwh",
    "pcc_energy_mwh",
    "mean_loading_pu",
    "max_loading_pu",
    "binding_hours",
    "thermal_violation_count",
    "voltage_violation_count",
    "cost",
]


def build_paired_effects(df: pd.DataFrame) -> pd.DataFrame:
    ref_name = "DLR-SMPC"
    ref = df[df["case"] == ref_name].copy()
    ref = ref[PAIR_KEYS + METRICS + ["strict_security_feasible"]]
    ref = ref.rename(
        columns={
            **{m: f"reference__{m}" for m in METRICS},
            "strict_security_feasible": "reference_strict_feasible",
        }
    )

    rows = []
    for comparator in [c for c in CASES if c != ref_name]:
        z = df[df["case"] == comparator].copy()
        keep = PAIR_KEYS + METRICS + [
            "strict_security_feasible",
            "optimization_applicable",
        ]
        z = z[keep].merge(ref, on=PAIR_KEYS, how="inner")
        z["reference_case"] = ref_name
        z["comparator_case"] = comparator

        if CASE_CONFIG[comparator]["optimization_applicable"]:
            z["pair_valid_for_continuous_effect"] = (
                z["reference_strict_feasible"]
                & z["strict_security_feasible"]
            )
        else:
            # Uncontrolled has no optimization feasibility concept. Require the
            # full DLR-SMPC reference to be strictly feasible; realized network
            # violations of uncontrolled remain explicit metrics.
            z["pair_valid_for_continuous_effect"] = z["reference_strict_feasible"]

        for m in METRICS:
            z[f"{m}__ablation_minus_full"] = z[m] - z[f"reference__{m}"]

        rows.append(z)

    return pd.concat(rows, ignore_index=True)


# =============================================================================
# 8. Main
# =============================================================================

def main():
    start_all = time.perf_counter()

    if SMOKE_TEST:
        periods = periods_all.iloc[:1].copy()
        seeds = [0]
        regimes = ["nominal"]
    else:
        periods = periods_all.copy()
        seeds = COMMON_SEEDS
        regimes = REGIMES

    expected_rows = len(regimes) * len(periods) * len(seeds) * len(CASES)

    print("EPSR ROOT:", ROOT)
    print("Phase 4D output:", OUT)
    print("Regimes:", regimes)
    print("MPC horizon: 4 h")
    print("Hourly receding horizon: yes for optimized cases")
    print("Windows:", len(periods))
    print("Seeds:", seeds)
    print("Cases:", CASES)
    print("Expected rows:", expected_rows)

    rows = []
    job = 0
    for regime in regimes:
        for _, window_row in periods.iterrows():
            for seed in seeds:
                for case in CASES:
                    job += 1
                    if job == 1 or job % 20 == 0 or job == expected_rows:
                        print(
                            f"[{job:4d}/{expected_rows}] {regime} "
                            f"N={regime_rows[regime]['feeder_count']} "
                            f"{window_row.scenario} seed={seed} {case}"
                        )
                    rows.append(run_case_ablation(window_row, seed, case, regime))

    df = pd.DataFrame(rows)

    if len(df) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} rows, generated {len(df)}.")
    if set(df["case"]) != set(CASES):
        raise RuntimeError("Phase-4D cases are incomplete.")
    if not df["ev_service_ratio"].between(0, 1).all():
        raise RuntimeError("EV service ratio outside [0,1].")

    group_sizes = df.groupby(PAIR_KEYS).size()
    if not group_sizes.eq(len(CASES)).all():
        raise RuntimeError("Incomplete five-case paired ablation design.")

    # Numerical/unknown solver errors are not acceptable. Hard infeasibility is
    # retained as a stress-regime finding and classified separately.
    other_fail = int(df["solver_other_failure_count"].sum())
    if other_fail != 0:
        raise RuntimeError(
            f"Phase 4D contains {other_fail} non-infeasibility solver failures."
        )

    df = df.sort_values(
        ["stress_regime", "feeder_count", "window_id", "seed", "case"]
    ).reset_index(drop=True)
    df.to_csv(OUT, index=False)

    summary = (
        df.groupby(["stress_regime", "feeder_count", "case"])
        .agg(
            runs=("case", "size"),
            optimization_runs=("optimization_applicable", "sum"),
            strict_feasible_runs=("strict_security_feasible", "sum"),
            failed_runs=("solver_fail_count", lambda s: int((s > 0).sum())),
            failed_hours=("solver_fail_count", "sum"),
            infeasible_hours=("solver_infeasible_count", "sum"),
            other_solver_failure_hours=("solver_other_failure_count", "sum"),
            mean_ev_unserved_mwh=("ev_unserved_mwh", "mean"),
            mean_ev_service_ratio=("ev_service_ratio", "mean"),
            mean_pv_curtailment_mwh=("pv_curtailment_mwh", "mean"),
            mean_pcc_energy_mwh=("pcc_energy_mwh", "mean"),
            mean_loading_pu=("mean_loading_pu", "mean"),
            mean_max_loading_pu=("max_loading_pu", "mean"),
            binding_hours=("binding_hours", "sum"),
            thermal_violations=("thermal_violation_count", "sum"),
            voltage_violations=("voltage_violation_count", "sum"),
            realized_security_clean_runs=("realized_security_clean", "sum"),
            solve_time_s=("solve_time_s", "sum"),
        )
        .reset_index()
    )
    summary["strict_feasible_fraction"] = np.where(
        summary["optimization_runs"] > 0,
        summary["strict_feasible_runs"] / summary["runs"],
        np.nan,
    )
    summary.to_csv(SUMMARY_OUT, index=False)

    feas = (
        df.groupby(["stress_regime", "feeder_count", "case"])
        .agg(
            runs=("case", "size"),
            optimization_applicable=("optimization_applicable", "first"),
            strict_feasible_runs=("strict_security_feasible", "sum"),
            failed_runs=("solver_fail_count", lambda s: int((s > 0).sum())),
            infeasible_hours=("solver_infeasible_count", "sum"),
            other_failure_hours=("solver_other_failure_count", "sum"),
            thermal_violations=("thermal_violation_count", "sum"),
            voltage_violations=("voltage_violation_count", "sum"),
            realized_security_clean_runs=("realized_security_clean", "sum"),
        )
        .reset_index()
    )
    feas["realized_security_clean_fraction"] = (
        feas["realized_security_clean_runs"] / feas["runs"]
    )
    feas.to_csv(FEAS_OUT, index=False)

    paired = build_paired_effects(df)
    paired.to_csv(PAIRED_OUT, index=False)

    runtime = time.perf_counter() - start_all
    meta = {
        "rows": int(len(df)),
        "windows": int(len(periods)),
        "seeds": seeds,
        "feeder_regimes": regimes,
        "feeder_counts": [regime_rows[r]["feeder_count"] for r in regimes],
        "mpc_horizon_h": int(MPC_HORIZON_H),
        "control_interval_h": 1,
        "cases": CASES,
        "case_config": CASE_CONFIG,
        "scenario_count_full_smpc": int(SCENARIO_COUNT),
        "runtime_s": float(runtime),
        "smoke_test": bool(SMOKE_TEST),
        "outputs": {
            "results": str(OUT),
            "summary": str(SUMMARY_OUT),
            "paired_effects": str(PAIRED_OUT),
            "feasibility_summary": str(FEAS_OUT),
        },
        "pair_effect_sign": (
            "raw paired effects are comparator/ablation minus full DLR-SMPC; "
            "positive is not universally better because metric directions differ"
        ),
        "uncalibrated_definition": (
            "selected point forecasts plus zero-mean Gaussian residual noise scaled "
            "by calibration-residual standard deviation; no empirical residual-"
            "distribution/conformal quantile calibration"
        ),
        "uncontrolled_definition": (
            "immediate charging of realized reconstructed EV hourly energy subject "
            "to class charging ceiling; PV uncurtailed; no network-aware optimizer; "
            "network security evaluated ex post"
        ),
        "scientific_note": (
            "Phase 4D isolates stochastic control, PV resource presence, and empirical "
            "uncertainty calibration at the frozen 4-h receding-horizon setting. "
            "The uncontrolled case is contextual and noPV curtailment is structurally zero."
        ),
    }
    META_OUT.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nPASS: Phase-4D ablation result contract generated.")
    print("Saved:", OUT)
    print("Rows:", len(df))
    print("Other solver failures:", other_fail)
    print("\nABLATION SUMMARY")
    print(summary.to_string(index=False))
    print("\nFEASIBILITY SUMMARY")
    print(feas.to_string(index=False))

    valid = paired[paired["pair_valid_for_continuous_effect"]].copy()
    if len(valid):
        print("\nVALID PAIRED EFFECTS: ABLATION MINUS FULL DLR-SMPC")
        cols = [
            "ev_unserved_mwh__ablation_minus_full",
            "ev_service_ratio__ablation_minus_full",
            "max_loading_pu__ablation_minus_full",
            "thermal_violation_count__ablation_minus_full",
            "voltage_violation_count__ablation_minus_full",
        ]
        print(
            valid.groupby(["stress_regime", "feeder_count", "comparator_case"])[cols]
            .mean()
            .to_string()
        )

    print("runtime_s", runtime)
    return df


if __name__ == "__main__":
    main()
