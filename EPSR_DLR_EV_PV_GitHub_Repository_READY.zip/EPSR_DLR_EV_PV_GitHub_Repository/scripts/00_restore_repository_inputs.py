from pathlib import Path
import gzip
import shutil

ROOT = Path(__file__).resolve().parent.parent
src = ROOT / "09_simulation_inputs" / "phase2_td" / "corridor_ratings_15min.csv.gz"
dst = ROOT / "09_simulation_inputs" / "phase2_td" / "corridor_ratings_15min.csv"

if dst.exists():
    print(f"Already present: {dst.relative_to(ROOT)}")
elif not src.exists():
    raise FileNotFoundError(src)
else:
    with gzip.open(src, "rb") as fin, open(dst, "wb") as fout:
        shutil.copyfileobj(fin, fout, length=1024 * 1024)
    print(f"Restored: {dst.relative_to(ROOT)}")
