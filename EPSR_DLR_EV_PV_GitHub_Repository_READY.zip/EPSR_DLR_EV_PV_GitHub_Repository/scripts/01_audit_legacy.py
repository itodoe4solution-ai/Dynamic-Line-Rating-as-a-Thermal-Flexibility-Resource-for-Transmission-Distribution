import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pathlib import Path
import numpy as np
import pandas as pd

from epsr_pipeline.common import ROOT, ensure_directories

ensure_directories()
base = ROOT / "01_legacy_dataset"
out = ROOT / "05_quality_control"

reports = []
for name in ["ev_profile.csv", "weather.csv", "pv_profile.csv", "load_profile.csv", "master_timeseries_20190501_20190508_15min.csv"]:
    p = base / name
    if not p.exists():
        continue
    df = pd.read_csv(p)
    ts_col = "timestamp" if "timestamp" in df.columns else None
    row = {"file": name, "rows": len(df), "columns": len(df.columns)}
    if ts_col:
        ts = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
        row["duplicate_timestamps"] = int(ts.duplicated().sum())
        if ts.notna().any():
            expected = pd.date_range(ts.min(), ts.max(), freq="15min", tz="UTC")
            row["missing_15min_timestamps"] = int(len(expected.difference(pd.DatetimeIndex(ts.dropna().unique()))))
    reports.append(row)
pd.DataFrame(reports).to_csv(out / "legacy_file_audit.csv", index=False)

# Known EV physical inconsistency check.
evp = pd.read_csv(base / "ev_profile.csv")
mask = (pd.to_numeric(evp["ev_connected_count"], errors="coerce") == 0) & (pd.to_numeric(evp["ev_charging_power_mw"], errors="coerce") > 1e-12)
anom = evp.loc[mask].copy()
anom.to_csv(out / "legacy_ev_connected_zero_positive_power.csv", index=False)

evs = pd.read_csv(base / "ev_sessions.csv")
legacy_energy = pd.DataFrame([{
    "interval_energy_kwh_total": float(pd.to_numeric(evp["ev_energy_kwh_interval"], errors="coerce").sum()),
    "session_kwh_delivered_total": float(pd.to_numeric(evs["kwh_delivered"], errors="coerce").sum()),
    "difference_kwh": float(pd.to_numeric(evs["kwh_delivered"], errors="coerce").sum() - pd.to_numeric(evp["ev_energy_kwh_interval"], errors="coerce").sum()),
    "connected_zero_positive_power_rows": int(mask.sum()),
}])
legacy_energy.to_csv(out / "legacy_ev_energy_audit.csv", index=False)

# Detect whether 15-min weather was constructed by exact linear interpolation of hourly values.
w = pd.read_csv(base / "weather.csv")
w["timestamp"] = pd.to_datetime(w["timestamp"], utc=True)
w = w.set_index("timestamp")
interp_rows = []
for col in ["ambient_temp_c", "wind_speed_ms", "wind_direction_deg", "solar_irradiance_wm2"]:
    if col not in w:
        continue
    errs=[]
    for t in w.index:
        if t.minute in (15,30,45):
            h=t.floor("h"); nxt=h+pd.Timedelta(hours=1)
            if h in w.index and nxt in w.index:
                frac=t.minute/60.0
                errs.append(abs(float(w.loc[t,col]) - ((1-frac)*float(w.loc[h,col])+frac*float(w.loc[nxt,col]))))
    interp_rows.append({"variable":col,"max_abs_error_from_exact_hourly_linear_interpolation":max(errs) if errs else np.nan,"n_checked":len(errs)})
pd.DataFrame(interp_rows).to_csv(out / "legacy_weather_interpolation_audit.csv", index=False)

print("Legacy audit complete.")
print(f"Physical EV inconsistency rows: {int(mask.sum())}")
print(legacy_energy.to_string(index=False))
