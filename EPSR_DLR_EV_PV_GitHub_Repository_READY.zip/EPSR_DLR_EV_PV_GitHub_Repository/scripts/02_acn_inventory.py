import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from epsr_pipeline.common import ROOT, load_config, ensure_directories
from epsr_pipeline.acn import inventory_monthly, recommend_12_month_windows

ensure_directories()
cfg = load_config()
a = cfg["acn"]
s = cfg["study"]
inv = inventory_monthly(
    site=a["site_id"],
    start_year=int(s["candidate_start_year"]),
    end_year=int(s["candidate_end_year"]),
    min_energy_kwh=float(a.get("min_energy_kwh", 0.0)),
)
inv.to_csv(ROOT / "05_quality_control/acn_monthly_coverage.csv", index=False)
rec = recommend_12_month_windows(inv)
rec.to_csv(ROOT / "05_quality_control/acn_recommended_12_month_windows.csv", index=False)
print(inv.to_string(index=False))
print("\nTop candidate 12-month windows:")
print(rec.head(10).to_string(index=False) if not rec.empty else "No complete candidate window found.")
print("\nReview the results, then set study.start_utc and study.end_utc in config.yaml.")
