import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from epsr_pipeline.common import ROOT, load_config, ensure_directories, write_json
from epsr_pipeline.dlr import build_dlr, static_rating, seasonal_ratings

ensure_directories(); cfg=load_config()
w=pd.read_csv(ROOT/"03_processed/weather_solar_15min.csv",parse_dates=["timestamp_utc"])
dlr=build_dlr(w,cfg)
dlr.to_csv(ROOT/"08_dlr/dlr_15min.csv",index=False)
str_info=static_rating(cfg); write_json(str_info,ROOT/"08_dlr/static_rating.json")
seasonal=seasonal_ratings(w,cfg); seasonal.to_csv(ROOT/"08_dlr/seasonal_ratings.csv",index=False)

orientation_cols = [c for c in dlr.columns if c.startswith("dlr_ampacity_a_axis_")]
primary = pd.to_numeric(dlr["dlr_ampacity_a"], errors="coerce") if "dlr_ampacity_a" in dlr.columns else pd.Series(dtype=float)
validation_rows = []
validation_rows.append({
    "check": "orientation_columns_present",
    "status": "pass" if len(orientation_cols) >= 3 else "fail",
    "value": len(orientation_cols),
    "details": ",".join(orientation_cols),
})
if not primary.empty:
    validation_rows.append({
        "check": "primary_ampacity_positive_fraction",
        "status": "pass" if float((primary > 0).mean()) == 1.0 else "fail",
        "value": float((primary > 0).mean()),
        "details": "Primary orientation ampacity should stay positive throughout the study window.",
    })
    other = pd.concat([pd.to_numeric(dlr[c], errors="coerce") for c in orientation_cols], axis=1) if orientation_cols else pd.DataFrame()
    if not other.empty:
        validation_rows.append({
            "check": "sensitivity_surface_finite_fraction",
            "status": "pass" if float(np.isfinite(other.to_numpy(dtype=float)).mean()) == 1.0 else "fail",
            "value": float(np.isfinite(other.to_numpy(dtype=float)).mean()),
            "details": "All exported orientation sensitivities should be finite.",
        })
        spread = (other.max(axis=1) - other.min(axis=1)) / primary.replace(0, np.nan)
        validation_rows.append({
            "check": "median_orientation_spread_fraction",
            "status": "pass" if float(spread.median(skipna=True)) >= 0 else "pass",
            "value": float(spread.median(skipna=True)),
            "details": "Median relative spread across 0/45/90-degree sensitivities.",
        })
        validation_rows.append({
            "check": "primary_orientation_within_sensitivity_envelope",
            "status": "pass" if ((primary <= other.max(axis=1) + 1e-9) & (primary >= other.min(axis=1) - 1e-9)).mean() >= 0.99 else "review",
            "value": float(((primary <= other.max(axis=1) + 1e-9) & (primary >= other.min(axis=1) - 1e-9)).mean()),
            "details": "Primary orientation should lie within the exported sensitivity envelope.",
        })
validation_rows.append({
    "check": "static_rating_independent_from_min_dlr",
    "status": "pass" if (not primary.empty and float(str_info["str_ampacity_a"]) > float(primary.min())) else "review",
    "value": float(str_info["str_ampacity_a"]) if not primary.empty else np.nan,
    "details": f"Minimum primary DLR ampacity = {float(primary.min()) if not primary.empty else np.nan}",
})
validation_rows.append({
    "check": "seasonal_ratings_complete",
    "status": "pass" if set(seasonal["season"].astype(str)) >= {"winter", "spring", "summer", "autumn"} else "review",
    "value": int(len(seasonal)),
    "details": "Expected four seasonal rating rows.",
})
pd.DataFrame(validation_rows).to_csv(ROOT/"05_quality_control/dlr_validation_report.csv", index=False)
print("Static rating:",str_info)
print("\nSeasonal ratings:\n",seasonal.to_string(index=False))
print("\nDLR summary:\n",dlr[["dlr_ampacity_a","dlr_mva"]].describe().to_string())
