
from __future__ import annotations

"""
PHASE 5F — VOLTAGE-CONTROL SENSITIVITY
======================================

Scientific purpose
------------------
Phase 5A–5E showed that the frozen DLR strategy consistently reduced thermal
loading, while the exact IEEE-33 validation exposed substantial 0.95–1.05 pu
voltage violations under fixed distribution voltage control.

Phase 5F asks a narrower follow-up question:

    Can conventional distribution-voltage controls mitigate the residual
    IEEE-33 voltage violations without changing the frozen Phase-4 active-power
    schedules or removing the thermal advantage of DLR?

This is a SENSITIVITY / VALIDATION EXTENSION. It does NOT retune Phase 4.

Frozen quantities
-----------------
The following remain unchanged:
- Phase-4 feeder populations,
- frozen windows and seeds,
- 4-hour validation horizon used by Phase 5A,
- hourly EV/PV active-power schedules recovered in Phase 5A,
- STR/DLR line-rating policies,
- active PCC power,
- selected IEEE-118 corridors.

Control sensitivities
---------------------
1. BASELINE
   - source tap = 1.0 pu
   - inverter reactive support = 0

2. OLTC
   - common discrete source-voltage setpoint selected from 0.95–1.05 pu
   - 0.00625 pu step
   - no inverter reactive support

3. VOLT_VAR
   - source tap = 1.0 pu
   - class-specific bounded PV-inverter reactive support
   - active power is NOT curtailed
   - reactive capability is available only when PV is producing

4. OLTC_VOLT_VAR
   - common OLTC tap plus bounded PV-inverter reactive support

PV-inverter sensitivity assumption
----------------------------------
For each feeder class:
    S_inv,rated = 1.10 * P_PV,rated

At an operating point with active PV power P:
    |Q|max = sqrt(S_inv,rated^2 - P^2)

This is an explicit sensitivity assumption, not a claim about the actual
hardware at Caltech or on IEEE-33.

Voltage-control objective
-------------------------
The controller is NOT optimized for economic cost. It uses a deterministic
lexicographic voltage-security objective:
1. minimize the feeder-count-weighted number of IEEE-33 bus voltage violations,
2. minimize maximum voltage-limit exceedance,
3. minimize mean absolute voltage deviation from 1 pu,
4. minimize control effort.

The 0.95–1.05 pu limits are the Phase-5 validation limits.

Transmission recheck
--------------------
For every control case, IEEE-118 AC power flow is rerun using:
- identical active PCC power,
- adjusted aggregate PCC reactive demand from Volt-VAR support,
- identical timestamp-specific STR/DLR ratings.

Therefore Phase 5F can check whether voltage support sacrifices the previously
observed DLR thermal-loading advantage.

Interpretation boundary
-----------------------
A process PASS means the sensitivity calculations completed consistently.
It does not force all states to become voltage-secure.
"""

from pathlib import Path
import importlib.util
import json
import math
import os
import time

import numpy as np
import pandas as pd


# =============================================================================
# 1. Shared Phase-5 utilities
# =============================================================================

def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing shared Phase-5 utility: {path}"
        )
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not import 29_phase5_common.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")

SOURCE = OUTDIR / "phase5a_acpf_results.csv"

RESULT_OUT = OUTDIR / "phase5f_voltage_control_results.csv"
SUMMARY_OUT = OUTDIR / "phase5f_voltage_control_summary.csv"
CONTROL_EFFECT_OUT = OUTDIR / "phase5f_control_effects_vs_baseline.csv"
PAIRED_OUT = OUTDIR / "phase5f_paired_str_dlr_effects.csv"
GATE_OUT = OUTDIR / "phase5f_gate_summary.csv"
META_OUT = OUTDIR / "phase5f_metadata.json"


# =============================================================================
# 2. Frozen sensitivity settings
# =============================================================================

VLOW = 0.95
VHIGH = 1.05

OLTC_MIN = 0.95
OLTC_MAX = 1.05
OLTC_STEP = 0.00625

PV_INVERTER_S_OVER_P_RATED = 1.10

# q-search resolution for each feeder-class representative.
Q_GRID_POINTS = int(
    os.environ.get(
        "PHASE5F_Q_GRID_POINTS",
        "25",
    )
)

FAST_MODE = (
    os.environ.get(
        "PHASE5F_FAST_MODE",
        "0",
    ).strip()
    == "1"
)

if FAST_MODE:
    Q_GRID_POINTS = min(Q_GRID_POINTS, 11)

CONTROL_CASES = [
    "BASELINE",
    "OLTC",
    "VOLT_VAR",
    "OLTC_VOLT_VAR",
]


# =============================================================================
# 3. Preconditions
# =============================================================================

if not SOURCE.exists():
    raise FileNotFoundError(
        f"Phase-5A result file is missing:\n{SOURCE}\n"
        "Run Phase 5A first."
    )

src = pd.read_csv(SOURCE)

required_cols = [
    "pair_id",
    "window_id",
    "seed",
    "stress_regime",
    "feeder_count",
    "mpc_horizon_h",
    "timestamp_utc",
    "sentinel_reason",
    "case",
    "rating_policy",
    "actual_system_load_factor",
    "pcc_mw",
    "pcc_q_mvar",
    "class_net_mw_json",
    "class_pv_available_mw_json",
    "corridor_ratings_mva_json",
]

missing_cols = [
    x for x in required_cols if x not in src.columns
]

if missing_cols:
    raise KeyError(
        "phase5a_acpf_results.csv is missing required columns:\n"
        + "\n".join(missing_cols)
    )


# =============================================================================
# 4. Frozen Phase-4C foundation
# =============================================================================

p4c = c.import_phase4c(ROOT)
p4 = p4c.p4
backend = c.load_power_backend()

classes = list(p4c.CLASSES)

corridor_rows = c.corridor_rows_from_phase4(p4)
selected_branch_ids = [
    int(x["branch_id"])
    for x in corridor_rows
]

# Base PV profile maximum used in Phase 4.
base_pv_peak_mw = float(
    p4.master15["pv_ac_kw"].max()
) / 1000.0

pv_rated_mw = {
    cls:
        base_pv_peak_mw
        * float(p4.pv_scale[cls])
    for cls in classes
}

s_inv_rated_mva = {
    cls:
        PV_INVERTER_S_OVER_P_RATED
        * pv_rated_mw[cls]
    for cls in classes
}

tap_candidates = np.round(
    np.arange(
        OLTC_MIN,
        OLTC_MAX + OLTC_STEP / 2.0,
        OLTC_STEP,
    ),
    6,
)


# =============================================================================
# 5. Exact IEEE-33 BFS with source-tap and reactive-support controls
# =============================================================================

def bfs_detail(
    native_factor: float,
    net_p_mw: float,
    q_support_mvar: float = 0.0,
    tap_pu: float = 1.0,
):
    """
    Exact balanced backward/forward sweep using the frozen Phase-4 IEEE-33
    topology and load allocation.

    Positive q_support_mvar = reactive injection by PV inverter(s), which
    reduces net reactive demand.

    Active power is unchanged from the frozen Phase-5A state.
    """

    native_factor = float(native_factor)
    net_p_mw = float(net_p_mw)
    q_support_mvar = float(q_support_mvar)
    tap_pu = float(tap_pu)

    extra_kw = (
        net_p_mw * 1000.0
        -
        float(p4.P0.sum()) * native_factor
    )

    P = (
        p4.P0 * native_factor
        +
        p4.wbus * extra_kw
    )

    # Native reactive load remains frozen.
    # Reactive injection is allocated using the same feeder spatial weighting
    # used for active flexibility in Phase 4.
    Q = (
        p4.Q0 * native_factor
        -
        p4.wbus * q_support_mvar * 1000.0
    )

    source_v = (
        float(p4.vsl)
        * tap_pu
    )

    v = np.full(
        34,
        complex(source_v, 0.0),
    )

    converged = False
    iterations = 0

    for iteration in range(1, 101):

        iterations = iteration

        iload = np.zeros(
            34,
            dtype=complex,
        )

        for bus in range(2, 34):

            if abs(v[bus]) < 1e-9:
                raise RuntimeError(
                    f"IEEE-33 BFS reached near-zero voltage at bus {bus}."
                )

            s_phase = (
                complex(
                    P[bus],
                    Q[bus],
                )
                * 1000.0
                / 3.0
            )

            iload[bus] = np.conj(
                s_phase
                /
                v[bus]
            )

        ib = {}

        for u in reversed(
            p4.order[1:]
        ):

            ib[
                (
                    int(p4.parent[u]),
                    int(u),
                )
            ] = (
                iload[u]
                +
                sum(
                    ib[
                        (
                            int(u),
                            int(child),
                        )
                    ]
                    for child
                    in p4.children[u]
                )
            )

        vn = np.zeros(
            34,
            dtype=complex,
        )

        vn[1] = complex(
            source_v,
            0.0,
        )

        for u in p4.order[1:]:

            parent = int(
                p4.parent[u]
            )

            vn[u] = (
                vn[parent]
                -
                ib[
                    (
                        parent,
                        int(u),
                    )
                ]
                *
                p4.zline[
                    (
                        parent,
                        int(u),
                    )
                ]
            )

        if (
            np.max(
                np.abs(
                    vn[1:]
                    -
                    v[1:]
                )
            )
            <
            1e-7
        ):

            v = vn
            converged = True
            break

        v = vn

    pu = (
        np.abs(
            v[1:]
        )
        /
        float(p4.vsl)
    )

    violation_mask = (
        (pu < VLOW - 1e-8)
        |
        (pu > VHIGH + 1e-8)
    )

    below = np.maximum(
        0.0,
        VLOW - pu,
    )

    above = np.maximum(
        0.0,
        pu - VHIGH,
    )

    limit_exceedance = (
        below
        +
        above
    )

    return {
        "converged":
            bool(converged),

        "iterations":
            int(iterations),

        "voltages_pu":
            pu,

        "vmin_pu":
            float(
                np.min(pu)
            ),

        "vmax_pu":
            float(
                np.max(pu)
            ),

        "voltage_violation_bus_count":
            int(
                np.sum(
                    violation_mask
                )
            ),

        "max_voltage_limit_exceedance_pu":
            float(
                np.max(
                    limit_exceedance
                )
            ),

        "mean_abs_voltage_deviation_pu":
            float(
                np.mean(
                    np.abs(
                        pu - 1.0
                    )
                )
            ),
    }


# =============================================================================
# 6. Inverter reactive-power capability
# =============================================================================

def q_capability_mvar(
    cls: str,
    actual_pv_mw: float,
):
    """
    Daytime-only reactive support sensitivity.

    If actual PV output is zero, no reactive support is assumed. This avoids
    silently assuming night-time VAR capability.
    """

    actual_pv_mw = max(
        0.0,
        float(actual_pv_mw),
    )

    if (
        actual_pv_mw
        <=
        1e-8
    ):
        return 0.0

    s_rating = float(
        s_inv_rated_mva[cls]
    )

    if (
        actual_pv_mw
        >
        s_rating
    ):
        # Should not normally occur; clip for numerical safety.
        actual_pv_mw = s_rating

    return float(
        math.sqrt(
            max(
                0.0,
                s_rating ** 2
                -
                actual_pv_mw ** 2,
            )
        )
    )


# =============================================================================
# 7. Voltage objective helpers
# =============================================================================

def class_objective(
    bfs_result,
    q_support_mvar,
):
    """
    Lexicographic feeder objective.

    Lower tuple is better.
    """

    return (
        int(
            bfs_result[
                "voltage_violation_bus_count"
            ]
        ),

        float(
            bfs_result[
                "max_voltage_limit_exceedance_pu"
            ]
        ),

        float(
            bfs_result[
                "mean_abs_voltage_deviation_pu"
            ]
        ),

        abs(
            float(
                q_support_mvar
            )
        ),
    )


def best_q_for_class(
    native_factor: float,
    net_p_mw: float,
    actual_pv_mw: float,
    cls: str,
    tap_pu: float,
):
    """
    Select bounded Q support for one representative feeder class.
    """

    qcap = q_capability_mvar(
        cls,
        actual_pv_mw,
    )

    if qcap <= 1e-10:

        result = bfs_detail(
            native_factor=native_factor,
            net_p_mw=net_p_mw,
            q_support_mvar=0.0,
            tap_pu=tap_pu,
        )

        return {
            "q_support_mvar":
                0.0,

            "q_capability_mvar":
                0.0,

            "bfs":
                result,
        }

    q_grid = np.linspace(
        -qcap,
        qcap,
        Q_GRID_POINTS,
    )

    # Guarantee 0 is evaluated exactly.
    q_grid = np.unique(
        np.concatenate(
            [
                q_grid,
                np.array(
                    [0.0]
                ),
            ]
        )
    )

    best = None
    best_obj = None

    for q in q_grid:

        result = bfs_detail(
            native_factor=native_factor,
            net_p_mw=net_p_mw,
            q_support_mvar=float(q),
            tap_pu=float(tap_pu),
        )

        obj = class_objective(
            result,
            q,
        )

        if (
            best is None
            or
            obj < best_obj
        ):

            best = {
                "q_support_mvar":
                    float(q),

                "q_capability_mvar":
                    float(qcap),

                "bfs":
                    result,
            }

            best_obj = obj

    return best


# =============================================================================
# 8. Evaluate one operating state for a given control case
# =============================================================================

def evaluate_control_case(
    row,
    control_case: str,
):
    """
    Returns exact IEEE-33 results for all feeder classes and the selected
    control settings.
    """

    regime = str(
        row[
            "stress_regime"
        ]
    )

    counts = {
        cls:
            int(
                p4c.regime_rows[
                    regime
                ][
                    "counts"
                ][
                    cls
                ]
            )
        for cls
        in classes
    }



    # parse_int_float_json expects integer keys, while class JSON uses
    # alphabetic A-E keys, so parse these separately.
    class_net = {
        str(k):
            float(v)
        for k, v
        in json.loads(
            str(
                row[
                    "class_net_mw_json"
                ]
            )
        ).items()
    }

    class_pv = {
        str(k):
            float(v)
        for k, v
        in json.loads(
            str(
                row[
                    "class_pv_available_mw_json"
                ]
            )
        ).items()
    }

    native_factor = float(
        row[
            "actual_system_load_factor"
        ]
    )

    use_oltc = (
        control_case
        in {
            "OLTC",
            "OLTC_VOLT_VAR",
        }
    )

    use_volt_var = (
        control_case
        in {
            "VOLT_VAR",
            "OLTC_VOLT_VAR",
        }
    )

    candidate_taps = (
        tap_candidates
        if use_oltc
        else np.array(
            [1.0]
        )
    )

    best_state = None
    best_obj = None

    for tap in candidate_taps:

        class_records = {}

        weighted_violation_bus_feeders = 0
        weighted_voltage_deviation = 0.0

        max_limit_exceedance = 0.0

        total_q_support_mvar = 0.0
        total_abs_q_support_mvar = 0.0

        all_converged = True

        for cls in classes:

            net_mw = float(
                class_net[cls]
            )

            pv_mw = float(
                class_pv[cls]
            )

            if use_volt_var:

                q_choice = best_q_for_class(
                    native_factor=native_factor,
                    net_p_mw=net_mw,
                    actual_pv_mw=pv_mw,
                    cls=cls,
                    tap_pu=float(tap),
                )

            else:

                bfs = bfs_detail(
                    native_factor=native_factor,
                    net_p_mw=net_mw,
                    q_support_mvar=0.0,
                    tap_pu=float(tap),
                )

                q_choice = {
                    "q_support_mvar":
                        0.0,

                    "q_capability_mvar":
                        q_capability_mvar(
                            cls,
                            pv_mw,
                        ),

                    "bfs":
                        bfs,
                }

            bfs = q_choice[
                "bfs"
            ]

            class_records[
                cls
            ] = {

                "net_p_mw":
                    net_mw,

                "pv_available_mw":
                    pv_mw,

                "q_support_mvar":
                    float(
                        q_choice[
                            "q_support_mvar"
                        ]
                    ),

                "q_capability_mvar":
                    float(
                        q_choice[
                            "q_capability_mvar"
                        ]
                    ),

                "vmin_pu":
                    float(
                        bfs[
                            "vmin_pu"
                        ]
                    ),

                "vmax_pu":
                    float(
                        bfs[
                            "vmax_pu"
                        ]
                    ),

                "violation_bus_count":
                    int(
                        bfs[
                            "voltage_violation_bus_count"
                        ]
                    ),

                "max_limit_exceedance_pu":
                    float(
                        bfs[
                            "max_voltage_limit_exceedance_pu"
                        ]
                    ),

                "mean_abs_voltage_deviation_pu":
                    float(
                        bfs[
                            "mean_abs_voltage_deviation_pu"
                        ]
                    ),

                "converged":
                    bool(
                        bfs[
                            "converged"
                        ]
                    ),
            }

            nfeed = int(
                counts[
                    cls
                ]
            )

            weighted_violation_bus_feeders += (
                nfeed
                *
                int(
                    bfs[
                        "voltage_violation_bus_count"
                    ]
                )
            )

            weighted_voltage_deviation += (
                nfeed
                *
                float(
                    bfs[
                        "mean_abs_voltage_deviation_pu"
                    ]
                )
            )

            max_limit_exceedance = max(
                max_limit_exceedance,
                float(
                    bfs[
                        "max_voltage_limit_exceedance_pu"
                    ]
                ),
            )

            q_value = float(
                q_choice[
                    "q_support_mvar"
                ]
            )

            total_q_support_mvar += (
                nfeed
                *
                q_value
            )

            total_abs_q_support_mvar += (
                nfeed
                *
                abs(
                    q_value
                )
            )

            all_converged = (
                all_converged
                and
                bool(
                    bfs[
                        "converged"
                    ]
                )
            )

        total_feeders = sum(
            counts.values()
        )

        mean_voltage_deviation = (
            weighted_voltage_deviation
            /
            total_feeders
        )

        # System-level lexicographic objective.
        obj = (
            int(
                weighted_violation_bus_feeders
            ),

            float(
                max_limit_exceedance
            ),

            float(
                mean_voltage_deviation
            ),

            abs(
                float(
                    tap
                )
                -
                1.0
            ),

            float(
                total_abs_q_support_mvar
            ),
        )

        if (
            best_state is None
            or
            obj < best_obj
        ):

            vmins = [
                x[
                    "vmin_pu"
                ]
                for x
                in class_records.values()
            ]

            vmaxs = [
                x[
                    "vmax_pu"
                ]
                for x
                in class_records.values()
            ]

            violating_feeders = sum(
                counts[cls]
                for cls
                in classes
                if (
                    class_records[
                        cls
                    ][
                        "violation_bus_count"
                    ]
                    >
                    0
                )
            )

            best_state = {

                "control_case":
                    control_case,

                "selected_tap_pu":
                    float(
                        tap
                    ),

                "total_q_support_mvar":
                    float(
                        total_q_support_mvar
                    ),

                "total_abs_q_support_mvar":
                    float(
                        total_abs_q_support_mvar
                    ),

                "distribution_vmin_pu":
                    float(
                        min(
                            vmins
                        )
                    ),

                "distribution_vmax_pu":
                    float(
                        max(
                            vmaxs
                        )
                    ),

                "distribution_voltage_violation_feeders":
                    int(
                        violating_feeders
                    ),

                "weighted_bus_voltage_violations":
                    int(
                        weighted_violation_bus_feeders
                    ),

                "max_voltage_limit_exceedance_pu":
                    float(
                        max_limit_exceedance
                    ),

                "mean_abs_voltage_deviation_pu":
                    float(
                        mean_voltage_deviation
                    ),

                "all_ieee33_bfs_converged":
                    bool(
                        all_converged
                    ),

                "class_control_json":
                    c.json_dumps(
                        class_records
                    ),
            }

            best_obj = obj

    return best_state


# =============================================================================
# 9. Run Phase 5F
# =============================================================================

print(
    "EPSR ROOT:",
    ROOT,
)

print(
    "PHASE 5F — VOLTAGE-CONTROL SENSITIVITY"
)

print(
    "AC backend:",
    backend[
        "name"
    ],
)

print(
    "Phase-5A operating states:",
    len(
        src
    ),
)

print(
    "Control cases:",
    CONTROL_CASES,
)

print(
    "OLTC candidate taps:",
    len(
        tap_candidates
    ),
)

print(
    "PV inverter S/P rating sensitivity:",
    PV_INVERTER_S_OVER_P_RATED,
)

print(
    "Q-search grid points:",
    Q_GRID_POINTS,
)

records = []

t0 = time.perf_counter()

total_runs = (
    len(src)
    *
    len(
        CONTROL_CASES
    )
)

counter = 0

for _, row in src.iterrows():

    ratings = c.parse_int_float_json(
        row[
            "corridor_ratings_mva_json"
        ]
    )

    for control_case in CONTROL_CASES:

        counter += 1

        controlled = evaluate_control_case(
            row,
            control_case,
        )

        # Positive Q support reduces reactive import seen by transmission.
        controlled_pcc_q = (
            float(
                row[
                    "pcc_q_mvar"
                ]
            )
            -
            float(
                controlled[
                    "total_q_support_mvar"
                ]
            )
        )

        # Active power remains frozen.
        controlled_pcc_p = float(
            row[
                "pcc_mw"
            ]
        )

        mpc = c.build_case118_state(
            backend,
            pcc_mw=controlled_pcc_p,
            pcc_q_mvar=controlled_pcc_q,
            pcc_bus=78,
            ratings_by_branch=ratings,
            vmin=VLOW,
            vmax=VHIGH,
        )

        ac_result, ac_success, ac_error = c.run_pf(
            backend,
            mpc,
        )

        ac_eval = c.evaluate_ac_result(
            ac_result,
            corridor_branch_ids=selected_branch_ids,
            vmin=VLOW,
            vmax=VHIGH,
        )

        rec = {

            "pair_id":
                row[
                    "pair_id"
                ],

            "window_id":
                row[
                    "window_id"
                ],

            "seed":
                int(
                    row[
                        "seed"
                    ]
                ),

            "stress_regime":
                row[
                    "stress_regime"
                ],

            "feeder_count":
                int(
                    row[
                        "feeder_count"
                    ]
                ),

            "mpc_horizon_h":
                int(
                    row[
                        "mpc_horizon_h"
                    ]
                ),

            "timestamp_utc":
                row[
                    "timestamp_utc"
                ],

            "sentinel_reason":
                row[
                    "sentinel_reason"
                ],

            "case":
                row[
                    "case"
                ],

            "rating_policy":
                row[
                    "rating_policy"
                ],

            "control_case":
                control_case,

            "frozen_pcc_mw":
                controlled_pcc_p,

            "baseline_pcc_q_mvar":
                float(
                    row[
                        "pcc_q_mvar"
                    ]
                ),

            "controlled_pcc_q_mvar":
                float(
                    controlled_pcc_q
                ),

            "selected_tap_pu":
                controlled[
                    "selected_tap_pu"
                ],

            "total_q_support_mvar":
                controlled[
                    "total_q_support_mvar"
                ],

            "total_abs_q_support_mvar":
                controlled[
                    "total_abs_q_support_mvar"
                ],

            "distribution_vmin_pu":
                controlled[
                    "distribution_vmin_pu"
                ],

            "distribution_vmax_pu":
                controlled[
                    "distribution_vmax_pu"
                ],

            "distribution_voltage_violation_feeders":
                controlled[
                    "distribution_voltage_violation_feeders"
                ],

            "weighted_bus_voltage_violations":
                controlled[
                    "weighted_bus_voltage_violations"
                ],

            "max_voltage_limit_exceedance_pu":
                controlled[
                    "max_voltage_limit_exceedance_pu"
                ],

            "mean_abs_voltage_deviation_pu":
                controlled[
                    "mean_abs_voltage_deviation_pu"
                ],

            "all_ieee33_bfs_converged":
                controlled[
                    "all_ieee33_bfs_converged"
                ],

            "class_control_json":
                controlled[
                    "class_control_json"
                ],

            "ieee118_acpf_success":
                bool(
                    ac_success
                ),

            "ieee118_acpf_error":
                ac_error,

            "ieee118_bus_vmin_pu":
                ac_eval[
                    "bus_vmin_pu"
                ],

            "ieee118_bus_vmax_pu":
                ac_eval[
                    "bus_vmax_pu"
                ],

            "ieee118_bus_voltage_violation_count":
                ac_eval[
                    "bus_voltage_violation_count"
                ],

            "ieee118_selected_corridor_max_loading_pu":
                ac_eval[
                    "selected_corridor_max_loading_pu"
                ],

            "ieee118_selected_corridor_thermal_violation_count":
                ac_eval[
                    "selected_corridor_thermal_violation_count"
                ],

            "ieee118_selected_corridor_loading_json":
                ac_eval[
                    "selected_corridor_loading_json"
                ],
        }

        records.append(
            rec
        )

        if (
            counter % 10 == 0
            or
            counter == total_runs
        ):

            print(
                f"Phase-5F evaluated "
                f"{counter}/{total_runs} "
                "state-control combinations"
            )


results = pd.DataFrame(
    records
)

results.to_csv(
    RESULT_OUT,
    index=False,
)


# =============================================================================
# 10. Summary by stress regime, rating case, and control case
# =============================================================================

summary_work = (
    results.copy()
)

summary_work[
    "distribution_voltage_clean"
] = (
    pd.to_numeric(
        summary_work[
            "distribution_voltage_violation_feeders"
        ],
        errors="coerce",
    )
    .eq(
        0
    )
)

summary_work[
    "ieee118_voltage_clean"
] = (
    pd.to_numeric(
        summary_work[
            "ieee118_bus_voltage_violation_count"
        ],
        errors="coerce",
    )
    .eq(
        0
    )
)

summary_work[
    "ieee118_thermal_clean"
] = (
    pd.to_numeric(
        summary_work[
            "ieee118_selected_corridor_thermal_violation_count"
        ],
        errors="coerce",
    )
    .eq(
        0
    )
)

summary_work[
    "ieee118_acpf_ok"
] = c.boolify(
    summary_work[
        "ieee118_acpf_success"
    ]
)

summary = (
    summary_work

    .groupby(
        [
            "stress_regime",
            "case",
            "control_case",
        ],
        dropna=False,
    )

    .agg(

        evaluations=(
            "timestamp_utc",
            "size",
        ),

        ieee33_voltage_clean_evaluations=(
            "distribution_voltage_clean",
            "sum",
        ),

        mean_ieee33_violating_feeders=(
            "distribution_voltage_violation_feeders",
            "mean",
        ),

        mean_weighted_bus_voltage_violations=(
            "weighted_bus_voltage_violations",
            "mean",
        ),

        worst_ieee33_vmin_pu=(
            "distribution_vmin_pu",
            "min",
        ),

        worst_ieee33_vmax_pu=(
            "distribution_vmax_pu",
            "max",
        ),

        mean_selected_tap_pu=(
            "selected_tap_pu",
            "mean",
        ),

        mean_abs_q_support_mvar=(
            "total_abs_q_support_mvar",
            "mean",
        ),

        ieee118_acpf_converged=(
            "ieee118_acpf_ok",
            "sum",
        ),

        ieee118_voltage_clean_evaluations=(
            "ieee118_voltage_clean",
            "sum",
        ),

        ieee118_thermal_clean_evaluations=(
            "ieee118_thermal_clean",
            "sum",
        ),

        mean_ieee118_max_corridor_loading_pu=(
            "ieee118_selected_corridor_max_loading_pu",
            "mean",
        ),

        worst_ieee118_vmin_pu=(
            "ieee118_bus_vmin_pu",
            "min",
        ),

        worst_ieee118_vmax_pu=(
            "ieee118_bus_vmax_pu",
            "max",
        ),
    )

    .reset_index()
)

summary[
    "ieee33_voltage_clean_fraction"
] = (
    summary[
        "ieee33_voltage_clean_evaluations"
    ]
    /
    summary[
        "evaluations"
    ]
)

summary[
    "ieee118_voltage_clean_fraction"
] = (
    summary[
        "ieee118_voltage_clean_evaluations"
    ]
    /
    summary[
        "evaluations"
    ]
)

summary[
    "ieee118_thermal_clean_fraction"
] = (
    summary[
        "ieee118_thermal_clean_evaluations"
    ]
    /
    summary[
        "evaluations"
    ]
)

summary.to_csv(
    SUMMARY_OUT,
    index=False,
)


# =============================================================================
# 11. Control effect relative to BASELINE
# =============================================================================

compare_metrics = [
    "distribution_voltage_violation_feeders",
    "weighted_bus_voltage_violations",
    "distribution_vmin_pu",
    "distribution_vmax_pu",
    "ieee118_bus_voltage_violation_count",
    "ieee118_selected_corridor_max_loading_pu",
    "ieee118_selected_corridor_thermal_violation_count",
]

key_cols = [
    "pair_id",
    "timestamp_utc",
    "case",
]

baseline = (
    results[
        results[
            "control_case"
        ]
        ==
        "BASELINE"
    ]
    [
        key_cols
        +
        compare_metrics
    ]
    .copy()
)

baseline = baseline.rename(
    columns={
        metric:
            f"baseline_{metric}"
        for metric
        in compare_metrics
    }
)

control_effect = (
    results[
        results[
            "control_case"
        ]
        !=
        "BASELINE"
    ]
    .merge(
        baseline,
        on=key_cols,
        how="left",
        validate="many_to_one",
    )
)

for metric in compare_metrics:

    control_effect[
        f"delta_{metric}"
    ] = (
        pd.to_numeric(
            control_effect[
                metric
            ],
            errors="coerce",
        )
        -
        pd.to_numeric(
            control_effect[
                f"baseline_{metric}"
            ],
            errors="coerce",
        )
    )

control_effect.to_csv(
    CONTROL_EFFECT_OUT,
    index=False,
)


# =============================================================================
# 12. Paired STR / DLR effects under each voltage-control case
# =============================================================================

paired_rows = []

pair_keys = [
    "pair_id",
    "timestamp_utc",
    "control_case",
]

paired_metrics = [
    "distribution_voltage_violation_feeders",
    "weighted_bus_voltage_violations",
    "ieee118_bus_voltage_violation_count",
    "ieee118_selected_corridor_max_loading_pu",
    "ieee118_selected_corridor_thermal_violation_count",
]

for metric in paired_metrics:

    pivot = (
        results[
            pair_keys
            +
            [
                "case",
                metric,
            ]
        ]
        .pivot_table(
            index=pair_keys,
            columns="case",
            values=metric,
            aggfunc="first",
        )
    )

    if not {
        "STR-SMPC",
        "DLR-SMPC",
    }.issubset(
        set(
            pivot.columns
        )
    ):
        continue

    pivot = (
        pivot
        .dropna(
            subset=[
                "STR-SMPC",
                "DLR-SMPC",
            ]
        )
        .reset_index()
    )

    for _, r in pivot.iterrows():

        paired_rows.append(
            {
                "pair_id":
                    r[
                        "pair_id"
                    ],

                "timestamp_utc":
                    r[
                        "timestamp_utc"
                    ],

                "control_case":
                    r[
                        "control_case"
                    ],

                "metric":
                    metric,

                "STR":
                    float(
                        r[
                            "STR-SMPC"
                        ]
                    ),

                "DLR":
                    float(
                        r[
                            "DLR-SMPC"
                        ]
                    ),

                "DLR_minus_STR":
                    float(
                        r[
                            "DLR-SMPC"
                        ]
                        -
                        r[
                            "STR-SMPC"
                        ]
                    ),
            }
        )

paired = pd.DataFrame(
    paired_rows
)

paired.to_csv(
    PAIRED_OUT,
    index=False,
)


# =============================================================================
# 13. Process-integrity gates
# =============================================================================

expected_rows = (
    len(
        src
    )
    *
    len(
        CONTROL_CASES
    )
)

execution_exceptions = int(
    results[
        "ieee118_acpf_error"
    ]
    .notna()
    .sum()
)

bfs_nonconverged = int(
    (
        ~c.boolify(
            results[
                "all_ieee33_bfs_converged"
            ]
        )
    )
    .sum()
)

complete_control_matrix = bool(
    (
        results
        .groupby(
            [
                "pair_id",
                "timestamp_utc",
                "case",
            ]
        )[
            "control_case"
        ]
        .nunique()
        ==
        len(
            CONTROL_CASES
        )
    )
    .all()
)

active_power_frozen = bool(
    np.allclose(
        results[
            "frozen_pcc_mw"
        ]
        .to_numpy(
            dtype=float
        ),
        results[
            "pair_id"
        ]
        .map(
            src.set_index(
                "pair_id"
            )[
                "pcc_mw"
            ]
        )
        .to_numpy(
            dtype=float
        ),
        rtol=0.0,
        atol=1e-9,
    )
) if src["pair_id"].is_unique else True

# More robust active-power check using pair/timestamp/case.
frozen_ref = (
    src[
        [
            "pair_id",
            "timestamp_utc",
            "case",
            "pcc_mw",
        ]
    ]
    .rename(
        columns={
            "pcc_mw":
                "_reference_pcc_mw"
        }
    )
)

frozen_check = (
    results
    .merge(
        frozen_ref,
        on=[
            "pair_id",
            "timestamp_utc",
            "case",
        ],
        how="left",
        validate="many_to_one",
    )
)

active_power_frozen = bool(
    np.allclose(
        frozen_check[
            "frozen_pcc_mw"
        ]
        .to_numpy(
            dtype=float
        ),
        frozen_check[
            "_reference_pcc_mw"
        ]
        .to_numpy(
            dtype=float
        ),
        rtol=0.0,
        atol=1e-9,
    )
)

gates = pd.DataFrame(
    [
        {
            "gate":
                "expected_control_matrix_rows",

            "status":
                bool(
                    len(
                        results
                    )
                    ==
                    expected_rows
                ),

            "note":
                (
                    f"Expected {expected_rows} rows = "
                    f"{len(src)} Phase-5A states x "
                    f"{len(CONTROL_CASES)} control cases."
                ),
        },

        {
            "gate":
                "all_four_voltage_control_cases_present",

            "status":
                bool(
                    set(
                        results[
                            "control_case"
                        ]
                    )
                    ==
                    set(
                        CONTROL_CASES
                    )
                ),

            "note":
                ", ".join(
                    CONTROL_CASES
                ),
        },

        {
            "gate":
                "complete_control_case_matrix_per_frozen_state",

            "status":
                complete_control_matrix,

            "note":
                "Each STR/DLR sentinel state has all four control sensitivities.",
        },

        {
            "gate":
                "phase4_active_power_schedule_remains_frozen",

            "status":
                active_power_frozen,

            "note":
                "Phase 5F changes voltage-control variables only; PCC active power is unchanged.",
        },

        {
            "gate":
                "all_exact_ieee33_BFS_solutions_converged",

            "status":
                bool(
                    bfs_nonconverged
                    ==
                    0
                ),

            "note":
                f"Non-converged exact BFS evaluations: {bfs_nonconverged}",
        },

        {
            "gate":
                "no_unclassified_ieee118_backend_exceptions",

            "status":
                bool(
                    execution_exceptions
                    ==
                    0
                ),

            "note":
                (
                    "Returned ACPF non-convergence is a physical/numerical result; "
                    "Python/backend exceptions are implementation failures."
                ),
        },

        {
            "gate":
                "paired_STR_DLR_effect_table_created",

            "status":
                bool(
                    PAIRED_OUT.exists()
                    and
                    len(
                        paired
                    )
                    >
                    0
                ),

            "note":
                "Thermal and voltage comparisons remain paired by sentinel timestamp.",
        },
    ]
)

gates.to_csv(
    GATE_OUT,
    index=False,
)


# =============================================================================
# 14. Metadata
# =============================================================================

metadata = {

    "stage":
        "5F",

    "name":
        "Voltage-Control Sensitivity",

    "source":
        str(
            SOURCE
        ),

    "source_operating_states":
        int(
            len(
                src
            )
        ),

    "control_cases":
        CONTROL_CASES,

    "voltage_limits_pu":
        [
            VLOW,
            VHIGH,
        ],

    "oltc":
        {
            "min_pu":
                OLTC_MIN,

            "max_pu":
                OLTC_MAX,

            "step_pu":
                OLTC_STEP,

            "common_tap_across_representative_feeder_classes":
                True,
        },

    "volt_var":
        {
            "inverter_s_over_p_rated":
                PV_INVERTER_S_OVER_P_RATED,

            "night_var_support_assumed":
                False,

            "active_power_curtailment_allowed":
                False,

            "q_grid_points":
                Q_GRID_POINTS,

            "q_spatial_allocation":
                (
                    "same frozen IEEE-33 active-load spatial weights used "
                    "by the Phase-4 feeder model"
                ),
        },

    "frozen_variables":
        [
            "Phase-4 feeder counts",
            "Phase-4 windows",
            "Phase-4 seeds",
            "Phase-4 active EV/PV schedule",
            "PCC active power",
            "STR/DLR rating policy",
            "selected IEEE-118 corridor identities",
        ],

    "interpretation_boundary":
        (
            "Phase 5F is a voltage-control sensitivity, not a redesign or "
            "retuning of the Phase-4 controller. The inverter capability and "
            "OLTC ranges are explicit sensitivity assumptions."
        ),

    "outputs":
        {
            "results":
                str(
                    RESULT_OUT
                ),

            "summary":
                str(
                    SUMMARY_OUT
                ),

            "effects_vs_baseline":
                str(
                    CONTROL_EFFECT_OUT
                ),

            "paired_STR_DLR":
                str(
                    PAIRED_OUT
                ),

            "gate":
                str(
                    GATE_OUT
                ),
        },
}

META_OUT.write_text(
    json.dumps(
        metadata,
        indent=2,
    ),
    encoding="utf-8",
)


# =============================================================================
# 15. Console summary
# =============================================================================

print(
    "\n" + "=" * 100
)

print(
    "PHASE-5F VOLTAGE-CONTROL SUMMARY"
)

print(
    "=" * 100
)

print(
    summary.to_string(
        index=False
    )
)


print(
    "\n" + "=" * 100
)

print(
    "PHASE-5F PROCESS GATE"
)

print(
    "=" * 100
)

print(
    gates.to_string(
        index=False
    )
)


if not c.boolify(
    gates[
        "status"
    ]
).all():

    failed = gates.loc[
        ~c.boolify(
            gates[
                "status"
            ]
        )
    ]

    raise RuntimeError(
        "Phase 5F process-integrity gates failed:\n"
        +
        failed.to_string(
            index=False
        )
    )


print(
    "\nPASS: PHASE 5F VOLTAGE-CONTROL "
    "SENSITIVITY COMPUTATION COMPLETE."
)

print(
    "\nIMPORTANT: This PASS confirms the "
    "sensitivity workflow completed correctly. "
    "It does NOT force the voltage-control cases "
    "to eliminate every voltage violation."
)

print(
    "\nSaved:"
)

for path in [
    RESULT_OUT,
    SUMMARY_OUT,
    CONTROL_EFFECT_OUT,
    PAIRED_OUT,
    GATE_OUT,
    META_OUT,
]:
    print(
        path
    )

print(
    "\nruntime_s:",
    time.perf_counter()
    -
    t0,
)
