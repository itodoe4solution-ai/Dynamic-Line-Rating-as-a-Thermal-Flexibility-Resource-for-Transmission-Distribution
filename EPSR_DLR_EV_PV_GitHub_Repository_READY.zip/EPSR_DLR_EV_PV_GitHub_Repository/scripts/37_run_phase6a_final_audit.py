
from __future__ import annotations

"""PHASE 6A — FINAL DATA / EVIDENCE AUDIT AND FREEZE MANIFEST."""

from pathlib import Path
import importlib.util
import json
import os
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "36_phase6_common.py"
    spec = importlib.util.spec_from_file_location("phase6_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
RESULT_DIR = ROOT / "09_simulation_inputs" / "results"
OUTDIR = c.ensure_dir(RESULT_DIR / "phase6")
AUDIT_OUT = OUTDIR / "phase6a_data_audit.csv"
GATE_OUT = OUTDIR / "phase6a_gate_summary.csv"
META_OUT = OUTDIR / "phase6a_manifest.json"

required = [
    RESULT_DIR / "phase4c_receding_horizon_results.csv",
    RESULT_DIR / "phase4c_pair_feasibility.csv",
    RESULT_DIR / "phase4c_strict_feasible_paired_effects.csv",
    RESULT_DIR / "phase4d_ablation_results.csv",
    RESULT_DIR / "phase4e_primary_statistics.csv",
    RESULT_DIR / "phase4e_feasibility_statistics.csv",
    RESULT_DIR / "phase4e_ablation_statistics.csv",
    RESULT_DIR / "phase4e_publication_summary.csv",
    RESULT_DIR / "phase4e_gate_summary.csv",
    RESULT_DIR / "phase5a_acpf_results.csv",
    RESULT_DIR / "phase5b_acopf_results.csv",
    RESULT_DIR / "phase5c_n1_results.csv",
    RESULT_DIR / "phase5d_ieee39_results.csv",
    RESULT_DIR / "phase5e_publication_summary.csv",
    RESULT_DIR / "phase5e_paired_validation_effects.csv",
    RESULT_DIR / "phase5e_gate_summary.csv",
    RESULT_DIR / "phase5f_voltage_control_results.csv",
    RESULT_DIR / "phase5f_voltage_control_summary.csv",
    RESULT_DIR / "phase5f_paired_str_dlr_effects.csv",
    RESULT_DIR / "phase5f_gate_summary.csv",
]

optional = []
optional += c.find_optional_csvs(ROOT, "07_forecasts/*.csv")
optional += c.find_optional_csvs(ROOT, "09_simulation_inputs/phase2_td/*.csv")
optional += c.find_optional_csvs(ROOT, "06_scenarios/*.csv")

inventory = c.file_inventory(required + optional)
inventory["required"] = inventory["path"].isin([str(p) for p in required])
inventory.to_csv(AUDIT_OUT, index=False)

missing_required = inventory.loc[
    inventory["required"] & ~inventory["exists"], "path"
].tolist()

# Read stage gates and require process completeness.
stage_gate_files = [
    RESULT_DIR / "phase4e_gate_summary.csv",
    RESULT_DIR / "phase5e_gate_summary.csv",
    RESULT_DIR / "phase5f_gate_summary.csv",
]
gate_checks = []
for p in stage_gate_files:
    df = pd.read_csv(p)
    if "status" not in df.columns:
        raise KeyError(f"{p.name} has no status column.")
    all_pass = bool(c.boolify(df["status"]).all())
    gate_checks.append((p.name, all_pass, int(len(df))))

gates = pd.DataFrame(
    [
        {
            "gate": "all_required_publication_inputs_exist",
            "status": len(missing_required) == 0,
            "note": "Missing: " + "; ".join(missing_required) if missing_required else "All required inputs found.",
        },
        {
            "gate": "phase4e_process_gate_passed",
            "status": gate_checks[0][1],
            "note": f"{gate_checks[0][2]} Phase-4E gate rows checked.",
        },
        {
            "gate": "phase5e_process_gate_passed",
            "status": gate_checks[1][1],
            "note": f"{gate_checks[1][2]} Phase-5E gate rows checked.",
        },
        {
            "gate": "phase5f_process_gate_passed",
            "status": gate_checks[2][1],
            "note": f"{gate_checks[2][2]} Phase-5F gate rows checked.",
        },
        {
            "gate": "file_hash_manifest_created",
            "status": True,
            "note": "SHA-256 hashes recorded to support reproducibility and freeze tracking.",
        },
    ]
)
gates.to_csv(GATE_OUT, index=False)

manifest = {
    "stage": "6A",
    "purpose": "Final immutable evidence inventory before publication synthesis.",
    "project_root": str(ROOT),
    "required_file_count": len(required),
    "optional_file_count": len(optional),
    "missing_required": missing_required,
    "files": inventory.to_dict(orient="records"),
    "scientific_freeze": (
        "Phase 6 audits and synthesizes existing evidence only. "
        "Do not retune Phase 4/5 based on publication outputs."
    ),
}
c.write_json(META_OUT, manifest)

print("\nPHASE-6A DATA AUDIT")
print(inventory[["required", "exists", "name", "size_bytes"]].to_string(index=False))
print("\nPHASE-6A GATE")
print(gates.to_string(index=False))

if not c.boolify(gates["status"]).all():
    raise RuntimeError(
        "Phase 6A audit failed:\n"
        + gates.loc[~c.boolify(gates["status"])].to_string(index=False)
    )

print("\nPASS: PHASE 6A FINAL DATA AUDIT COMPLETE.")
