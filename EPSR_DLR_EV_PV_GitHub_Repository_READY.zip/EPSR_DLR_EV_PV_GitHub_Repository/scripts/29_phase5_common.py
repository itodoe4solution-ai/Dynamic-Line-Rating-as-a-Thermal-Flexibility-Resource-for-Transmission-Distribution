
from __future__ import annotations

"""
Phase 5 common utilities.

This module is intentionally shared by Phase 5A–5E so that:
- repository discovery is consistent,
- Phase-4C replay semantics are reused rather than reimplemented differently,
- PYPOWER / pandapower.pypower backend loading is centralized,
- IEEE-118 / IEEE-39 case construction is consistent,
- selected DLR corridor ratings are handled identically across stages.

Important scientific boundary
-----------------------------
Phase 5 validates the frozen Phase-4 operating decisions. It must not retune
Phase-4 feeder counts, horizons, windows, objectives, uncertainty models, or
STR/DLR policies in response to Phase-5 outcomes.
"""

from pathlib import Path
import copy
import importlib
import importlib.util
import json
import math
import os
from typing import Any

import numpy as np
import pandas as pd


# MATPOWER / PYPOWER column indices
BUS_I = 0
BUS_TYPE = 1
PD = 2
QD = 3
VM = 7
VA = 8
VMAX = 11
VMIN = 12

GEN_BUS = 0
GEN_STATUS = 7

F_BUS = 0
T_BUS = 1
BR_R = 2
BR_X = 3
BR_B = 4
RATE_A = 5
TAP = 8
SHIFT = 9
BR_STATUS = 10
PF = 13
QF = 14
PT = 15
QT = 16


def resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend(
        [
            Path.cwd(),
            Path(__file__).resolve().parent.parent,
            Path(__file__).resolve().parent,
        ]
    )
    for p in candidates:
        p = p.resolve()
        if (
            (p / "06_scenarios" / "selected_periods.csv").exists()
            and (p / "09_simulation_inputs" / "results").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate the EPSR repository root. "
        "Run from the repository root or set EPSR_ROOT."
    )


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def boolify(s: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)
    if pd.api.types.is_numeric_dtype(s):
        return s.fillna(0).astype(float).ne(0)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .map(
            {
                "true": True,
                "false": False,
                "1": True,
                "0": False,
                "yes": True,
                "no": False,
                "pass": True,
                "fail": False,
            }
        )
        .fillna(False)
        .astype(bool)
    )


def json_dumps(obj: Any) -> str:
    def conv(x):
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            return float(x)
        if isinstance(x, (np.bool_,)):
            return bool(x)
        if isinstance(x, pd.Timestamp):
            return str(x)
        raise TypeError(type(x).__name__)

    return json.dumps(obj, default=conv, sort_keys=True)


def import_phase4c(ROOT: Path):
    path = ROOT / "scripts" / "26_run_phase4c_receding.py"
    if not path.exists():
        raise FileNotFoundError(
            f"Phase-4C engine not found: {path}\n"
            "Phase 5 requires the frozen true receding-horizon engine."
        )
    spec = importlib.util.spec_from_file_location("phase4c_frozen_engine", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not import frozen Phase-4C engine.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_power_backend():
    """
    Returns a dict containing case118, case39, runpf, runopf, ppoption.

    Search order:
    1. pypower
    2. pandapower.pypower

    We do not auto-install packages from a research script.
    """
    errors = []

    try:
        from pypower.api import case118, case39, runpf, runopf, ppoption
        return {
            "name": "pypower",
            "case118": case118,
            "case39": case39,
            "runpf": runpf,
            "runopf": runopf,
            "ppoption": ppoption,
        }
    except Exception as exc:
        errors.append(f"pypower: {type(exc).__name__}: {exc}")

    try:
        from pandapower.pypower.api import runpf, runopf, ppoption
        try:
            from pandapower.pypower.case118 import case118
            from pandapower.pypower.case39 import case39
        except Exception:
            # Some pandapower installations expose PYPOWER cases elsewhere.
            from pandapower.pypower.api import case118, case39
        return {
            "name": "pandapower.pypower",
            "case118": case118,
            "case39": case39,
            "runpf": runpf,
            "runopf": runopf,
            "ppoption": ppoption,
        }
    except Exception as exc:
        errors.append(f"pandapower.pypower: {type(exc).__name__}: {exc}")

    raise ImportError(
        "Phase 5 requires an AC power-flow backend.\n"
        "Install ONE of the following in the SAME Python environment as Jupyter:\n"
        "  python -m pip install PYPOWER\n"
        "or\n"
        "  python -m pip install pandapower\n\n"
        "Backend import diagnostics:\n- " + "\n- ".join(errors)
    )


def _copy_case(case: dict) -> dict:
    out = {}
    for k, v in case.items():
        if isinstance(v, np.ndarray):
            out[k] = v.copy()
        else:
            out[k] = copy.deepcopy(v)
    return out


def _bus_row(mpc: dict, bus_number: int) -> int:
    idx = np.where(mpc["bus"][:, BUS_I].astype(int) == int(bus_number))[0]
    if len(idx) != 1:
        raise KeyError(f"Bus {bus_number} not uniquely found.")
    return int(idx[0])


def _set_voltage_limits(mpc: dict, vmin: float = 0.95, vmax: float = 1.05):
    mpc["bus"][:, VMIN] = float(vmin)
    mpc["bus"][:, VMAX] = float(vmax)


def corridor_rows_from_phase4(p4) -> list[dict]:
    """Return frozen corridor metadata keyed by the Phase-4 corridor IDs.

    The original Phase-4 optimization keeps only cid/base/PTDF in p4.corridors,
    while the full branch metadata remains in p4.selected. Use the latter when
    available so Phase 5 preserves the exact frozen branch IDs.
    """
    if hasattr(p4, "selected"):
        s = p4.selected.copy()
        required = {"corridor_id", "branch_id", "from_bus", "to_bus"}
        if required.issubset(set(s.columns)):
            rows = []
            for _, r in s.iterrows():
                rows.append(
                    {
                        "corridor_id": str(r["corridor_id"]),
                        "branch_id": int(r["branch_id"]),
                        "from_bus": int(r["from_bus"]),
                        "to_bus": int(r["to_bus"]),
                    }
                )
            return rows

    raise RuntimeError(
        "Frozen Phase-4 selected-corridor metadata is unavailable. "
        "Expected p4.selected with corridor_id/branch_id/from_bus/to_bus."
    )


def apply_selected_corridor_ratings(
    mpc: dict,
    ratings_by_branch: dict[int, float],
):
    for branch_id, rating in ratings_by_branch.items():
        i = int(branch_id) - 1
        if i < 0 or i >= len(mpc["branch"]):
            raise IndexError(
                f"1-based branch_id={branch_id} is outside case branch table."
            )
        mpc["branch"][i, RATE_A] = float(rating)


def build_case118_state(
    backend: dict,
    *,
    pcc_mw: float,
    pcc_q_mvar: float,
    pcc_bus: int,
    ratings_by_branch: dict[int, float],
    vmin: float = 0.95,
    vmax: float = 1.05,
):
    mpc = _copy_case(backend["case118"]())
    _set_voltage_limits(mpc, vmin=vmin, vmax=vmax)
    bi = _bus_row(mpc, pcc_bus)
    mpc["bus"][bi, PD] += float(pcc_mw)
    mpc["bus"][bi, QD] += float(pcc_q_mvar)
    apply_selected_corridor_ratings(mpc, ratings_by_branch)
    return mpc


def run_pf(backend: dict, mpc: dict) -> tuple[dict | None, bool, str | None]:
    try:
        ppopt = backend["ppoption"](VERBOSE=0, OUT_ALL=0)
        result, success = backend["runpf"](_copy_case(mpc), ppopt)
        return result, bool(success), None
    except Exception as exc:
        return None, False, f"{type(exc).__name__}: {exc}"


def run_opf(backend: dict, mpc: dict) -> tuple[dict | None, bool, str | None]:
    try:
        ppopt = backend["ppoption"](VERBOSE=0, OUT_ALL=0)
        result = backend["runopf"](_copy_case(mpc), ppopt)
        success = bool(result.get("success", False))
        return result, success, None
    except Exception as exc:
        return None, False, f"{type(exc).__name__}: {exc}"


def evaluate_ac_result(
    result: dict | None,
    *,
    corridor_branch_ids: list[int],
    vmin: float = 0.95,
    vmax: float = 1.05,
    outaged_branch_id: int | None = None,
) -> dict:
    if result is None:
        return {
            "bus_vmin_pu": np.nan,
            "bus_vmax_pu": np.nan,
            "bus_voltage_violation_count": np.nan,
            "selected_corridor_max_loading_pu": np.nan,
            "selected_corridor_thermal_violation_count": np.nan,
            "selected_corridor_loading_json": "{}",
        }

    bus = result["bus"]
    branch = result["branch"]

    vm = np.asarray(bus[:, VM], dtype=float)
    vviol = int(np.sum((vm < vmin - 1e-7) | (vm > vmax + 1e-7)))

    loading = {}
    violations = 0
    max_load = 0.0

    for branch_id in corridor_branch_ids:
        if outaged_branch_id is not None and int(branch_id) == int(outaged_branch_id):
            continue

        i = int(branch_id) - 1
        if i < 0 or i >= len(branch):
            continue
        if int(round(branch[i, BR_STATUS])) == 0:
            continue

        rating = float(branch[i, RATE_A])
        if not np.isfinite(rating) or rating <= 1e-9:
            continue

        sf = math.hypot(float(branch[i, PF]), float(branch[i, QF]))
        st = math.hypot(float(branch[i, PT]), float(branch[i, QT]))
        ld = max(sf, st) / rating
        loading[int(branch_id)] = float(ld)
        max_load = max(max_load, float(ld))
        if ld > 1.000001:
            violations += 1

    return {
        "bus_vmin_pu": float(np.nanmin(vm)),
        "bus_vmax_pu": float(np.nanmax(vm)),
        "bus_voltage_violation_count": int(vviol),
        "selected_corridor_max_loading_pu": float(max_load),
        "selected_corridor_thermal_violation_count": int(violations),
        "selected_corridor_loading_json": json_dumps(loading),
    }


def exact_ieee33_voltage_from_phase4(p4, native_factor: float, net_p_mw: float):
    """
    Uses the exact balanced backward/forward sweep already frozen in Phase 4,
    but applies the Phase-5 publication limits 0.95–1.05 pu.
    """
    vmin, vmax = p4.bfs_v(float(native_factor), float(net_p_mw))
    return {
        "vmin_pu": float(vmin),
        "vmax_pu": float(vmax),
        "voltage_violation": bool(vmin < 0.95 - 1e-7 or vmax > 1.05 + 1e-7),
    }


def replay_case_with_trace(
    p4c,
    *,
    window_row,
    seed: int,
    case: str,
    regime: str,
    requested_horizon_h: int,
) -> pd.DataFrame:
    """
    Replays the frozen Phase-4C controller and records hour-level realized states.

    This function intentionally mirrors run_case_receding(). It does not change
    the optimization problem. It only records additional state needed by Phase 5.
    """
    p4 = p4c.p4
    classes = p4c.CLASSES
    counts = p4c.regime_rows[regime]["counts"]
    feeder_count = int(p4c.regime_rows[regime]["feeder_count"])

    start = pd.Timestamp(window_row.start_utc)
    end = pd.Timestamp(window_row.end_utc_exclusive)
    win = p4c.hourly[
        (p4c.hourly.timestamp_utc >= start)
        & (p4c.hourly.timestamp_utc < end)
    ].copy().reset_index(drop=True)

    if len(win) != 168:
        raise RuntimeError(
            f"{window_row.scenario}: expected 168 hourly rows, got {len(win)}"
        )

    queues = {c: {} for c in classes}
    prev_x = {c: 0.0 for c in classes}

    trace = []
    corridor_meta = {
        str(r["corridor_id"]): r
        for r in corridor_rows_from_phase4(p4)
    }

    for local_t, row in win.iterrows():
        ts = row.timestamp_utc

        for c in classes:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if ts > p4.ev_support_end_ts:
                arr = 0.0
            if arr > 0.0:
                p4.add_energy_arrival(queues[c], local_t, arr, c)

        sol = p4c._solve_receding_plan(
            win=win,
            local_t=local_t,
            seed=int(seed),
            case=case,
            regime=regime,
            requested_horizon_h=int(requested_horizon_h),
            queues=queues,
            prev_x=prev_x,
        )

        actual_factor = float(row.system_load_mw) / p4.annual_system_max
        native_actual = 3.715 * actual_factor

        pcc_mw = 0.0
        class_net = {}
        class_x = {}
        class_pv = {}
        class_cur = {}
        class_vmin = {}
        class_vmax = {}
        distribution_violation_feeders = 0

        for ci, c in enumerate(classes):
            actual_pv = max(
                0.0,
                float(row.pv_ac_kw) * p4.pv_scale[c] / 1000.0,
            )
            cur = min(float(sol["first_cur"][ci]), actual_pv)

            avail = p4.queue_energy(queues[c])
            x = min(float(sol["first_x"][ci]), p4.pmax_mw[c], avail)
            x = p4.serve_fifo(queues[c], x)

            # Preserve Phase-4C state transition exactly.
            p4.expire_due(queues[c], local_t)

            net = native_actual + x - (actual_pv - cur)

            class_net[c] = float(net)
            class_x[c] = float(x)
            class_pv[c] = float(actual_pv)
            class_cur[c] = float(cur)

            vv = exact_ieee33_voltage_from_phase4(
                p4,
                native_factor=actual_factor,
                net_p_mw=net,
            )
            class_vmin[c] = vv["vmin_pu"]
            class_vmax[c] = vv["vmax_pu"]
            if vv["voltage_violation"]:
                distribution_violation_feeders += int(counts[c])

            pcc_mw += int(counts[c]) * net
            prev_x[c] = x

        # Native feeder reactive demand scales with native load.
        # EV charging and PV are unity-PF in the frozen Phase-4 model.
        pcc_q_mvar = float(feeder_count * 2.300 * actual_factor)

        ratings = {}
        corridor_flow = {}
        corridor_loading = {}
        max_corridor_loading = 0.0
        corridor_thermal_violations = 0

        for cor in p4.corridors:
            cid = str(cor["cid"])
            rr = p4.rating_lookup[cid]
            rating_col = "str_mva" if case == "STR-SMPC" else "dlr_mva"
            rating = float(rr.loc[ts, rating_col])
            flow = float(cor["base"] - cor["ptdf"] * pcc_mw)
            loading = abs(flow) / rating

            if cid not in corridor_meta:
                raise KeyError(f"Missing frozen branch metadata for corridor {cid}.")
            bid = int(corridor_meta[cid]["branch_id"])
            ratings[bid] = float(rating)
            corridor_flow[bid] = float(flow)
            corridor_loading[bid] = float(loading)

            max_corridor_loading = max(max_corridor_loading, float(loading))
            if loading > 1.000001:
                corridor_thermal_violations += 1

        trace.append(
            {
                "network": f"IEEE118+{feeder_count}xIEEE33",
                "window_id": str(window_row.scenario),
                "seed": int(seed),
                "stress_regime": str(regime),
                "feeder_count": int(feeder_count),
                "mpc_horizon_h": int(requested_horizon_h),
                "case": str(case),
                "rating_policy": "STR" if case == "STR-SMPC" else "DLR",
                "hour_index": int(local_t),
                "timestamp_utc": str(ts),
                "actual_system_load_factor": float(actual_factor),
                "pcc_mw": float(pcc_mw),
                "pcc_q_mvar": float(pcc_q_mvar),
                "solver_success": bool(sol["success"]),
                "solver_status": int(sol["status"]),
                "solver_message": str(sol["message"]),
                "effective_horizon_h": int(sol["effective_horizon_h"]),
                "class_net_mw_json": json_dumps(class_net),
                "class_ev_charge_mw_json": json_dumps(class_x),
                "class_pv_available_mw_json": json_dumps(class_pv),
                "class_pv_curtail_mw_json": json_dumps(class_cur),
                "class_vmin_pu_json": json_dumps(class_vmin),
                "class_vmax_pu_json": json_dumps(class_vmax),
                "distribution_vmin_pu": float(min(class_vmin.values())),
                "distribution_vmax_pu": float(max(class_vmax.values())),
                "distribution_voltage_violation_feeders": int(
                    distribution_violation_feeders
                ),
                "corridor_ratings_mva_json": json_dumps(ratings),
                "reduced_corridor_flow_mw_json": json_dumps(corridor_flow),
                "reduced_corridor_loading_pu_json": json_dumps(corridor_loading),
                "reduced_max_selected_corridor_loading_pu": float(
                    max_corridor_loading
                ),
                "reduced_selected_corridor_thermal_violation_count": int(
                    corridor_thermal_violations
                ),
            }
        )

    return pd.DataFrame(trace)


def parse_int_float_json(text: str) -> dict[int, float]:
    obj = json.loads(str(text))
    return {int(k): float(v) for k, v in obj.items()}


def select_phase4c_pairs(ROOT: Path, fast_mode: bool = False) -> pd.DataFrame:
    """
    Pre-AC stress-targeted selection based only on frozen Phase-4C outputs.

    This is a validation sample, not a random statistical sample.
    """
    result_dir = ROOT / "09_simulation_inputs" / "results"
    res = pd.read_csv(result_dir / "phase4c_receding_horizon_results.csv")
    feas = pd.read_csv(result_dir / "phase4c_pair_feasibility.csv")

    res = res[res["mpc_horizon_h"].astype(int) == 4].copy()
    feas = feas[feas["mpc_horizon_h"].astype(int) == 4].copy()

    keys = [
        "stress_regime",
        "feeder_count",
        "mpc_horizon_h",
        "network",
        "window_id",
        "seed",
    ]

    strr = (
        res[res["case"] == "STR-SMPC"]
        .set_index(keys)
        .add_prefix("str_")
    )
    dlrr = (
        res[res["case"] == "DLR-SMPC"]
        .set_index(keys)
        .add_prefix("dlr_")
    )
    pair = feas.set_index(keys).join(strr, how="left").join(dlrr, how="left").reset_index()

    for c in ["both_strict_feasible", "dlr_restores_feasibility", "str_only_feasible"]:
        if c in pair:
            pair[c] = boolify(pair[c])

    picks = []
    used = set()

    def key_of(row):
        return (
            str(row["stress_regime"]),
            int(row["feeder_count"]),
            int(row["mpc_horizon_h"]),
            str(row["network"]),
            str(row["window_id"]),
            int(row["seed"]),
        )

    def pick(label, mask, sort_col):
        cand = pair.loc[mask].copy()
        if cand.empty:
            return
        cand = cand.sort_values(sort_col, ascending=False)
        for _, r in cand.iterrows():
            k = key_of(r)
            if k not in used:
                d = {c: r[c] for c in keys}
                d["selection_reason"] = label
                d["selection_score"] = float(r.get(sort_col, np.nan))
                picks.append(d)
                used.add(k)
                return

    high = pair["stress_regime"].eq("high")
    nominal = pair["stress_regime"].eq("nominal")

    pick(
        "high_DLR_restores_STR_infeasible",
        high & pair["dlr_restores_feasibility"],
        "str_max_loading_pu",
    )
    pick(
        "high_both_feasible_peak_thermal",
        high & pair["both_strict_feasible"],
        "str_max_loading_pu",
    )
    if not fast_mode:
        pick(
            "high_both_feasible_peak_voltage",
            high & pair["both_strict_feasible"],
            "str_voltage_violation_count",
        )
    pick(
        "nominal_both_feasible_peak_thermal",
        nominal & pair["both_strict_feasible"],
        "str_max_loading_pu",
    )
    if not fast_mode:
        pick(
            "nominal_both_feasible_peak_voltage",
            nominal & pair["both_strict_feasible"],
            "str_voltage_violation_count",
        )

    out = pd.DataFrame(picks)
    if out.empty:
        raise RuntimeError("Could not select any Phase-4C validation pairs.")

    out["pair_id"] = (
        out["stress_regime"].astype(str)
        + "|"
        + out["window_id"].astype(str)
        + "|seed="
        + out["seed"].astype(int).astype(str)
        + "|H="
        + out["mpc_horizon_h"].astype(int).astype(str)
    )
    return out


def choose_sentinel_hours(trace: pd.DataFrame, fast_mode: bool = False) -> pd.DataFrame:
    """
    Selects common timestamps per STR/DLR pair BEFORE any AC result is known.

    Criteria use only the frozen/replayed Phase-4 quantities:
    - peak reduced-order corridor loading,
    - lowest exact IEEE-33 voltage,
    - largest PCC import,
    - highest exact IEEE-33 voltage (omitted in fast mode).
    """
    rows = []

    pair_cols = [
        "pair_id",
        "window_id",
        "seed",
        "stress_regime",
        "feeder_count",
        "mpc_horizon_h",
    ]

    for key, g in trace.groupby(pair_cols, dropna=False):
        # Aggregate across policies at each timestamp so both policies are later
        # validated at exactly the same sentinel times.
        h = (
            g.groupby("timestamp_utc")
            .agg(
                phase4_max_corridor_loading=(
                    "reduced_max_selected_corridor_loading_pu",
                    "max",
                ),
                phase4_min_distribution_voltage=("distribution_vmin_pu", "min"),
                phase4_max_distribution_voltage=("distribution_vmax_pu", "max"),
                phase4_max_pcc_import_mw=("pcc_mw", "max"),
            )
            .reset_index()
        )

        criteria = [
            (
                "peak_phase4_corridor_loading",
                h.sort_values(
                    "phase4_max_corridor_loading", ascending=False
                ).iloc[0],
            ),
            (
                "minimum_exact_ieee33_voltage",
                h.sort_values(
                    "phase4_min_distribution_voltage", ascending=True
                ).iloc[0],
            ),
            (
                "maximum_PCC_import",
                h.sort_values("phase4_max_pcc_import_mw", ascending=False).iloc[0],
            ),
        ]
        if not fast_mode:
            criteria.append(
                (
                    "maximum_exact_ieee33_voltage",
                    h.sort_values(
                        "phase4_max_distribution_voltage", ascending=False
                    ).iloc[0],
                )
            )

        seen_ts = set()
        for reason, r in criteria:
            ts = str(r["timestamp_utc"])
            if ts in seen_ts:
                continue
            seen_ts.add(ts)
            d = dict(zip(pair_cols, key if isinstance(key, tuple) else (key,)))
            d.update(
                {
                    "timestamp_utc": ts,
                    "sentinel_reason": reason,
                    "phase4_max_corridor_loading": float(
                        r["phase4_max_corridor_loading"]
                    ),
                    "phase4_min_distribution_voltage": float(
                        r["phase4_min_distribution_voltage"]
                    ),
                    "phase4_max_distribution_voltage": float(
                        r["phase4_max_distribution_voltage"]
                    ),
                    "phase4_max_pcc_import_mw": float(
                        r["phase4_max_pcc_import_mw"]
                    ),
                }
            )
            rows.append(d)

    return pd.DataFrame(rows)


def add_pair_id(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["pair_id"] = (
        out["stress_regime"].astype(str)
        + "|"
        + out["window_id"].astype(str)
        + "|seed="
        + out["seed"].astype(int).astype(str)
        + "|H="
        + out["mpc_horizon_h"].astype(int).astype(str)
    )
    return out


def summarize_group(
    df: pd.DataFrame,
    group_cols: list[str],
    success_col: str,
    error_col: str,
    voltage_viol_col: str,
    thermal_viol_col: str,
) -> pd.DataFrame:
    z = df.copy()
    z["_success"] = boolify(z[success_col])
    z["_error"] = z[error_col].notna() & z[error_col].astype(str).str.len().gt(0)
    z["_voltage_clean"] = pd.to_numeric(
        z[voltage_viol_col], errors="coerce"
    ).fillna(np.inf).eq(0)
    z["_thermal_clean"] = pd.to_numeric(
        z[thermal_viol_col], errors="coerce"
    ).fillna(np.inf).eq(0)
    z["_security_clean"] = z["_success"] & z["_voltage_clean"] & z["_thermal_clean"]

    return (
        z.groupby(group_cols, dropna=False)
        .agg(
            evaluations=(success_col, "size"),
            successful=(success_col, lambda s: int(boolify(s).sum())),
            execution_errors=("_error", "sum"),
            voltage_clean=("_voltage_clean", "sum"),
            thermal_clean=("_thermal_clean", "sum"),
            security_clean=("_security_clean", "sum"),
        )
        .reset_index()
    )
