
from __future__ import annotations

"""Phase 5B — IEEE-118 ACOPF validation of the frozen Phase-5A sentinel states."""

from pathlib import Path
import importlib.util
import json
import os
import time

import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")
IN = OUTDIR / "phase5a_acpf_results.csv"
OUT = OUTDIR / "phase5b_acopf_results.csv"
SUMMARY_OUT = OUTDIR / "phase5b_summary.csv"
META_OUT = OUTDIR / "phase5b_metadata.json"

if not IN.exists():
    raise FileNotFoundError(f"Phase-5A output not found: {IN}")

p4c = c.import_phase4c(ROOT)
branch_ids = [int(x["branch_id"]) for x in c.corridor_rows_from_phase4(p4c.p4)]
backend = c.load_power_backend()
print("EPSR ROOT:", ROOT)
print("PHASE 5B — IEEE-118 ACOPF validation")
print("AC backend:", backend["name"])

src = pd.read_csv(IN)
records = []
t0 = time.perf_counter()

for i, row in src.iterrows():
    ratings = c.parse_int_float_json(row["corridor_ratings_mva_json"])
    mpc = c.build_case118_state(
        backend,
        pcc_mw=float(row["pcc_mw"]),
        pcc_q_mvar=float(row["pcc_q_mvar"]),
        pcc_bus=78,
        ratings_by_branch=ratings,
        vmin=0.95,
        vmax=1.05,
    )

    result, success, error = c.run_opf(backend, mpc)
    ev = c.evaluate_ac_result(
        result,
        corridor_branch_ids=branch_ids,
        vmin=0.95,
        vmax=1.05,
    )

    objective = np.nan
    if result is not None and "f" in result:
        objective = float(result["f"])

    records.append(
        {
            "pair_id": row["pair_id"],
            "window_id": row["window_id"],
            "seed": int(row["seed"]),
            "stress_regime": row["stress_regime"],
            "feeder_count": int(row["feeder_count"]),
            "mpc_horizon_h": int(row["mpc_horizon_h"]),
            "timestamp_utc": row["timestamp_utc"],
            "sentinel_reason": row["sentinel_reason"],
            "case": row["case"],
            "rating_policy": row["rating_policy"],
            "pcc_mw": float(row["pcc_mw"]),
            "pcc_q_mvar": float(row["pcc_q_mvar"]),
            "corridor_ratings_mva_json": row["corridor_ratings_mva_json"],
            "ac_backend": backend["name"],
            "acopf_success": bool(success),
            "acopf_error": error,
            "acopf_objective": objective,
            "acopf_bus_vmin_pu": ev["bus_vmin_pu"],
            "acopf_bus_vmax_pu": ev["bus_vmax_pu"],
            "acopf_bus_voltage_violation_count": ev[
                "bus_voltage_violation_count"
            ],
            "acopf_selected_corridor_max_loading_pu": ev[
                "selected_corridor_max_loading_pu"
            ],
            "acopf_selected_corridor_thermal_violation_count": ev[
                "selected_corridor_thermal_violation_count"
            ],
            "acopf_selected_corridor_loading_json": ev[
                "selected_corridor_loading_json"
            ],
            "phase5b_status": (
                "ACOPF redispatch validation; ACOPF feasibility is not expected "
                "to duplicate Phase-4 SMPC feasibility because generator redispatch "
                "degrees of freedom differ"
            ),
        }
    )

    if (i + 1) % 10 == 0 or (i + 1) == len(src):
        print(f"ACOPF evaluated {i + 1}/{len(src)} operating states")

df = pd.DataFrame(records)
df.to_csv(OUT, index=False)

summary = (
    df.assign(
        acopf_ok=c.boolify(df["acopf_success"]),
        voltage_clean=pd.to_numeric(
            df["acopf_bus_voltage_violation_count"], errors="coerce"
        ).eq(0),
        thermal_clean=pd.to_numeric(
            df["acopf_selected_corridor_thermal_violation_count"], errors="coerce"
        ).eq(0),
    )
    .groupby(["stress_regime", "case"], dropna=False)
    .agg(
        operating_points=("timestamp_utc", "size"),
        acopf_successful=("acopf_ok", "sum"),
        execution_errors=("acopf_error", lambda s: int(s.notna().sum())),
        voltage_clean=("voltage_clean", "sum"),
        selected_corridor_thermal_clean=("thermal_clean", "sum"),
        mean_objective=("acopf_objective", "mean"),
        mean_max_loading=("acopf_selected_corridor_max_loading_pu", "mean"),
        worst_vmin=("acopf_bus_vmin_pu", "min"),
        worst_vmax=("acopf_bus_vmax_pu", "max"),
    )
    .reset_index()
)
summary.to_csv(SUMMARY_OUT, index=False)

errors = int(df["acopf_error"].notna().sum())
if errors:
    raise RuntimeError(
        f"Phase-5B had {errors} ACOPF backend execution exceptions. "
        "Returned ACOPF infeasibility is a research result; exceptions are not."
    )

META_OUT.write_text(
    json.dumps(
        {
            "stage": "5B",
            "backend": backend["name"],
            "evaluations": int(len(df)),
            "note": (
                "ACOPF uses IEEE-118 generator redispatch and 0.95–1.05 pu bus "
                "voltage limits with frozen selected-corridor STR/DLR ratings."
            ),
            "output": str(OUT),
        },
        indent=2,
    ),
    encoding="utf-8",
)

print("\nPHASE-5B SUMMARY")
print(summary.to_string(index=False))
print("\nPASS: PHASE 5B COMPUTATION COMPLETE.")
print("Saved:", OUT)
print("runtime_s:", time.perf_counter() - t0)
