import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from epsr_pipeline.common import ensure_directories, ROOT
import shutil

ensure_directories()
template = ROOT / "00_documentation/data_sources_template.csv"
manifest = ROOT / "00_documentation/data_sources.csv"
if template.exists() and not manifest.exists():
    shutil.copy2(template, manifest)
print(f"Project structure ready: {ROOT}")
print("Next: run scripts/01_audit_legacy.py")
