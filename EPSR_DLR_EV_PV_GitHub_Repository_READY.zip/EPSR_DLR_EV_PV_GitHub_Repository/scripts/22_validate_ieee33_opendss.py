import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from epsr_pipeline.common import ROOT

try:
    from opendssdirect import dss
except Exception as e:
    raise SystemExit('OpenDSSDirect.py is required. Install with: pip install "OpenDSSDirect.py>=0.9"\nOriginal import error: '+repr(e))

master=(ROOT/'09_simulation_inputs/ieee33_opendss/IEEE33_Master.dss').resolve()
dss.Text.Command('Clear')
dss.Text.Command(f'Compile "{master}"')
dss.Solution.Solve()
if not dss.Solution.Converged():
    raise SystemExit('OpenDSS did not converge.')

rows=[]
for bus in dss.Circuit.AllBusNames():
    if not bus.lower().startswith('b'):
        continue
    dss.Circuit.SetActiveBus(bus)
    vals=dss.Bus.puVmagAngle()
    mags=np.asarray(vals[0::2],dtype=float)
    busnum=int(bus[1:])
    rows.append({'bus':busnum,'voltage_pu':float(np.mean(mags)),'min_phase_voltage_pu':float(np.min(mags)),'max_phase_voltage_pu':float(np.max(mags))})
bus=pd.DataFrame(rows).sort_values('bus')
loss=dss.Circuit.LineLosses()  # W, var
loss_kw=float(loss[0])/1000.0; loss_kvar=float(loss[1])/1000.0
ref=pd.read_csv(ROOT/'05_quality_control/ieee33_independent_benchmark.csv').iloc[0]
summary=pd.DataFrame([{
    'opendss_converged':True,
    'opendss_min_voltage_pu':float(bus.voltage_pu.min()),
    'opendss_min_voltage_bus':int(bus.loc[bus.voltage_pu.idxmin(),'bus']),
    'reference_min_voltage_pu':float(ref.minimum_voltage_pu),
    'min_voltage_abs_error_pu':abs(float(bus.voltage_pu.min())-float(ref.minimum_voltage_pu)),
    'opendss_line_loss_kw':loss_kw,
    'reference_line_loss_kw':float(ref.total_line_loss_kw),
    'line_loss_relative_error_pct':abs(loss_kw-float(ref.total_line_loss_kw))/float(ref.total_line_loss_kw)*100.0,
    'pass_voltage':abs(float(bus.voltage_pu.min())-float(ref.minimum_voltage_pu)) <= 0.002,
    'pass_loss':abs(loss_kw-float(ref.total_line_loss_kw))/float(ref.total_line_loss_kw)*100.0 <= 1.0,
}])
summary['overall_pass']=summary.pass_voltage & summary.pass_loss & summary.opendss_converged
bus.to_csv(ROOT/'05_quality_control/ieee33_opendss_bus_voltage_validation.csv',index=False)
summary.to_csv(ROOT/'05_quality_control/ieee33_opendss_validation_summary.csv',index=False)
print(summary.to_string(index=False))
if not bool(summary.overall_pass.iloc[0]):
    raise SystemExit('IEEE-33 OpenDSS validation FAILED tolerance gate.')
print('IEEE-33 OpenDSS validation PASSED.')
