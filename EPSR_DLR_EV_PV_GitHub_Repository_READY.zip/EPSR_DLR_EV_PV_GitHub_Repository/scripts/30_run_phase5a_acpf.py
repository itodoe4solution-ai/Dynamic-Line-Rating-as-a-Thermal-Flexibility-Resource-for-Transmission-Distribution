
from __future__ import annotations

"""Phase 5A — stress-targeted AC power-flow + exact IEEE-33 validation."""

from pathlib import Path
import importlib.util
import json
import os
import time

import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")

PAIR_OUT = OUTDIR / "phase5a_selected_pairs.csv"
TRACE_OUT = OUTDIR / "phase5a_replay_trace.csv"
SENTINEL_OUT = OUTDIR / "phase5a_selected_operating_points.csv"
RESULT_OUT = OUTDIR / "phase5a_acpf_results.csv"
SUMMARY_OUT = OUTDIR / "phase5a_summary.csv"
META_OUT = OUTDIR / "phase5a_metadata.json"

FAST_MODE = os.environ.get("PHASE5_FAST_MODE", "0").strip() == "1"
REUSE_TRACE = os.environ.get("PHASE5_REUSE_5A_TRACE", "1").strip() == "1"

print("EPSR ROOT:", ROOT)
print("PHASE 5A — AC power-flow / exact IEEE-33 validation")
print("Fast mode:", FAST_MODE)

p4c = c.import_phase4c(ROOT)
p4 = p4c.p4
backend = c.load_power_backend()
print("AC backend:", backend["name"])

pairs = c.select_phase4c_pairs(ROOT, fast_mode=FAST_MODE)
pairs.to_csv(PAIR_OUT, index=False)
print("Selected Phase-4C validation pairs:", len(pairs))
print(pairs[["pair_id", "selection_reason"]].to_string(index=False))

trace = None
if REUSE_TRACE and TRACE_OUT.exists():
    candidate = pd.read_csv(TRACE_OUT)
    expected_pair_ids = set(pairs["pair_id"])
    have_pair_ids = set(candidate.get("pair_id", pd.Series(dtype=str)))
    expected_cases = {"STR-SMPC", "DLR-SMPC"}
    if expected_pair_ids.issubset(have_pair_ids) and expected_cases.issubset(
        set(candidate.get("case", pd.Series(dtype=str)))
    ):
        trace = candidate[
            candidate["pair_id"].astype(str).isin(expected_pair_ids)
        ].copy()
        print("Reusing compatible Phase-5A replay trace:", TRACE_OUT)

if trace is None:
    period_map = (
        p4c.periods_all.set_index("scenario", drop=False)
        if "scenario" in p4c.periods_all.columns
        else p4c.periods_all.set_index("window_id", drop=False)
    )

    pieces = []
    for _, sel in pairs.iterrows():
        window_id = str(sel["window_id"])
        if window_id not in period_map.index:
            raise KeyError(f"Frozen window not found: {window_id}")
        window_row = period_map.loc[window_id]
        if isinstance(window_row, pd.DataFrame):
            window_row = window_row.iloc[0]

        for case in ["STR-SMPC", "DLR-SMPC"]:
            print(
                f"Replaying {sel['pair_id']} | {case} "
                "(true hourly receding horizon; recording trace only)"
            )
            tr = c.replay_case_with_trace(
                p4c,
                window_row=window_row,
                seed=int(sel["seed"]),
                case=case,
                regime=str(sel["stress_regime"]),
                requested_horizon_h=int(sel["mpc_horizon_h"]),
            )
            tr = c.add_pair_id(tr)
            pieces.append(tr)

    trace = pd.concat(pieces, ignore_index=True)
    trace.to_csv(TRACE_OUT, index=False)

sentinel = c.choose_sentinel_hours(trace, fast_mode=FAST_MODE)
sentinel.to_csv(SENTINEL_OUT, index=False)
print("Common sentinel timestamps selected BEFORE AC evaluation:", len(sentinel))

# Validate both STR and DLR at every selected timestamp.
ops = (
    trace.merge(
        sentinel[
            [
                "pair_id",
                "timestamp_utc",
                "sentinel_reason",
            ]
        ],
        on=["pair_id", "timestamp_utc"],
        how="inner",
        validate="many_to_one",
    )
    .copy()
)

corridor_rows = c.corridor_rows_from_phase4(p4)
branch_ids = [int(x["branch_id"]) for x in corridor_rows]

records = []
t0 = time.perf_counter()

for i, row in ops.iterrows():
    ratings = c.parse_int_float_json(row["corridor_ratings_mva_json"])

    mpc = c.build_case118_state(
        backend,
        pcc_mw=float(row["pcc_mw"]),
        pcc_q_mvar=float(row["pcc_q_mvar"]),
        pcc_bus=78,
        ratings_by_branch=ratings,
        vmin=0.95,
        vmax=1.05,
    )

    result, success, error = c.run_pf(backend, mpc)
    ev = c.evaluate_ac_result(
        result,
        corridor_branch_ids=branch_ids,
        vmin=0.95,
        vmax=1.05,
    )

    rec = row.to_dict()
    rec.update(
        {
            "ac_backend": backend["name"],
            "acpf_success": bool(success),
            "acpf_error": error,
            "acpf_bus_vmin_pu": ev["bus_vmin_pu"],
            "acpf_bus_vmax_pu": ev["bus_vmax_pu"],
            "acpf_bus_voltage_violation_count": ev[
                "bus_voltage_violation_count"
            ],
            "acpf_selected_corridor_max_loading_pu": ev[
                "selected_corridor_max_loading_pu"
            ],
            "acpf_selected_corridor_thermal_violation_count": ev[
                "selected_corridor_thermal_violation_count"
            ],
            "acpf_selected_corridor_loading_json": ev[
                "selected_corridor_loading_json"
            ],
            "phase5_distribution_voltage_limit_low_pu": 0.95,
            "phase5_distribution_voltage_limit_high_pu": 1.05,
            "phase5_distribution_security_clean": bool(
                int(row["distribution_voltage_violation_feeders"]) == 0
            ),
            "phase5a_status": (
                "stress-targeted AC validation point; selection based only on "
                "frozen Phase-4 quantities before AC outcomes"
            ),
        }
    )
    records.append(rec)

    if (i + 1) % 10 == 0 or (i + 1) == len(ops):
        print(f"ACPF evaluated {i + 1}/{len(ops)} operating states")

df = pd.DataFrame(records)
df.to_csv(RESULT_OUT, index=False)

summary = (
    df.assign(
        transmission_voltage_clean=lambda x: pd.to_numeric(
            x["acpf_bus_voltage_violation_count"], errors="coerce"
        ).eq(0),
        transmission_thermal_clean=lambda x: pd.to_numeric(
            x["acpf_selected_corridor_thermal_violation_count"], errors="coerce"
        ).eq(0),
        distribution_voltage_clean=lambda x: pd.to_numeric(
            x["distribution_voltage_violation_feeders"], errors="coerce"
        ).eq(0),
    )
    .groupby(["stress_regime", "case"], dropna=False)
    .agg(
        operating_points=("timestamp_utc", "size"),
        acpf_converged=("acpf_success", lambda s: int(c.boolify(s).sum())),
        execution_errors=("acpf_error", lambda s: int(s.notna().sum())),
        transmission_voltage_clean=("transmission_voltage_clean", "sum"),
        selected_corridor_thermal_clean=("transmission_thermal_clean", "sum"),
        distribution_voltage_clean=("distribution_voltage_clean", "sum"),
        mean_acpf_max_loading=(
            "acpf_selected_corridor_max_loading_pu",
            "mean",
        ),
        worst_acpf_vmin=("acpf_bus_vmin_pu", "min"),
        worst_acpf_vmax=("acpf_bus_vmax_pu", "max"),
        worst_ieee33_vmin=("distribution_vmin_pu", "min"),
        worst_ieee33_vmax=("distribution_vmax_pu", "max"),
    )
    .reset_index()
)
summary.to_csv(SUMMARY_OUT, index=False)

# Process-integrity checks, not outcome-forcing security checks.
pair_time_case_counts = (
    df.groupby(["pair_id", "timestamp_utc"])["case"].nunique()
)
complete_pairs = bool((pair_time_case_counts == 2).all())
execution_errors = int(df["acpf_error"].notna().sum())

if not complete_pairs:
    raise RuntimeError("Phase-5A STR/DLR sentinel design is not fully paired.")
if execution_errors:
    raise RuntimeError(
        f"Phase-5A had {execution_errors} AC backend execution exceptions. "
        "Non-converged PF returned normally is a research outcome; Python/backend "
        "exceptions are not."
    )

meta = {
    "stage": "5A",
    "backend": backend["name"],
    "fast_mode": FAST_MODE,
    "pair_count": int(len(pairs)),
    "sentinel_timestamp_count": int(len(sentinel)),
    "operating_state_count": int(len(df)),
    "validation_selection": (
        "stress-targeted using frozen Phase-4C H=4 outcomes only; "
        "AC results are not used to select points"
    ),
    "transmission_model": (
        "PYPOWER/MATPOWER IEEE-118 base case with frozen aggregate PCC active and "
        "reactive demand added at bus 78; selected five corridors use timestamp-"
        "specific STR/DLR ratings; other case118 ratings remain as provided"
    ),
    "distribution_model": (
        "exact balanced IEEE-33 backward/forward sweep already frozen in Phase 4, "
        "evaluated against 0.95–1.05 pu"
    ),
    "note": (
        "Phase-5A pass means the validation calculations completed consistently. "
        "Voltage/thermal violations, if present, remain research results."
    ),
    "outputs": [str(PAIR_OUT), str(TRACE_OUT), str(SENTINEL_OUT), str(RESULT_OUT), str(SUMMARY_OUT)],
}
META_OUT.write_text(json.dumps(meta, indent=2), encoding="utf-8")

print("\nPHASE-5A SUMMARY")
print(summary.to_string(index=False))
print("\nPASS: PHASE 5A COMPUTATION COMPLETE.")
print("Saved:", RESULT_OUT)
print("runtime_s:", time.perf_counter() - t0)
