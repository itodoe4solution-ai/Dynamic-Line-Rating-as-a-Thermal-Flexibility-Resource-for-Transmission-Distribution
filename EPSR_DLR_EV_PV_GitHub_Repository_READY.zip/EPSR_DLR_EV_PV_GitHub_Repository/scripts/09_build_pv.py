import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, ensure_directories
from epsr_pipeline.pv import build_pv_profile

ensure_directories(); cfg=load_config()
w=pd.read_csv(ROOT/"03_processed/weather_solar_15min.csv",parse_dates=["timestamp_utc"])
pv=build_pv_profile(w,cfg)
pv.to_csv(ROOT/"03_processed/pv_profile_physical_15min.csv",index=False)
print(pv[["pv_dc_kw","pv_ac_kw"]].describe().to_string())
