
from __future__ import annotations

"""
Phase 5D — IEEE-39 transferability / robustness validation.

This is explicitly a normalized-rating robustness test, not a claim that the
IEEE-39 branches physically use the same Drake conductor as the IEEE-118 DLR
benchmark. The DLR/STR ratio is transferred as a dimensionless rating-uplift
factor onto a baseline-selected set of IEEE-39 branches.
"""

from pathlib import Path
import importlib.util
import json
import math
import os
import time

import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")
IN = OUTDIR / "phase5a_acpf_results.csv"
SEL_OUT = OUTDIR / "phase5d_ieee39_frozen_selection.csv"
OUT = OUTDIR / "phase5d_ieee39_results.csv"
SUMMARY_OUT = OUTDIR / "phase5d_summary.csv"
META_OUT = OUTDIR / "phase5d_metadata.json"

if not IN.exists():
    raise FileNotFoundError(f"Phase-5A output not found: {IN}")

backend = c.load_power_backend()
print("EPSR ROOT:", ROOT)
print("PHASE 5D — IEEE-39 normalized robustness validation")
print("AC backend:", backend["name"])

base39 = backend["case39"]()
base118 = backend["case118"]()

# Baseline case39 power flow is used only to freeze the robustness-test
# branch set before any transferred DLR result is calculated.
r0, s0, e0 = c.run_pf(backend, base39)
if e0 is not None:
    raise RuntimeError(f"IEEE-39 baseline PF backend exception: {e0}")
if not s0:
    raise RuntimeError("IEEE-39 baseline PF did not converge.")

bus39 = r0["bus"]
branch39 = r0["branch"]

# PCC analog: largest non-slack active-load bus, selected from baseline only.
non_slack = bus39[:, c.BUS_TYPE].astype(int) != 3
candidate_buses = bus39[non_slack]
pcc39_bus = int(candidate_buses[np.argmax(candidate_buses[:, c.PD]), c.BUS_I])

# Branch set: top five baseline-loaded in-service non-transformer branches
# with usable native ratings. This selection is independent of Phase-5D outcome.
cand = []
for i, br in enumerate(branch39):
    if int(round(br[c.BR_STATUS])) == 0:
        continue
    rating = float(br[c.RATE_A])
    if not np.isfinite(rating) or rating <= 0 or rating >= 9000:
        continue
    if abs(float(br[c.TAP])) > 1e-12:
        continue
    sf = math.hypot(float(br[c.PF]), float(br[c.QF]))
    st = math.hypot(float(br[c.PT]), float(br[c.QT]))
    ld = max(sf, st) / rating
    cand.append(
        {
            "branch_id": i + 1,
            "from_bus": int(br[c.F_BUS]),
            "to_bus": int(br[c.T_BUS]),
            "native_rate_a_mva": rating,
            "baseline_loading_pu": float(ld),
        }
    )

selection = (
    pd.DataFrame(cand)
    .sort_values("baseline_loading_pu", ascending=False)
    .head(5)
    .reset_index(drop=True)
)
if len(selection) < 5:
    raise RuntimeError("Could not freeze five usable IEEE-39 robustness branches.")

selection["selection_rank"] = np.arange(1, len(selection) + 1)
selection["pcc39_bus"] = pcc39_bus
selection["selection_rule"] = (
    "top five baseline-loaded in-service non-transformer branches with "
    "0 < native RATE_A < 9000 MVA; selection uses baseline case39 only"
)
selection.to_csv(SEL_OUT, index=False)

selected39 = selection["branch_id"].astype(int).tolist()
native39_rate = dict(
    zip(
        selection["branch_id"].astype(int),
        selection["native_rate_a_mva"].astype(float),
    )
)

pd118 = float(np.sum(base118["bus"][:, c.PD]))
pd39 = float(np.sum(base39["bus"][:, c.PD]))
system_scale = pd39 / pd118

src = pd.read_csv(IN)
records = []
t0 = time.perf_counter()

for i, row in src.iterrows():
    original_ratings = c.parse_int_float_json(row["corridor_ratings_mva_json"])
    # All five Phase-2 corridors share the same frozen conductor/weather basis.
    # Use the mean dynamic uplift only as a dimensionless transfer factor.
    if str(row["rating_policy"]).upper() == "STR":
        uplift = 1.0
    else:
        str_ref = 171.49903864534676
        uplift = float(np.mean(list(original_ratings.values()))) / str_ref

    mpc = c._copy_case(base39)
    c._set_voltage_limits(mpc, vmin=0.95, vmax=1.05)

    bi = c._bus_row(mpc, pcc39_bus)
    mapped_p_mw = float(row["pcc_mw"]) * system_scale
    mapped_q_mvar = float(row["pcc_q_mvar"]) * system_scale
    mpc["bus"][bi, c.PD] += mapped_p_mw
    mpc["bus"][bi, c.QD] += mapped_q_mvar

    mapped_ratings = {
        bid: native39_rate[bid] * uplift
        for bid in selected39
    }
    c.apply_selected_corridor_ratings(mpc, mapped_ratings)

    pfr, pfs, pfe = c.run_pf(backend, mpc)
    pfev = c.evaluate_ac_result(
        pfr,
        corridor_branch_ids=selected39,
        vmin=0.95,
        vmax=1.05,
    )

    opfr, opfs, opfe = c.run_opf(backend, mpc)
    opev = c.evaluate_ac_result(
        opfr,
        corridor_branch_ids=selected39,
        vmin=0.95,
        vmax=1.05,
    )

    records.append(
        {
            "pair_id": row["pair_id"],
            "window_id": row["window_id"],
            "seed": int(row["seed"]),
            "stress_regime": row["stress_regime"],
            "timestamp_utc": row["timestamp_utc"],
            "case": row["case"],
            "rating_policy": row["rating_policy"],
            "ieee39_pcc_bus": int(pcc39_bus),
            "system_load_scale_39_over_118": float(system_scale),
            "mapped_pcc_mw": mapped_p_mw,
            "mapped_pcc_q_mvar": mapped_q_mvar,
            "rating_uplift_factor": float(uplift),
            "selected_ieee39_branch_ids_json": c.json_dumps(selected39),
            "mapped_ratings_mva_json": c.json_dumps(mapped_ratings),
            "ieee39_acpf_success": bool(pfs),
            "ieee39_acpf_error": pfe,
            "ieee39_acpf_bus_vmin_pu": pfev["bus_vmin_pu"],
            "ieee39_acpf_bus_vmax_pu": pfev["bus_vmax_pu"],
            "ieee39_acpf_bus_voltage_violation_count": pfev[
                "bus_voltage_violation_count"
            ],
            "ieee39_acpf_selected_branch_max_loading_pu": pfev[
                "selected_corridor_max_loading_pu"
            ],
            "ieee39_acpf_selected_branch_thermal_violation_count": pfev[
                "selected_corridor_thermal_violation_count"
            ],
            "ieee39_acopf_success": bool(opfs),
            "ieee39_acopf_error": opfe,
            "ieee39_acopf_bus_vmin_pu": opev["bus_vmin_pu"],
            "ieee39_acopf_bus_vmax_pu": opev["bus_vmax_pu"],
            "ieee39_acopf_bus_voltage_violation_count": opev[
                "bus_voltage_violation_count"
            ],
            "ieee39_acopf_selected_branch_max_loading_pu": opev[
                "selected_corridor_max_loading_pu"
            ],
            "ieee39_acopf_selected_branch_thermal_violation_count": opev[
                "selected_corridor_thermal_violation_count"
            ],
        }
    )

    if (i + 1) % 10 == 0 or (i + 1) == len(src):
        print(f"IEEE-39 evaluated {i + 1}/{len(src)} mapped operating states")

df = pd.DataFrame(records)
df.to_csv(OUT, index=False)

summary = (
    df.assign(
        pf_ok=c.boolify(df["ieee39_acpf_success"]),
        opf_ok=c.boolify(df["ieee39_acopf_success"]),
        pf_vclean=pd.to_numeric(
            df["ieee39_acpf_bus_voltage_violation_count"], errors="coerce"
        ).eq(0),
        pf_tclean=pd.to_numeric(
            df["ieee39_acpf_selected_branch_thermal_violation_count"],
            errors="coerce",
        ).eq(0),
        opf_vclean=pd.to_numeric(
            df["ieee39_acopf_bus_voltage_violation_count"], errors="coerce"
        ).eq(0),
        opf_tclean=pd.to_numeric(
            df["ieee39_acopf_selected_branch_thermal_violation_count"],
            errors="coerce",
        ).eq(0),
    )
    .groupby(["stress_regime", "case"], dropna=False)
    .agg(
        mapped_points=("timestamp_utc", "size"),
        pf_successful=("pf_ok", "sum"),
        opf_successful=("opf_ok", "sum"),
        pf_voltage_clean=("pf_vclean", "sum"),
        pf_thermal_clean=("pf_tclean", "sum"),
        opf_voltage_clean=("opf_vclean", "sum"),
        opf_thermal_clean=("opf_tclean", "sum"),
        mean_rating_uplift=("rating_uplift_factor", "mean"),
        mean_pf_max_loading=(
            "ieee39_acpf_selected_branch_max_loading_pu", "mean"
        ),
        mean_opf_max_loading=(
            "ieee39_acopf_selected_branch_max_loading_pu", "mean"
        ),
    )
    .reset_index()
)
summary.to_csv(SUMMARY_OUT, index=False)

errors = int(df["ieee39_acpf_error"].notna().sum()) + int(
    df["ieee39_acopf_error"].notna().sum()
)
if errors:
    raise RuntimeError(
        f"Phase-5D had {errors} backend execution exceptions. "
        "Returned PF/OPF non-convergence is retained as a research outcome."
    )

META_OUT.write_text(
    json.dumps(
        {
            "stage": "5D",
            "backend": backend["name"],
            "ieee39_pcc_bus": pcc39_bus,
            "selected_branch_ids": selected39,
            "system_scale_39_over_118": system_scale,
            "interpretation_boundary": (
                "The DLR/STR ratio is transferred as a dimensionless rating-uplift "
                "factor. This is a robustness/generalization experiment, not a claim "
                "that IEEE-39 branches use the same physical conductor."
            ),
            "selection_output": str(SEL_OUT),
            "output": str(OUT),
        },
        indent=2,
    ),
    encoding="utf-8",
)

print("\nFROZEN IEEE-39 ROBUSTNESS SELECTION")
print(selection.to_string(index=False))
print("\nPHASE-5D SUMMARY")
print(summary.to_string(index=False))
print("\nPASS: PHASE 5D COMPUTATION COMPLETE.")
print("Saved:", OUT)
print("runtime_s:", time.perf_counter() - t0)
