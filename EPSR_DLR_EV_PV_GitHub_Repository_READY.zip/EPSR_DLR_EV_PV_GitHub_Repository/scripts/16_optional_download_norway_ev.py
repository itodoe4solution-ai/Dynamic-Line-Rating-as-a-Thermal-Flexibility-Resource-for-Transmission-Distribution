import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import requests
from epsr_pipeline.common import ROOT

RECORD_ID = "13896176"
API = f"https://zenodo.org/api/records/{RECORD_ID}"
WANTED = {
    "Dataset1_charging_reports.csv",
    "Dataset2_user_predictions.csv",
    "Dataset3_session_predictions.csv",
    "Dataset4_hourly_predictions.csv",
}

out = ROOT / "01_raw/external_ev/norway"
out.mkdir(parents=True, exist_ok=True)
meta = requests.get(API, timeout=60)
meta.raise_for_status()
record = meta.json()
for f in record.get("files", []):
    key = f.get("key")
    if key not in WANTED:
        continue
    url = (f.get("links") or {}).get("content") or (f.get("links") or {}).get("self")
    if not url:
        print(f"No content URL for {key}; skipped")
        continue
    path = out / key
    if path.exists():
        print(f"Exists, skipped: {path.name}")
        continue
    with requests.get(url, stream=True, timeout=180) as r:
        r.raise_for_status()
        with path.open("wb") as fh:
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk: fh.write(chunk)
    print(f"Downloaded {path.name}")
print("External Norway data are for robustness testing only. Do not merge them into the California primary timeline.")
