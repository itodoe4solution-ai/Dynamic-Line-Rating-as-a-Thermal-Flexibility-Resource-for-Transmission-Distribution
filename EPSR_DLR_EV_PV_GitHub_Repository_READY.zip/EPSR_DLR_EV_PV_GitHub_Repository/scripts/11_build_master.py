import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories, read_json
from epsr_pipeline.master import build_master

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
ev=pd.read_csv(ROOT/"03_processed/ev_profile_15min.csv",parse_dates=["timestamp_utc"])
w=pd.read_csv(ROOT/"03_processed/weather_solar_15min.csv",parse_dates=["timestamp_utc"])
pv=pd.read_csv(ROOT/"03_processed/pv_profile_physical_15min.csv",parse_dates=["timestamp_utc"])
eia=pd.read_csv(ROOT/"03_processed/eia930_ciso_15min.csv",parse_dates=["timestamp_utc"])
dlr=pd.read_csv(ROOT/"08_dlr/dlr_15min.csv",parse_dates=["timestamp_utc"])
str_info=read_json(ROOT/"08_dlr/static_rating.json")
seasonal=pd.read_csv(ROOT/"08_dlr/seasonal_ratings.csv")
master=build_master(start,end,int(cfg["project"]["interval_minutes"]),cfg["project"]["timezone_local"],ev,w,pv,eia,dlr,str_info,seasonal)
master.to_csv(ROOT/"04_master/master_dataset_working.csv",index=False)
print(f"Master rows={len(master)}, columns={len(master.columns)}")
