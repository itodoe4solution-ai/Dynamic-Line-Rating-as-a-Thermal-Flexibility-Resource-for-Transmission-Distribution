
from __future__ import annotations

"""PHASE 6E — FINAL PUBLICATION PACKAGE / NARRATIVE / FREEZE."""

from pathlib import Path
import importlib.util
import json
import zipfile
import pandas as pd
import numpy as np


def load_common():
    path = Path(__file__).resolve().parent / "36_phase6_common.py"
    spec = importlib.util.spec_from_file_location("phase6_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
R = ROOT / "09_simulation_inputs" / "results"
P6 = c.ensure_dir(R / "phase6")
FIGDIR = P6 / "figures"
TDIR = P6 / "tables"
PKGDIR = c.ensure_dir(P6 / "publication_package")

CLAIMS = P6 / "phase6b_claim_evidence_matrix.csv"
FIG_INDEX = P6 / "phase6c_figure_index.csv"
TAB_INDEX = P6 / "phase6d_table_index.csv"
P5F = R / "phase5f_voltage_control_summary.csv"
P5FP = R / "phase5f_paired_str_dlr_effects.csv"
P5PAIR = R / "phase5e_paired_validation_effects.csv"

GATE_OUT = P6 / "phase6e_gate_summary.csv"
META_OUT = P6 / "phase6e_metadata.json"
NARRATIVE_OUT = PKGDIR / "phase6_results_discussion_draft.md"
ABSTRACT_OUT = PKGDIR / "phase6_abstract_evidence_notes.md"
LIMIT_OUT = PKGDIR / "phase6_limitations_and_claim_boundaries.md"
MANIFEST_OUT = PKGDIR / "phase6_publication_manifest.csv"
ZIP_OUT = P6 / "EPSR_Phase6_Publication_Package.zip"

claims = pd.read_csv(CLAIMS)
fig_index = pd.read_csv(FIG_INDEX)
tab_index = pd.read_csv(TAB_INDEX)
p5f = pd.read_csv(P5F)
p5fp = pd.read_csv(P5FP)
p5pair = pd.read_csv(P5PAIR)

def mean_effect(df, filt):
    z = df.loc[filt].copy()
    if z.empty:
        return np.nan
    return float(pd.to_numeric(z["DLR_minus_STR"], errors="coerce").mean())

a5 = mean_effect(
    p5pair,
    p5pair["stage"].astype(str).eq("5A")
    & p5pair["metric"].astype(str).eq("acpf_selected_corridor_max_loading_pu"),
)
b5 = mean_effect(
    p5pair,
    p5pair["stage"].astype(str).eq("5B")
    & p5pair["metric"].astype(str).eq("acpf_selected_corridor_max_loading_pu"),
)
c5 = mean_effect(
    p5pair,
    p5pair["stage"].astype(str).eq("5C")
    & p5pair["metric"].astype(str).eq("n1_remaining_selected_corridor_max_loading_pu"),
)
d5 = mean_effect(
    p5pair,
    p5pair["stage"].astype(str).eq("5D")
    & p5pair["metric"].astype(str).eq("ieee39_acpf_selected_branch_max_loading_pu"),
)
f5 = mean_effect(
    p5fp,
    p5fp["control_case"].astype(str).eq("OLTC_VOLT_VAR")
    & p5fp["metric"].astype(str).eq("ieee118_selected_corridor_max_loading_pu"),
)

oltc = p5f[p5f["control_case"].astype(str).eq("OLTC")]
comb = p5f[p5f["control_case"].astype(str).eq("OLTC_VOLT_VAR")]
vv = p5f[p5f["control_case"].astype(str).eq("VOLT_VAR")]
high_comb = comb[comb["stress_regime"].astype(str).eq("high")]

narrative = f"""# Phase 6 — Results and Discussion Evidence Draft

## Core result

The final evidence supports a deliberately bounded interpretation of dynamic line
rating (DLR): DLR is primarily a **thermal-flexibility resource**, while voltage
security requires explicit voltage/reactive-power control. Across the selected
AC validation states, the mean paired DLR-minus-STR maximum-loading effects were
{a5:.3f} pu in IEEE-118 AC power flow, {b5:.3f} pu in IEEE-118 ACOPF, and
{c5:.3f} pu under the selected IEEE-118 N-1 contingencies. The normalized
IEEE-39 robustness test retained the same direction, with a mean paired loading
effect of {d5:.3f} pu.

## Voltage-control sensitivity

The Phase-5F sensitivity resolves the main distribution-voltage limitation
without reopening Phase 4. OLTC achieved a minimum grouped IEEE-33
voltage-clean fraction of {oltc['ieee33_voltage_clean_fraction'].min():.3f}
across the selected STR/DLR states. Volt-VAR alone did not universally restore
the 0.95–1.05 pu criterion; its maximum grouped voltage-clean fraction was
{vv['ieee33_voltage_clean_fraction'].max():.3f}. Combined OLTC + Volt-VAR also
achieved a minimum grouped voltage-clean fraction of
{comb['ieee33_voltage_clean_fraction'].min():.3f} and increased voltage margin.

Crucially, the DLR thermal advantage persisted after combined voltage control:
the mean paired maximum-loading effect remained {f5:.3f} pu (DLR minus STR).
For the high-stress combined-control states, the thermal-clean fractions were
{float(high_comb.loc[high_comb['case'].eq('DLR-SMPC'),'ieee118_thermal_clean_fraction'].iloc[0]):.3f}
for DLR and
{float(high_comb.loc[high_comb['case'].eq('STR-SMPC'),'ieee118_thermal_clean_fraction'].iloc[0]):.3f}
for STR.

## Interpretation

These results support complementary operational roles. DLR expands the thermal
operating envelope and reduces corridor loading, whereas OLTC and inverter
reactive support address distribution-voltage compliance. Fixed-dispatch
transmission-voltage violations must not be attributed to DLR itself; they are
handled separately through ACOPF / transmission-level reactive-power and
redispatch mechanisms.

## Publication rule

Do not rewrite this evidence into claims of universal security, annual
guarantees, or conductor-specific IEEE-39 DLR performance. The validation is
stress-targeted and the IEEE-39 study transfers a dimensionless rating-uplift
factor rather than the physical Drake conductor model.
"""
NARRATIVE_OUT.write_text(narrative, encoding="utf-8")

abstract_notes = f"""# Abstract Evidence Notes

Use these facts when rewriting the abstract:

- Phase-4 true receding-horizon results distinguish nominal service effects from
  high-stress feasibility expansion.
- AC validation preserves the DLR loading advantage:
  - IEEE-118 ACPF mean paired loading effect: {a5:.3f} pu.
  - IEEE-118 ACOPF mean paired loading effect: {b5:.3f} pu.
  - selected N-1 mean paired loading effect: {c5:.3f} pu.
  - normalized IEEE-39 ACPF mean paired loading effect: {d5:.3f} pu.
- OLTC restored IEEE-33 voltage compliance across all selected Phase-5F groups.
- Combined OLTC + Volt-VAR preserved the DLR loading benefit ({f5:.3f} pu).
- Do not claim that DLR alone guarantees voltage security.
- Do not call the annual EV reconstruction fully measured 15-minute charging demand.
"""
ABSTRACT_OUT.write_text(abstract_notes, encoding="utf-8")

limitations = """# Limitations and Claim Boundaries

1. The annual EV series is an empirical reconstruction from ACN session
   arrival/departure and delivered-energy records; the majority of annual energy
   uses fallback duration-conditioned templates rather than measured current
   trajectories.

2. The main study is a benchmark-system study driven by Southern California
   data. It is not a calibrated representation of the physical California grid.

3. The five IEEE-118 DLR corridors use a common frozen conductor/weather basis
   as a controlled benchmark, not as a claim about actual IEEE-118 hardware.

4. Phase-4 distribution voltage screening is reduced-order. Phase 5/5F provides
   the stricter 0.95–1.05 pu exact IEEE-33 validation.

5. Phase-5 stress-targeted AC validation is not an annual exhaustive AC study.

6. Phase-5C N-1 validation covers the selected five corridor outages rather than
   every branch outage in IEEE-118.

7. Phase-5D transfers the DLR/STR rating ratio to IEEE-39 as a dimensionless
   robustness experiment. It is not conductor-specific IEEE-39 DLR.

8. Phase-5F OLTC and inverter Volt-VAR settings are explicit sensitivity
   assumptions. They are not field-calibrated device settings.

9. DLR is interpreted as a thermal-flexibility resource. Voltage security
   requires explicit voltage/reactive-power control and transmission-level
   redispatch where needed.

10. No Phase-4/5 parameter should be retuned after observing Phase-6 publication
    outputs.
"""
LIMIT_OUT.write_text(limitations, encoding="utf-8")

manifest_rows = []
for p in [CLAIMS, FIG_INDEX, TAB_INDEX, NARRATIVE_OUT, ABSTRACT_OUT, LIMIT_OUT]:
    manifest_rows.append(
        {
            "artifact": p.name,
            "path": str(p),
            "exists": p.exists(),
            "sha256": c.sha256(p) if p.exists() else None,
        }
    )
for p in sorted(FIGDIR.glob("*")):
    if p.is_file():
        manifest_rows.append(
            {
                "artifact": p.name,
                "path": str(p),
                "exists": True,
                "sha256": c.sha256(p),
            }
        )
for p in sorted(TDIR.glob("*")):
    if p.is_file():
        manifest_rows.append(
            {
                "artifact": p.name,
                "path": str(p),
                "exists": True,
                "sha256": c.sha256(p),
            }
        )
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(MANIFEST_OUT, index=False)

# Build zip.
with zipfile.ZipFile(ZIP_OUT, "w", zipfile.ZIP_DEFLATED) as zf:
    for p in sorted(FIGDIR.glob("*")):
        if p.is_file():
            zf.write(p, Path("figures") / p.name)
    for p in sorted(TDIR.glob("*")):
        if p.is_file():
            zf.write(p, Path("tables") / p.name)
    for p in [CLAIMS, NARRATIVE_OUT, ABSTRACT_OUT, LIMIT_OUT, MANIFEST_OUT]:
        zf.write(p, Path("publication_package") / p.name)

gates = pd.DataFrame(
    [
        {"gate": "all_claims_have_scope_limits", "status": bool(claims["scope_limit"].notna().all()), "note": "Every claim carries an explicit boundary."},
        {"gate": "high_resolution_figure_index_present", "status": len(fig_index) >= 7, "note": f"{len(fig_index)} figures indexed."},
        {"gate": "publication_table_index_present", "status": len(tab_index) >= 6, "note": f"{len(tab_index)} tables indexed."},
        {"gate": "results_discussion_draft_created", "status": NARRATIVE_OUT.exists(), "note": str(NARRATIVE_OUT)},
        {"gate": "limitations_document_created", "status": LIMIT_OUT.exists(), "note": str(LIMIT_OUT)},
        {"gate": "publication_zip_created", "status": ZIP_OUT.exists(), "note": str(ZIP_OUT)},
    ]
)
gates.to_csv(GATE_OUT, index=False)

c.write_json(
    META_OUT,
    {
        "stage": "6E",
        "publication_package": str(ZIP_OUT),
        "manifest": str(MANIFEST_OUT),
        "narrative": str(NARRATIVE_OUT),
        "abstract_notes": str(ABSTRACT_OUT),
        "limitations": str(LIMIT_OUT),
        "scientific_freeze": "Publication synthesis only; no retrospective retuning.",
    },
)

print("\nPHASE-6E GATE")
print(gates.to_string(index=False))

if not c.boolify(gates["status"]).all():
    raise RuntimeError("Phase 6E packaging gates failed.")

print("\nPASS: PHASE 6E FINAL PUBLICATION PACKAGE COMPLETE.")
print("Package:", ZIP_OUT)
