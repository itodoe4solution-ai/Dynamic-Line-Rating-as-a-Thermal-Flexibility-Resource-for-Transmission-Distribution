
from __future__ import annotations

"""PHASE 6D — PUBLICATION-READY TABLES."""

from pathlib import Path
import importlib.util
import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "36_phase6_common.py"
    spec = importlib.util.spec_from_file_location("phase6_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
R = ROOT / "09_simulation_inputs" / "results"
OUTDIR = c.ensure_dir(R / "phase6")
TDIR = c.ensure_dir(OUTDIR / "tables")
INDEX_OUT = OUTDIR / "phase6d_table_index.csv"
GATE_OUT = OUTDIR / "phase6d_gate_summary.csv"
META_OUT = OUTDIR / "phase6d_metadata.json"

p4e_primary = pd.read_csv(R / "phase4e_primary_statistics.csv")
p4e_feas = pd.read_csv(R / "phase4e_feasibility_statistics.csv")
p4e_abl = pd.read_csv(R / "phase4e_ablation_statistics.csv")
p5pub = pd.read_csv(R / "phase5e_publication_summary.csv")
p5f = pd.read_csv(R / "phase5f_voltage_control_summary.csv")
claims = pd.read_csv(OUTDIR / "phase6b_claim_evidence_matrix.csv")

table_records = []

def export(df: pd.DataFrame, stem: str, title: str, note: str):
    csv_path = TDIR / f"{stem}.csv"
    md_path = TDIR / f"{stem}.md"
    tex_path = TDIR / f"{stem}.tex"
    df.to_csv(csv_path, index=False)
    md_path.write_text(
        f"# {title}\n\n{df.to_markdown(index=False)}\n\n**Note.** {note}\n",
        encoding="utf-8",
    )
    tex_path.write_text(
        "% " + title + "\n"
        + df.to_latex(index=False, escape=True, float_format=lambda x: f"{x:.4f}")
        + "\n% Note: " + note + "\n",
        encoding="utf-8",
    )
    table_records.append(
        {
            "table_id": stem,
            "title": title,
            "note": note,
            "csv": str(csv_path),
            "markdown": str(md_path),
            "latex": str(tex_path),
        }
    )

# Table 1 — Phase-4 primary statistics
cols = [
    "stress_regime", "feeder_count", "mpc_horizon_h", "metric",
    "n_pairs", "n_windows", "window_equal_weight_mean_effect",
    "ci95_low_cluster_bootstrap", "ci95_high_cluster_bootstrap",
    "cluster_signflip_p_value", "effect_size_dz_window",
]
export(
    p4e_primary[[x for x in cols if x in p4e_primary.columns]].copy(),
    "Table06_01_phase4_primary_statistics",
    "Confirmatory Phase-4C paired STR–DLR statistics",
    "Continuous effects use both-strict-feasible pairs and window-level inference.",
)

# Table 2 — Feasibility
cols = [
    "analysis_source", "stress_regime", "feeder_count", "mpc_horizon_h",
    "n_pairs", "n_windows", "dlr_restores_feasibility_pairs",
    "str_only_feasible_pairs", "both_strict_feasible_pairs",
    "restoration_rate_window_equal",
    "restoration_ci95_low_cluster_bootstrap",
    "restoration_ci95_high_cluster_bootstrap",
    "feasibility_advantage_signflip_p",
]
export(
    p4e_feas[[x for x in cols if x in p4e_feas.columns]].copy(),
    "Table06_02_phase4_feasibility",
    "STR–DLR feasibility comparison",
    "Feasibility restoration is reported separately from continuous paired effects.",
)

# Table 3 — Ablation
cols = [
    "stress_regime", "feeder_count", "comparator_case", "ablation_label",
    "metric", "n_pairs", "n_windows", "window_equal_weight_mean_effect",
    "ci95_low_cluster_bootstrap", "ci95_high_cluster_bootstrap",
    "cluster_signflip_p_value", "effect_size_dz_window",
]
export(
    p4e_abl[[x for x in cols if x in p4e_abl.columns]].copy(),
    "Table06_03_phase4_ablation",
    "Phase-4D ablation statistics",
    "PV-absent sensitivity is not interpreted as a causal PV-coordination estimate.",
)

# Table 4 — Phase-5 AC validation
export(
    p5pub.copy(),
    "Table06_04_phase5_ac_validation",
    "AC, ACOPF, N-1, and IEEE-39 validation summary",
    "Process success is distinct from security-clean operation.",
)

# Table 5 — Phase-5F voltage control
cols = [
    "stress_regime", "case", "control_case", "evaluations",
    "ieee33_voltage_clean_evaluations", "ieee33_voltage_clean_fraction",
    "mean_ieee33_violating_feeders", "worst_ieee33_vmin_pu",
    "worst_ieee33_vmax_pu", "mean_selected_tap_pu",
    "mean_abs_q_support_mvar", "ieee118_acpf_converged",
    "ieee118_voltage_clean_fraction", "ieee118_thermal_clean_fraction",
    "mean_ieee118_max_corridor_loading_pu",
]
export(
    p5f[[x for x in cols if x in p5f.columns]].copy(),
    "Table06_05_phase5f_voltage_control",
    "Voltage-control sensitivity",
    "OLTC/Volt-VAR are sensitivity controls; Phase-4 active schedules remain frozen.",
)

# Table 6 — Claim-evidence matrix
export(
    claims.copy(),
    "Table06_06_claim_evidence_matrix",
    "Final claim–evidence matrix",
    "Each claim includes an explicit scope limit to prevent overstatement.",
)

index = pd.DataFrame(table_records)
index.to_csv(INDEX_OUT, index=False)

gates = pd.DataFrame(
    [
        {"gate": "six_core_publication_tables_created", "status": len(index) >= 6, "note": f"{len(index)} tables created."},
        {"gate": "all_tables_have_csv_markdown_latex", "status": True, "note": "Three export formats produced for every table."},
        {"gate": "claim_evidence_table_included", "status": index["table_id"].eq("Table06_06_claim_evidence_matrix").any(), "note": "Conservative claim mapping included."},
    ]
)
gates.to_csv(GATE_OUT, index=False)

c.write_json(
    META_OUT,
    {
        "stage": "6D",
        "table_count": len(index),
        "table_dir": str(TDIR),
        "index": str(INDEX_OUT),
    },
)

print("\nPHASE-6D TABLE INDEX")
print(index[["table_id", "title", "note"]].to_string(index=False))
print("\nPHASE-6D GATE")
print(gates.to_string(index=False))

if not c.boolify(gates["status"]).all():
    raise RuntimeError("Phase 6D table-generation gates failed.")

print("\nPASS: PHASE 6D PUBLICATION TABLES COMPLETE.")
