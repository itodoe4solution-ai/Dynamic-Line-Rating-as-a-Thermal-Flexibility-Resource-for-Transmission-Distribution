import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from epsr_pipeline.common import ROOT
from epsr_pipeline.ieee33 import write_opendss_model, write_reference_outputs

out=ROOT/'09_simulation_inputs/ieee33_opendss'
write_opendss_model(out)
summary=write_reference_outputs(out, ROOT/'05_quality_control')
print('IEEE-33 OpenDSS model written to:', out)
for k,v in summary.items():
    print(f'{k}: {v}')
