import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datetime import datetime, timezone

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.qc import timestamp_qc, missing_values_report, physical_sanity, weather_qc, dataset_summary
from epsr_pipeline.scenarios import classify_regimes, correlation_audit

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
m=pd.read_csv(ROOT/"04_master/master_dataset_working.csv",parse_dates=["timestamp_utc","timestamp_local"])
ts,missing=timestamp_qc(m,start,end,int(cfg["project"]["interval_minutes"])); ts.to_csv(ROOT/"05_quality_control/timestamp_report.csv",index=False); missing.to_csv(ROOT/"05_quality_control/missing_timestamps.csv",index=False)
missing_values_report(m).to_csv(ROOT/"05_quality_control/missing_values_report.csv",index=False)
physical_sanity(m,cfg).to_csv(ROOT/"05_quality_control/physical_sanity_report.csv",index=False)
weather_qc(m).to_csv(ROOT/"05_quality_control/weather_qc_report.csv",index=False)
dataset_summary(m).to_csv(ROOT/"05_quality_control/dataset_summary.csv",index=False)
classified,thr=classify_regimes(m); classified.to_csv(ROOT/"04_master/master_dataset_classified.csv",index=False); thr.to_csv(ROOT/"05_quality_control/regime_thresholds.csv",index=False)
corr=correlation_audit(classified); corr.to_csv(ROOT/"05_quality_control/correlation_spearman.csv")

# Update a reproducible source manifest with the selected study window.
manifest_path=ROOT/"00_documentation/data_sources.csv"
if manifest_path.exists():
    manifest=pd.read_csv(manifest_path).astype(object)
    def _latest_mtime_iso(paths: list[Path]) -> str:
        existing = [p for p in paths if p.exists()]
        if not existing:
            return ""
        mtime = max(p.stat().st_mtime for p in existing)
        return pd.Timestamp(datetime.fromtimestamp(mtime, tz=timezone.utc)).isoformat()

    def _first_station_row() -> dict:
        sel = ROOT/"05_quality_control/noaa_station_selected.csv"
        if sel.exists():
            return pd.read_csv(sel, dtype={"USAF":str, "WBAN":str}).iloc[0].to_dict()
        return {}

    station = _first_station_row()
    loc = cfg["location"]
    today_utc = pd.Timestamp.now(tz="UTC").isoformat()
    for i, row in manifest.iterrows():
        variable = str(row.get("variable", "")).strip().lower()
        manifest.loc[i, "start_date"] = start.isoformat()
        manifest.loc[i, "end_date"] = end.isoformat()
        if variable == "ev charging":
            manifest.loc[i, "location"] = loc["name"]
            manifest.loc[i, "latitude"] = float(loc["latitude"])
            manifest.loc[i, "longitude"] = float(loc["longitude"])
            manifest.loc[i, "original_resolution"] = "session timeseries"
            manifest.loc[i, "download_date"] = _latest_mtime_iso([ROOT/"01_raw/acn_ev/acn_sessions_timeseries.jsonl"])
            manifest.loc[i, "license"] = "ACN-Data terms"
        elif variable == "weather/solar":
            manifest.loc[i, "location"] = loc["name"]
            manifest.loc[i, "latitude"] = float(loc["latitude"])
            manifest.loc[i, "longitude"] = float(loc["longitude"])
            manifest.loc[i, "original_resolution"] = "5 min"
            manifest.loc[i, "download_date"] = _latest_mtime_iso(list((ROOT/"01_raw/nsrdb").glob("*.csv")))
            manifest.loc[i, "license"] = "NSRDB terms"
        elif variable == "weather validation":
            manifest.loc[i, "location"] = station.get("station_name", "Nearest suitable station")
            if "LAT" in station and pd.notna(station["LAT"]):
                manifest.loc[i, "latitude"] = float(station["LAT"])
            if "LON" in station and pd.notna(station["LON"]):
                manifest.loc[i, "longitude"] = float(station["LON"])
            manifest.loc[i, "original_resolution"] = "hourly"
            manifest.loc[i, "download_date"] = _latest_mtime_iso(list((ROOT/"01_raw/noaa").glob("*.gz")))
            manifest.loc[i, "license"] = "NOAA/NCEI data use terms"
        elif variable == "system demand":
            manifest.loc[i, "download_date"] = _latest_mtime_iso([ROOT/"01_raw/eia930/eia930_ciso_raw.csv"])
            manifest.loc[i, "original_resolution"] = "hourly"
            manifest.loc[i, "license"] = "EIA open data"
        elif variable == "pv":
            manifest.loc[i, "location"] = loc["name"]
            manifest.loc[i, "latitude"] = float(loc["latitude"])
            manifest.loc[i, "longitude"] = float(loc["longitude"])
            manifest.loc[i, "original_resolution"] = "15 min"
            manifest.loc[i, "download_date"] = _latest_mtime_iso([ROOT/"03_processed/pv_profile_physical_15min.csv"])
            manifest.loc[i, "license"] = "Derived by authors from NSRDB and pvlib"
        elif variable == "dlr":
            manifest.loc[i, "location"] = loc["name"]
            manifest.loc[i, "latitude"] = float(loc["latitude"])
            manifest.loc[i, "longitude"] = float(loc["longitude"])
            manifest.loc[i, "original_resolution"] = "15 min"
            manifest.loc[i, "download_date"] = _latest_mtime_iso([ROOT/"08_dlr/dlr_15min.csv"])
            manifest.loc[i, "license"] = "Derived by authors from NSRDB and IEEE-738-style model"
    manifest["download_date"] = manifest["download_date"].replace("", pd.NA).fillna(today_utc)
    manifest.to_csv(ROOT/"05_quality_control/source_manifest.csv",index=False)
print(ts.to_string(index=False)); print("\nPhysical sanity:\n",physical_sanity(m,cfg).to_string(index=False))
