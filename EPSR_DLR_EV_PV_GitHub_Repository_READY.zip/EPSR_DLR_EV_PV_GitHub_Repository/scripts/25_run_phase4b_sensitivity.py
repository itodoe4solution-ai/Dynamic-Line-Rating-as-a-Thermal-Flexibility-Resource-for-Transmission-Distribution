from __future__ import annotations

"""
Phase 4B — Predeclared stress/horizon sensitivity
==================================================

Runs the frozen STR-SMPC vs DLR-SMPC comparison over:
    feeder populations: 28 / 37 / 43
    MPC horizons:       2 / 4 / 8 hours
    frozen windows:     selected_periods.csv
    common seeds:       0..9

Full expected rows:
    3 populations x 3 horizons x N_windows x 10 seeds x 2 rating cases.
For 13 frozen windows this is 2340 rows.

IMPORTANT
---------
This Phase-4B script intentionally preserves the same block-execution semantics
as the existing Phase-4 primary engine so the sensitivity remains directly
comparable to the primary result. A true hourly receding-horizon implementation
should be introduced as a separate Phase-4C robustness/implementation upgrade,
not silently mixed into this sensitivity.

The script does NOT overwrite phase4_primary_results.csv.
"""

from pathlib import Path
import importlib.util
import math
import os
import time
import json

import numpy as np
import pandas as pd
from scipy.optimize import linprog

# -----------------------------------------------------------------------------
# Repository / primary-engine discovery
# -----------------------------------------------------------------------------

def _resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path.cwd(),
        Path(__file__).resolve().parent.parent,
        Path(__file__).resolve().parent,
    ])
    for p in candidates:
        p = p.resolve()
        if (
            (p / "04_master" / "master_dataset_classified.csv").exists()
            and (p / "06_scenarios" / "selected_periods.csv").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate EPSR repository root. Run from the repository root "
        "or set EPSR_ROOT to that folder."
    )


ROOT = _resolve_root()
PRIMARY_ENGINE = ROOT / "scripts" / "24_run_phase4_primary.py"
if not PRIMARY_ENGINE.exists():
    raise FileNotFoundError(
        f"Required Phase-4 primary engine not found: {PRIMARY_ENGINE}\n"
        "Copy 24_run_phase4_primary.py into ROOT/scripts first."
    )

spec = importlib.util.spec_from_file_location("phase4_primary_engine", PRIMARY_ENGINE)
if spec is None or spec.loader is None:
    raise RuntimeError("Could not import the Phase-4 primary engine.")
p4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p4)

OUTDIR = ROOT / "09_simulation_inputs" / "results"
OUTDIR.mkdir(parents=True, exist_ok=True)
OUT = OUTDIR / "phase4_sensitivity_results.csv"
SUMMARY_OUT = OUTDIR / "phase4_sensitivity_summary.csv"
PAIRED_OUT = OUTDIR / "phase4_sensitivity_paired_effects.csv"
META_OUT = OUTDIR / "phase4_sensitivity_metadata.json"

# -----------------------------------------------------------------------------
# Frozen sensitivity design
# -----------------------------------------------------------------------------
FEEDER_REGIMES = ["moderate", "nominal", "high"]
MPC_HORIZONS_H = [2, 4, 8]
COMMON_SEEDS = list(range(10))
CASES = ["STR-SMPC", "DLR-SMPC"]
MAX_H = max(MPC_HORIZONS_H)

# Optional smoke test: set PHASE4B_SMOKE_TEST=1 before execution.
SMOKE_TEST = os.environ.get("PHASE4B_SMOKE_TEST", "0").strip() == "1"

# Use the same penalties/security screen as the primary engine.
SCENARIO_COUNT = p4.SCENARIO_COUNT
VLOW, VHIGH = p4.VLOW, p4.VHIGH
BINDING_THRESHOLD = p4.BINDING_THRESHOLD
W_DUE = p4.W_DUE
W_CURTAIL = p4.W_CURTAIL
W_BACKLOG = p4.W_BACKLOG
W_RAMP = p4.W_RAMP
RNG_BASE = p4.RNG_BASE
CLASSES = p4.CLASSES
C = len(CLASSES)

# -----------------------------------------------------------------------------
# Verify / freeze feeder populations from Phase 2
# -----------------------------------------------------------------------------
pop = p4.pop.copy()
pop["stress_regime"] = pop["stress_regime"].astype(str).str.lower()

regime_rows = {}
for regime in FEEDER_REGIMES:
    z = pop[pop["stress_regime"] == regime]
    if len(z) != 1:
        raise RuntimeError(
            f"Expected exactly one Phase-2 feeder population row for {regime!r}; got {len(z)}."
        )
    r = z.iloc[0]
    counts = {c: int(r[f"class_{c}_count"]) for c in CLASSES}
    nfeed = int(r["recommended_integer_feeder_count"])
    if sum(counts.values()) != nfeed:
        raise RuntimeError(f"Class counts do not sum to feeder count for {regime}.")
    regime_rows[regime] = {
        "row": r,
        "counts": counts,
        "feeder_count": nfeed,
        "target_loading_pu": float(r["target_loading_pu"]),
        "predicted_loading_pu": float(r["predicted_loading_pu"]),
    }

expected_counts = {
    "moderate": 28,
    "nominal": 37,
    "high": 43,
}
for regime, n in expected_counts.items():
    if regime_rows[regime]["feeder_count"] != n:
        raise RuntimeError(
            f"Frozen Phase-2 {regime} population is {regime_rows[regime]['feeder_count']}, expected {n}."
        )

# -----------------------------------------------------------------------------
# Phase-3 forecast-family extension to sensitivity horizons
# -----------------------------------------------------------------------------
# Exact selected anchor families from Phase 3 are checked against the file.
sel = p4.phase3_selection.copy()
anchor = {
    (str(r.target), int(r.horizon_minutes // 60)): str(r.selected_model)
    for _, r in sel.iterrows()
    if int(r.horizon_minutes) in [60, 120, 240, 480]
}

expected_anchor = {
    ("ev_power_kw", 1): "hist_gradient_boosting_direct",
    ("ev_power_kw", 2): "historical_hour_of_week_mean",
    ("ev_power_kw", 4): "historical_hour_of_week_mean",
    ("ev_power_kw", 8): "historical_hour_of_week_mean",
    ("pv_ac_kw", 1): "hist_gradient_boosting_direct",
    ("pv_ac_kw", 2): "hist_gradient_boosting_direct",
    ("pv_ac_kw", 4): "hist_gradient_boosting_direct",
    ("pv_ac_kw", 8): "seasonal_persistence_24h",
}
for k, v in expected_anchor.items():
    if anchor.get(k) != v:
        raise RuntimeError(
            f"Phase-3 frozen model selection changed for {k}: "
            f"found {anchor.get(k)!r}, expected {v!r}."
        )

# Family used for non-anchor hours follows the nearest *longer* frozen anchor.
# This avoids giving the sensitivity an optimistic shorter-horizon family.
MODEL_TYPE = {
    "ev_power_kw": {
        1: "hist_gradient_boosting_direct",
        2: "historical_hour_of_week_mean",
        3: "historical_hour_of_week_mean",   # inherits 4h anchor
        4: "historical_hour_of_week_mean",
        5: "historical_hour_of_week_mean",   # inherits 8h anchor
        6: "historical_hour_of_week_mean",
        7: "historical_hour_of_week_mean",
    },
    "pv_ac_kw": {
        1: "hist_gradient_boosting_direct",
        2: "hist_gradient_boosting_direct",
        3: "hist_gradient_boosting_direct",  # inherits 4h anchor
        4: "hist_gradient_boosting_direct",
        5: "seasonal_persistence_24h",       # inherits 8h anchor
        6: "seasonal_persistence_24h",
        7: "seasonal_persistence_24h",
    },
}

# Reuse already-trained primary forecasts where possible, then extend to h=5..7.
forecast = {
    t: {h: np.asarray(v, dtype=float).copy() for h, v in p4.forecast[t].items()}
    for t in ["ev_power_kw", "pv_ac_kw"]
}
resid_pool = {
    t: {h: np.asarray(v, dtype=float).copy() for h, v in p4.resid_pool[t].items()}
    for t in ["ev_power_kw", "pv_ac_kw"]
}

hourly = p4.hourly

def _build_forecast_for_h(target: str, h: int):
    y = pd.to_numeric(hourly[target], errors="coerce")
    if target == "ev_power_kw":
        support = np.asarray(hourly.timestamp_utc <= p4.ev_support_end_ts)
    else:
        support = np.ones(len(hourly), dtype=bool)

    n = int(np.where(support)[0][-1] + 1)
    tr = int(n * 0.70)
    ve = int(n * 0.85)
    se = tr + (ve - tr) // 2
    fit_mask = (np.arange(len(hourly)) < se) & support
    cal_mask = (
        (np.arange(len(hourly)) >= se)
        & (np.arange(len(hourly)) < ve)
        & support
    )

    model_type = MODEL_TYPE[target][h]
    if model_type == "historical_hour_of_week_mean":
        pred = p4.historical_how(y, fit_mask)
    elif model_type == "seasonal_persistence_24h":
        pred = y.shift(24).to_numpy(dtype=float)
    elif model_type == "hist_gradient_boosting_direct":
        X = p4.hourly_features(target, h)
        valid = X.notna().all(axis=1).to_numpy()
        idx = np.where(fit_mask & y.notna().to_numpy() & valid)[0]
        model = p4.hgb()
        model.fit(X.iloc[idx], y.iloc[idx])
        pred = np.full(len(hourly), np.nan)
        pred[valid] = model.predict(X.loc[valid])
    else:
        raise ValueError(model_type)

    pred = np.maximum(pred, 0.0)
    if target == "ev_power_kw":
        pred[~support] = 0.0

    good = cal_mask & np.isfinite(y.to_numpy()) & np.isfinite(pred)
    resid = (y.to_numpy() - pred)[good]
    resid = resid[np.isfinite(resid)]
    return pred, resid


for target in ["ev_power_kw", "pv_ac_kw"]:
    for h in range(1, MAX_H):
        # Rebuild whenever the required sensitivity family differs from the
        # family used by the primary engine, or the horizon was absent.
        primary_type = p4.MODEL_TYPE.get(target, {}).get(h)
        if h not in forecast[target] or primary_type != MODEL_TYPE[target][h]:
            forecast[target][h], resid_pool[target][h] = _build_forecast_for_h(target, h)

# -----------------------------------------------------------------------------
# Dynamic LP indexing for each horizon
# -----------------------------------------------------------------------------
def make_lp_index(H: int):
    nch = C * H
    nvar = 4 * nch

    def vid(block: str, ci: int, k: int) -> int:
        b = {"x": 0, "cur": 1, "slack": 2, "ramp": 3}[block]
        return b * nch + ci * H + k

    return nch, nvar, vid


def add_ub(A, b, nvar: int, coef: dict[int, float], rhs: float):
    row = np.zeros(nvar, dtype=float)
    for j, v in coef.items():
        row[j] += v
    A.append(row)
    b.append(float(rhs))

# -----------------------------------------------------------------------------
# Horizon-specific stochastic forecast scenarios
# -----------------------------------------------------------------------------
def scenario_forecasts_h(origin_i: int, seed: int, H: int):
    """Current hour observed; future k=1..H-1 sampled from calibration residuals."""
    rng = np.random.default_rng(seed)
    ev_s = np.zeros((SCENARIO_COUNT, H), dtype=float)
    pv_s = np.zeros((SCENARIO_COUNT, H), dtype=float)

    ev_now = float(hourly.loc[origin_i, "ev_power_kw"]) if origin_i < len(hourly) else 0.0
    pv_now = float(hourly.loc[origin_i, "pv_ac_kw"]) if origin_i < len(hourly) else 0.0
    ev_s[:, 0] = max(0.0, ev_now)
    pv_s[:, 0] = max(0.0, pv_now)

    for k in range(1, H):
        ti = origin_i + k
        if ti >= len(hourly):
            ev_hat = 0.0
            pv_hat = 0.0
        else:
            ev_hat = float(forecast["ev_power_kw"][k][ti])
            pv_hat = float(forecast["pv_ac_kw"][k][ti])

        er = resid_pool["ev_power_kw"][k]
        pr = resid_pool["pv_ac_kw"][k]
        ev_err = (
            rng.choice(er, size=SCENARIO_COUNT, replace=True)
            if len(er) else np.zeros(SCENARIO_COUNT)
        )
        pv_err = (
            rng.choice(pr, size=SCENARIO_COUNT, replace=True)
            if len(pr) else np.zeros(SCENARIO_COUNT)
        )
        ev_s[:, k] = np.maximum(0.0, ev_hat + ev_err)
        pv_s[:, k] = np.maximum(0.0, pv_hat + pv_err)

    return ev_s, pv_s

# -----------------------------------------------------------------------------
# One sensitivity run
# -----------------------------------------------------------------------------
def run_case_sensitivity(window_row, seed: int, case: str, regime: str, H: int):
    if regime not in regime_rows:
        raise ValueError(regime)
    if H not in MPC_HORIZONS_H:
        raise ValueError(H)

    reg = regime_rows[regime]
    counts = reg["counts"]
    feeder_count = reg["feeder_count"]

    start = pd.Timestamp(window_row.start_utc)
    end = pd.Timestamp(window_row.end_utc_exclusive)
    win = hourly[
        (hourly.timestamp_utc >= start)
        & (hourly.timestamp_utc < end)
    ].copy().reset_index(drop=True)

    if len(win) != 168:
        raise RuntimeError(
            f"{window_row.scenario}: expected 168 hourly rows, got {len(win)}"
        )

    _, NVAR, vid = make_lp_index(H)

    queues = {c: {} for c in CLASSES}
    prev_x = {c: 0.0 for c in CLASSES}

    unserved = 0.0
    required_due = 0.0
    curtail_total = 0.0
    pcc_energy = 0.0
    ramp_total = 0.0
    solver_time = 0.0
    solver_fail = 0
    all_loadings = []
    binding_hours = 0
    thermal_viol = 0
    voltage_viol = 0

    # Precompute only energy whose empirical deadline remains inside the frozen week.
    for j, row in win.iterrows():
        for c in CLASSES:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if row.timestamp_utc > p4.ev_support_end_ts:
                arr = 0.0
            for d, prob in p4.DURATION_PROB[c].items():
                if j + d <= len(win) - 1:
                    required_due += arr * prob * counts[c]

    # IMPORTANT: block execution intentionally matches Phase-4 primary semantics.
    for block_start in range(0, len(win), H):
        row0 = win.iloc[block_start]
        ts0 = row0.timestamp_utc
        gi0 = p4.h_index[ts0]

        # Add current-hour arrivals before optimization.
        for c in CLASSES:
            arr = float(row0.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if ts0 > p4.ev_support_end_ts:
                arr = 0.0
            if arr > 0:
                p4.add_energy_arrival(queues[c], block_start, arr, c)

        ev_s, pv_s = scenario_forecasts_h(
            gi0,
            RNG_BASE + seed * 100000 + block_start * 97,
            H,
        )
        ev_med = np.quantile(ev_s, 0.50, axis=0)
        ev_hi = np.quantile(ev_s, 0.90, axis=0)
        pv_lo = np.quantile(pv_s, 0.10, axis=0)
        pv_hi = np.quantile(pv_s, 0.90, axis=0)

        A, b = [], []
        cobj = np.zeros(NVAR, dtype=float)
        bounds_lp = []

        for ci, c in enumerate(CLASSES):
            for k in range(H):
                cobj[vid("x", ci, k)] = -W_BACKLOG * counts[c]
                cobj[vid("cur", ci, k)] = W_CURTAIL * counts[c]
                cobj[vid("slack", ci, k)] = W_DUE * counts[c]
                cobj[vid("ramp", ci, k)] = W_RAMP * counts[c]

        for block in ["x", "cur", "slack", "ramp"]:
            for ci, c in enumerate(CLASSES):
                for k in range(H):
                    if block == "x":
                        ub = p4.pmax_mw[c]
                    elif block == "cur":
                        ub = max(0.0, pv_hi[k] * p4.pv_scale[c] / 1000.0)
                    else:
                        ub = None
                    bounds_lp.append((0, ub))

        # EV availability, deadline, and ramp constraints.
        for ci, c in enumerate(CLASSES):
            B0 = p4.queue_energy(queues[c])
            qlist = list(queues[c].items())

            for k in range(H):
                avail = B0
                for jj in range(1, k + 1):
                    avail += max(0.0, ev_med[jj]) * p4.ev_scale[c] / 1000.0

                add_ub(
                    A, b, NVAR,
                    {vid("x", ci, jj): 1.0 for jj in range(k + 1)},
                    avail,
                )

                due = sum(
                    amt for due_t, amt in qlist
                    if due_t <= block_start + k
                )
                for jj in range(1, k + 1):
                    future_arr = max(0.0, ev_hi[jj]) * p4.ev_scale[c] / 1000.0
                    for d, prob in p4.DURATION_PROB[c].items():
                        if block_start + jj + d <= block_start + k:
                            due += future_arr * prob

                coef = {vid("x", ci, jj): -1.0 for jj in range(k + 1)}
                coef[vid("slack", ci, k)] = -1.0
                add_ub(A, b, NVAR, coef, -due)

                if k == 0:
                    add_ub(
                        A, b, NVAR,
                        {vid("x", ci, k): 1.0, vid("ramp", ci, k): -1.0},
                        prev_x[c],
                    )
                    add_ub(
                        A, b, NVAR,
                        {vid("x", ci, k): -1.0, vid("ramp", ci, k): -1.0},
                        -prev_x[c],
                    )
                else:
                    add_ub(
                        A, b, NVAR,
                        {
                            vid("x", ci, k): 1.0,
                            vid("x", ci, k - 1): -1.0,
                            vid("ramp", ci, k): -1.0,
                        },
                        0,
                    )
                    add_ub(
                        A, b, NVAR,
                        {
                            vid("x", ci, k): -1.0,
                            vid("x", ci, k - 1): 1.0,
                            vid("ramp", ci, k): -1.0,
                        },
                        0,
                    )

        # Reduced-order feeder voltage and transmission corridor constraints.
        for k in range(H):
            ti = min(gi0 + k, len(hourly) - 1)
            future_ts = hourly.loc[ti, "timestamp_utc"]
            lf = float(hourly.loc[ti, "load_forecast_mw"])
            native_lo_factor = max(0.0, (lf + p4.load_q10) / p4.annual_system_max)
            native_hi_factor = max(0.0, (lf + p4.load_q90) / p4.annual_system_max)
            native_lo = 3.715 * native_lo_factor
            native_hi = 3.715 * native_hi_factor

            for ci, c in enumerate(CLASSES):
                pmin, _ = p4.voltage_bounds(native_lo_factor)
                _, pmaxv = p4.voltage_bounds(native_hi_factor)
                pvlow = max(0.0, pv_lo[k]) * p4.pv_scale[c] / 1000.0
                pvhigh = max(0.0, pv_hi[k]) * p4.pv_scale[c] / 1000.0

                add_ub(
                    A, b, NVAR,
                    {vid("x", ci, k): 1.0, vid("cur", ci, k): 1.0},
                    pmaxv - native_hi + pvlow,
                )
                add_ub(
                    A, b, NVAR,
                    {vid("x", ci, k): -1.0, vid("cur", ci, k): -1.0},
                    native_lo - pvhigh - pmin,
                )

            const_hi = 0.0
            const_lo = 0.0
            coeff = {}
            for ci, c in enumerate(CLASSES):
                n = counts[c]
                pvlow = max(0.0, pv_lo[k]) * p4.pv_scale[c] / 1000.0
                pvhigh = max(0.0, pv_hi[k]) * p4.pv_scale[c] / 1000.0
                const_hi += n * (native_hi - pvlow)
                const_lo += n * (native_lo - pvhigh)
                coeff[vid("x", ci, k)] = coeff.get(vid("x", ci, k), 0.0) + n
                coeff[vid("cur", ci, k)] = coeff.get(vid("cur", ci, k), 0.0) + n

            for cor in p4.corridors:
                rr = p4.rating_lookup[cor["cid"]]
                rating_col = "str_mva" if case == "STR-SMPC" else "dlr_mva"
                rating = float(rr.loc[future_ts, rating_col])
                base = cor["base"]
                ptdf = cor["ptdf"]

                coef_hi = {j: (-ptdf) * v for j, v in coeff.items()}
                add_ub(A, b, NVAR, coef_hi, rating - base + ptdf * const_hi)
                add_ub(A, b, NVAR, coef_hi, rating - base + ptdf * const_lo)

                coef_lo = {j: ptdf * v for j, v in coeff.items()}
                add_ub(A, b, NVAR, coef_lo, rating + base - ptdf * const_hi)
                add_ub(A, b, NVAR, coef_lo, rating + base - ptdf * const_lo)

        t0 = time.perf_counter()
        res = linprog(
            cobj,
            A_ub=np.asarray(A),
            b_ub=np.asarray(b),
            bounds=bounds_lp,
            method="highs",
        )
        solver_time += time.perf_counter() - t0

        if not res.success:
            solver_fail += 1
            plan_x = np.zeros((C, H), dtype=float)
            plan_cur = np.zeros((C, H), dtype=float)
        else:
            plan_x = np.array([
                [res.x[vid("x", ci, k)] for k in range(H)]
                for ci in range(C)
            ])
            plan_cur = np.array([
                [res.x[vid("cur", ci, k)] for k in range(H)]
                for ci in range(C)
            ])

        # Execute the full block exactly as in the primary Phase-4 engine.
        for k in range(H):
            local_t = block_start + k
            if local_t >= len(win):
                break

            row = win.iloc[local_t]
            ts = row.timestamp_utc

            if k > 0:
                for c in CLASSES:
                    arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
                    if ts > p4.ev_support_end_ts:
                        arr = 0.0
                    if arr > 0:
                        p4.add_energy_arrival(queues[c], local_t, arr, c)

            actual_factor = float(row.system_load_mw) / p4.annual_system_max
            native_actual = 3.715 * actual_factor
            pcc = 0.0
            hour_vviol = 0

            for ci, c in enumerate(CLASSES):
                actual_pv = max(0.0, float(row.pv_ac_kw) * p4.pv_scale[c] / 1000.0)
                cur = min(float(plan_cur[ci, k]), actual_pv)
                avail = p4.queue_energy(queues[c])
                x = min(float(plan_x[ci, k]), p4.pmax_mw[c], avail)
                x = p4.serve_fifo(queues[c], x)
                lost = p4.expire_due(queues[c], local_t)

                unserved += lost * counts[c]
                curtail_total += cur * counts[c]
                ramp_total += abs(x - prev_x[c]) * counts[c]
                prev_x[c] = x

                net = native_actual + x - (actual_pv - cur)
                pcc += counts[c] * net

                pmin, pmaxv = p4.voltage_bounds(actual_factor)
                if net < pmin - 1e-6 or net > pmaxv + 1e-6:
                    hour_vviol += counts[c]

            voltage_viol += hour_vviol
            pcc_energy += pcc

            hour_binding = False
            for cor in p4.corridors:
                rr = p4.rating_lookup[cor["cid"]]
                rating_col = "str_mva" if case == "STR-SMPC" else "dlr_mva"
                rating = float(rr.loc[ts, rating_col])
                flow = cor["base"] - cor["ptdf"] * pcc
                loading = abs(flow) / rating
                all_loadings.append(loading)
                if loading >= BINDING_THRESHOLD:
                    hour_binding = True
                if loading > 1.000001:
                    thermal_viol += 1

            if hour_binding:
                binding_hours += 1

    last = len(win) - 1
    for c in CLASSES:
        unserved += p4.expire_due(queues[c], last) * counts[c]

    service_ratio = (
        1.0
        if required_due <= 1e-12
        else max(0.0, 1.0 - unserved / required_due)
    )
    cost = W_DUE * unserved + W_CURTAIL * curtail_total + W_RAMP * ramp_total
    ev_support_fraction = float(np.mean(win.timestamp_utc <= p4.ev_support_end_ts))

    return {
        "network": f"IEEE118+{feeder_count}xIEEE33",
        "window_id": window_row.scenario,
        "seed": seed,
        "case": case,
        "rating_policy": "STR" if case == "STR-SMPC" else "DLR",
        "ev_unserved_mwh": unserved,
        "ev_service_ratio": service_ratio,
        "pv_curtailment_mwh": curtail_total,
        "pcc_energy_mwh": pcc_energy,
        "mean_loading_pu": float(np.mean(all_loadings)),
        "max_loading_pu": float(np.max(all_loadings)),
        "binding_hours": int(binding_hours),
        "voltage_violation_count": int(voltage_viol),
        "thermal_violation_count": int(thermal_viol),
        "cost": float(cost),
        "solve_time_s": float(solver_time),
        "stress_regime": regime,
        "target_loading_pu": reg["target_loading_pu"],
        "phase2_predicted_loading_pu": reg["predicted_loading_pu"],
        "feeder_count": feeder_count,
        "class_A_count": counts["A"],
        "class_B_count": counts["B"],
        "class_C_count": counts["C"],
        "class_D_count": counts["D"],
        "class_E_count": counts["E"],
        "required_ev_due_mwh": float(required_due),
        "served_ev_due_mwh": float(max(0.0, required_due - unserved)),
        "pcc_bus": 78,
        "slack_bus": 69,
        "critical_branch_id": 121,
        "mpc_horizon_h": H,
        "control_interval_h": H,
        "execution_semantics": "block execution matched to Phase-4 primary; hourly receding-horizon upgrade is Phase 4C",
        "scenario_count": SCENARIO_COUNT,
        "ev_deadline_model": "aggregate reconstructed charging-energy arrivals split by empirical 2019 ACN class-specific connection-duration deadline distribution (1-12 h)",
        "uncertainty_method": "empirical calibration-residual bootstrap from frozen Phase-3 selected model families; 10/50/90 scenario quantiles",
        "rating_forecast_assumption": "short-horizon STR/DLR rating chronology treated as known; DLR weather-forecast uncertainty deferred",
        "voltage_limit_low_pu": VLOW,
        "voltage_limit_high_pu": VHIGH,
        "voltage_check_method": "IEEE-33 balanced BFS-derived reduced-order active-power envelope; Phase-5 AC check pending",
        "ev_support_fraction": ev_support_fraction,
        "solver_fail_count": solver_fail,
        "cost_units": "penalty units = 1e6*unserved_MWh + 1e3*curtail_MWh + 0.1*ramp_MW",
        "phase4b_status": "predeclared feeder-stress and horizon sensitivity; final AC/N-1 confirmation deferred to Phase 5",
    }

# -----------------------------------------------------------------------------
# Paired effects and QA
# -----------------------------------------------------------------------------
def build_paired_effects(df: pd.DataFrame) -> pd.DataFrame:
    keys = ["stress_regime", "feeder_count", "mpc_horizon_h", "network", "window_id", "seed"]
    metrics = [
        "ev_unserved_mwh",
        "ev_service_ratio",
        "pv_curtailment_mwh",
        "mean_loading_pu",
        "max_loading_pu",
        "binding_hours",
        "thermal_violation_count",
        "voltage_violation_count",
        "cost",
    ]
    out = None
    for metric in metrics:
        p = (
            df.pivot_table(index=keys, columns="case", values=metric, aggfunc="first")
            .dropna()
            .reset_index()
        )
        if "STR-SMPC" not in p.columns or "DLR-SMPC" not in p.columns:
            raise RuntimeError(f"Missing paired cases for {metric}")
        p[f"{metric}__DLR_minus_STR"] = p["DLR-SMPC"] - p["STR-SMPC"]
        keep = keys + [f"{metric}__DLR_minus_STR"]
        out = p[keep] if out is None else out.merge(p[keep], on=keys, how="inner")
    return out


def main():
    start_all = time.perf_counter()

    periods = p4.periods.copy()
    seeds = COMMON_SEEDS.copy()
    regimes = FEEDER_REGIMES.copy()
    horizons = MPC_HORIZONS_H.copy()

    if SMOKE_TEST:
        periods = periods.iloc[:1].copy()
        seeds = [0]
        regimes = ["nominal"]
        horizons = [4]
        print("PHASE4B_SMOKE_TEST=1: running only 1 window x 1 seed x nominal x 4h x 2 cases")

    jobs = []
    for regime in regimes:
        for H in horizons:
            for _, w in periods.iterrows():
                for seed in seeds:
                    for case in CASES:
                        jobs.append((w, seed, case, regime, H))

    print("EPSR ROOT:", ROOT)
    print("Phase-4B output:", OUT)
    print(
        f"Phase-4B jobs: {len(jobs)} = {len(regimes)} regimes x {len(horizons)} horizons "
        f"x {len(periods)} windows x {len(seeds)} seeds x 2 rating policies"
    )

    rows = []
    for i, args in enumerate(jobs, 1):
        rows.append(run_case_sensitivity(*args))
        if i % 20 == 0 or i == len(jobs):
            print(f"completed {i}/{len(jobs)}", flush=True)

    df = pd.DataFrame(rows)

    required = [
        "network", "window_id", "seed", "case", "rating_policy",
        "ev_unserved_mwh", "ev_service_ratio",
        "pv_curtailment_mwh", "pcc_energy_mwh",
        "mean_loading_pu", "max_loading_pu", "binding_hours",
        "voltage_violation_count", "thermal_violation_count",
        "cost", "solve_time_s",
        "stress_regime", "feeder_count", "mpc_horizon_h",
    ]

    df = df[required + [c for c in df.columns if c not in required]]
    df = df.sort_values(
        ["stress_regime", "feeder_count", "mpc_horizon_h", "window_id", "seed", "case"]
    ).reset_index(drop=True)

    # QA checks.
    expected_rows = len(regimes) * len(horizons) * len(periods) * len(seeds) * 2
    assert len(df) == expected_rows
    assert not df[required].isna().any().any()
    assert set(df["case"]) == {"STR-SMPC", "DLR-SMPC"}
    assert df["ev_service_ratio"].between(0, 1).all()
    assert (df[["ev_unserved_mwh", "pv_curtailment_mwh", "solve_time_s"]] >= 0).all().all()

    pair_keys = ["stress_regime", "feeder_count", "mpc_horizon_h", "window_id", "seed"]
    pair_sizes = df.groupby(pair_keys).size()
    assert pair_sizes.eq(2).all(), "Incomplete STR/DLR pairs detected."

    if not SMOKE_TEST:
        assert set(df["feeder_count"]) == {28, 37, 43}
        assert set(df["mpc_horizon_h"]) == {2, 4, 8}
        assert len(df) == len(p4.periods) * 10 * 2 * 3 * 3

    df.to_csv(OUT, index=False)

    summary = (
        df.groupby(["stress_regime", "feeder_count", "mpc_horizon_h", "case"])
        .agg(
            runs=("case", "size"),
            mean_ev_unserved_mwh=("ev_unserved_mwh", "mean"),
            mean_ev_service_ratio=("ev_service_ratio", "mean"),
            mean_pv_curtailment_mwh=("pv_curtailment_mwh", "mean"),
            mean_pcc_energy_mwh=("pcc_energy_mwh", "mean"),
            mean_loading_pu=("mean_loading_pu", "mean"),
            mean_max_loading_pu=("max_loading_pu", "mean"),
            total_binding_hours=("binding_hours", "sum"),
            thermal_violations=("thermal_violation_count", "sum"),
            voltage_violations=("voltage_violation_count", "sum"),
            solver_failures=("solver_fail_count", "sum"),
            solve_time_s=("solve_time_s", "sum"),
        )
        .reset_index()
    )
    summary.to_csv(SUMMARY_OUT, index=False)

    paired = build_paired_effects(df)
    paired.to_csv(PAIRED_OUT, index=False)

    runtime = time.perf_counter() - start_all
    meta = {
        "rows": int(len(df)),
        "windows": int(len(periods)),
        "seeds": seeds,
        "feeder_regimes": regimes,
        "feeder_counts": [regime_rows[r]["feeder_count"] for r in regimes],
        "mpc_horizons_h": horizons,
        "rating_cases": CASES,
        "scenario_count": SCENARIO_COUNT,
        "runtime_s": runtime,
        "smoke_test": SMOKE_TEST,
        "output": str(OUT),
        "summary_output": str(SUMMARY_OUT),
        "paired_output": str(PAIRED_OUT),
        "execution_semantics": "same block-execution SMPC semantics as Phase-4 primary for direct sensitivity comparability",
        "scientific_note": "28/37/43 feeder populations and 2/4/8 h horizons were predeclared before examining Phase-4B outcomes; no outcome-based population tuning is performed.",
    }
    META_OUT.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nPASS: Phase-4B sensitivity result contract generated.")
    print("Saved:", OUT)
    print("Rows:", len(df))
    print("Solver failures:", int(df["solver_fail_count"].sum()))
    print("\nSUMMARY")
    print(summary.to_string(index=False))
    print("\nPAIRED EV UNSERVED ENERGY (DLR - STR)")
    print(
        paired.groupby(["stress_regime", "feeder_count", "mpc_horizon_h"])
        ["ev_unserved_mwh__DLR_minus_STR"]
        .agg(["count", "mean", "std", "min", "median", "max"])
        .to_string()
    )
    print("runtime_s", runtime)
    return df


if __name__ == "__main__":
    main()
