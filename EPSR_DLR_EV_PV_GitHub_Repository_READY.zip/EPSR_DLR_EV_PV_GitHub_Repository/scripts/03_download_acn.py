import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.acn import download_sessions, sessions_jsonl_to_metadata_csv

ensure_directories()
cfg=load_config(); start,end=require_study_period(cfg); a=cfg["acn"]
# Rebuild the 2019 raw cache from scratch so old fallback records do not linger.
download_start = start - pd.Timedelta(hours=48)
out_jsonl=ROOT / "01_raw/acn_ev/acn_sessions_timeseries.jsonl"
n=download_sessions(
    site=a["site_id"], start=download_start, end=end, out_jsonl=out_jsonl,
    min_energy_kwh=float(a.get("min_energy_kwh",0.0)),
    timeseries=bool(a.get("timeseries",True)),
    polite_sleep_seconds=float(a.get("polite_sleep_seconds",0.05)),
    chunk_days=int(a.get("download_chunk_days",1)),
    parallel_workers=int(a.get("download_parallel_workers",8)),
    replace_existing=True,
)
meta=sessions_jsonl_to_metadata_csv(out_jsonl, ROOT / "01_raw/acn_ev/acn_sessions_metadata.csv")
coverage = pd.DataFrame([{
    "total_sessions": int(len(meta)),
    "with_charging_current_timeseries": int(meta["has_charging_current_timeseries"].sum()) if "has_charging_current_timeseries" in meta else 0,
    "with_pilot_signal_timeseries": int(meta["has_pilot_signal_timeseries"].sum()) if "has_pilot_signal_timeseries" in meta else 0,
}])
coverage["charging_current_fraction"] = coverage["with_charging_current_timeseries"] / coverage["total_sessions"]
coverage["pilot_signal_fraction"] = coverage["with_pilot_signal_timeseries"] / coverage["total_sessions"]
coverage.to_csv(ROOT/"05_quality_control/acn_timeseries_coverage.csv", index=False)
print(f"ACN download complete. Sessions added: {n}; total cached: {len(meta)}")
print(coverage.to_string(index=False))
