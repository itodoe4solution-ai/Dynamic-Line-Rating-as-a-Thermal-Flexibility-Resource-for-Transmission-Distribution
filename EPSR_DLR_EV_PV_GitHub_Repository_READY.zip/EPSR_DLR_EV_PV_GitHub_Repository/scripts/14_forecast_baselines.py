import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, ensure_directories
from epsr_pipeline.forecast import chronological_split, benchmark_series, conformal_interval_from_validation, interval_coverage

ensure_directories(); cfg=load_config(); fc=cfg["forecast"]
m=pd.read_csv(ROOT/"04_master/master_dataset_classified.csv",parse_dates=["timestamp_utc"])
all_metrics=[]
for target in [c for c in ["ev_power_kw","pv_ac_kw"] if c in m]:
    pred,metrics=benchmark_series(m,target,int(fc.get("seasonal_lag_steps",96)))
    pred.to_csv(ROOT/f"07_forecasts/{target}_baseline_predictions.csv",index=False)
    metrics.to_csv(ROOT/f"07_forecasts/{target}_baseline_metrics_all.csv",index=False)
    all_metrics.append(metrics)

    train,val,test=chronological_split(pred,float(fc["train_fraction"]),float(fc["validation_fraction"]))
    # Use the best validation baseline by RMSE, then split-conformal residual calibration.
    candidates=["persistence","seasonal_persistence","historical_hour_of_week_mean"]
    val_scores=[]
    from epsr_pipeline.forecast import metrics as metric_fn
    for c in candidates:
        val_scores.append((metric_fn(val[target],val[c])["rmse"],c))
    val_scores=[x for x in val_scores if pd.notna(x[0])]
    if val_scores:
        _,best=min(val_scores)
        lo,hi,q=conformal_interval_from_validation(val[target],val[best],test[best],float(fc.get("nominal_coverage",.9)))
        cov=interval_coverage(test[target],lo,hi)
        pd.DataFrame([{ "target":target,"selected_baseline":best,"conformal_abs_residual_quantile":q,"nominal_coverage":float(fc.get("nominal_coverage",.9)),**cov}]).to_csv(ROOT/f"07_forecasts/{target}_conformal_coverage.csv",index=False)
if all_metrics:
    pd.concat(all_metrics,ignore_index=True).to_csv(ROOT/"07_forecasts/baseline_model_comparison.csv",index=False)
print("Forecast baseline and conformal calibration reports written to 07_forecasts/.")
