import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.nsrdb import read_nsrdb_csv, aggregate_to_15min
from epsr_pipeline.noaa import read_isd_lite_gz, validate_against_nsrdb

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg); n=cfg["nsrdb"]
frames=[]
for year in range(start.year, (end - pd.Timedelta(nanoseconds=1)).year + 1):
    p=ROOT/f"01_raw/nsrdb/nsrdb_goes_conus_{year}_{n['interval_minutes']}min.csv"
    frames.append(read_nsrdb_csv(p))
weather5=pd.concat(frames,ignore_index=True).sort_values("timestamp_utc")
weather5=weather5[(weather5.timestamp_utc>=start)&(weather5.timestamp_utc<end)]
weather5.to_csv(ROOT/"02_cleaned/nsrdb_5min_clean.csv",index=False)
w15=aggregate_to_15min(weather5)
w15=w15[(w15.timestamp_utc>=start)&(w15.timestamp_utc<end)]
w15.to_csv(ROOT/"03_processed/weather_solar_15min.csv",index=False)

sel=ROOT/"05_quality_control/noaa_station_selected.csv"
if sel.exists():
    s=pd.read_csv(sel,dtype={"USAF":str,"WBAN":str}).iloc[0]
    noaa=[]
    for year in range(start.year, (end - pd.Timedelta(nanoseconds=1)).year + 1):
        p=ROOT/f"01_raw/noaa/{str(s['USAF']).zfill(6)}-{str(s['WBAN']).zfill(5)}-{year}.gz"
        noaa.append(read_isd_lite_gz(p))
    nh=pd.concat(noaa,ignore_index=True)
    nh=nh[(nh.timestamp_utc>=start)&(nh.timestamp_utc<end)]
    nh.to_csv(ROOT/"02_cleaned/noaa_hourly_validation.csv",index=False)
    report=validate_against_nsrdb(w15,nh)
    report.to_csv(ROOT/"05_quality_control/weather_validation_report.csv",index=False)
    print(report.to_string(index=False))
print(f"NSRDB 5-min rows: {len(weather5)}; 15-min rows: {len(w15)}")
