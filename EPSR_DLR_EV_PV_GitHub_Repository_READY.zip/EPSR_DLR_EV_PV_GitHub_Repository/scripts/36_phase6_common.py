
from __future__ import annotations

"""
PHASE 6 COMMON UTILITIES
========================
Shared utilities for the final publication-synthesis workflow.

Scientific boundary
-------------------
Phase 6 does not retune or rerun Phase 4/5 controls. It audits, consolidates,
visualizes, tabulates, and packages the already-frozen evidence.
"""

from pathlib import Path
import hashlib
import json
import math
import os
from typing import Any

import numpy as np
import pandas as pd


def resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([Path.cwd(), Path(__file__).resolve().parent.parent])
    for p in candidates:
        p = p.resolve()
        if (
            (p / "09_simulation_inputs" / "results").exists()
            and (p / "scripts").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate EPSR project root. Set EPSR_ROOT or run from the project root."
    )


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def boolify(s: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)
    if pd.api.types.is_numeric_dtype(s):
        return s.fillna(0).astype(float).ne(0)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .map(
            {
                "true": True, "false": False,
                "1": True, "0": False,
                "yes": True, "no": False,
                "pass": True, "fail": False,
            }
        )
        .fillna(False)
        .astype(bool)
    )


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv_required(path: Path, required_cols: list[str] | None = None) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(str(path))
    df = pd.read_csv(path)
    if required_cols:
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            raise KeyError(
                f"{path.name} missing required columns: {missing}\n"
                f"Available columns: {list(df.columns)}"
            )
    return df


def safe_numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")


def write_json(path: Path, obj: Any):
    path.write_text(
        json.dumps(obj, indent=2, default=str),
        encoding="utf-8",
    )


def flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        out.columns = [
            "_".join([str(x) for x in tup if str(x) not in ("", "None")])
            for tup in out.columns
        ]
    return out


def percent(x: float) -> float:
    return float(x) * 100.0


def paired_mean_from_long(
    df: pd.DataFrame,
    *,
    case_col: str,
    metric_col: str,
    value_col: str,
    str_label: str = "STR-SMPC",
    dlr_label: str = "DLR-SMPC",
    group_cols: list[str] | None = None,
) -> pd.DataFrame:
    group_cols = group_cols or []
    rows = []
    for metric, gm in df.groupby(metric_col, dropna=False):
        keys = group_cols + [case_col]
        agg = (
            gm.groupby(keys, dropna=False)[value_col]
            .mean()
            .reset_index()
        )
        if group_cols:
            piv = agg.pivot_table(
                index=group_cols, columns=case_col, values=value_col, aggfunc="first"
            ).reset_index()
        else:
            piv = agg.pivot_table(
                columns=case_col, values=value_col, aggfunc="first"
            ).reset_index(drop=True)
        if str_label in piv.columns and dlr_label in piv.columns:
            piv["metric"] = metric
            piv["DLR_minus_STR"] = piv[dlr_label] - piv[str_label]
            rows.append(piv)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)


def find_optional_csvs(root: Path, relative_glob: str) -> list[Path]:
    return sorted(root.glob(relative_glob))


def file_inventory(paths: list[Path]) -> pd.DataFrame:
    rows = []
    for p in paths:
        rows.append(
            {
                "path": str(p),
                "name": p.name,
                "exists": p.exists(),
                "size_bytes": p.stat().st_size if p.exists() else np.nan,
                "sha256": sha256(p) if p.exists() else None,
            }
        )
    return pd.DataFrame(rows)
