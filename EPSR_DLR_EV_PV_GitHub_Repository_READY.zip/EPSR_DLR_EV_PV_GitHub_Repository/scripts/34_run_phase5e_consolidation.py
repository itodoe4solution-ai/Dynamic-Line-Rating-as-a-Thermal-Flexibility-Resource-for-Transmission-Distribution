
from __future__ import annotations

"""
Phase 5E — validation consolidation / publication tables.

A PASS here means the predeclared validation computations completed with intact
pairing and without unclassified backend exceptions. It does NOT mean that every
operating state is physically security-clean. Any observed voltage, thermal,
PF-convergence, OPF-feasibility, or N-1 failure remains a research result.
"""

from pathlib import Path
import hashlib
import importlib.util
import json
import os

import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")

P5A = OUTDIR / "phase5a_acpf_results.csv"
P5B = OUTDIR / "phase5b_acopf_results.csv"
P5C = OUTDIR / "phase5c_n1_results.csv"
P5D = OUTDIR / "phase5d_ieee39_results.csv"
P5A_SEL = OUTDIR / "phase5a_selected_operating_points.csv"
P5D_SEL = OUTDIR / "phase5d_ieee39_frozen_selection.csv"

PUB_OUT = OUTDIR / "phase5e_publication_summary.csv"
PAIR_OUT = OUTDIR / "phase5e_paired_validation_effects.csv"
GATE_OUT = OUTDIR / "phase5e_gate_summary.csv"
META_OUT = OUTDIR / "phase5e_metadata.json"

required = [P5A, P5B, P5C, P5D, P5A_SEL, P5D_SEL]
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise FileNotFoundError("Missing Phase-5 inputs:\n" + "\n".join(missing))

a = pd.read_csv(P5A)
b = pd.read_csv(P5B)
cc = pd.read_csv(P5C)
d = pd.read_csv(P5D)
asel = pd.read_csv(P5A_SEL)
dsel = pd.read_csv(P5D_SEL)

# -------------------------------------------------------------------------
# Publication summary
# -------------------------------------------------------------------------
rows = []

def add_summary(stage, model, df, success, error, vviol, tviol):
    ok = c.boolify(df[success])
    err = df[error].notna() & df[error].astype(str).str.len().gt(0)
    vv = pd.to_numeric(df[vviol], errors="coerce")
    tv = pd.to_numeric(df[tviol], errors="coerce")
    clean = ok & vv.eq(0) & tv.eq(0)
    rows.append(
        {
            "stage": stage,
            "model": model,
            "evaluations": int(len(df)),
            "successful_or_converged": int(ok.sum()),
            "execution_exceptions": int(err.sum()),
            "voltage_clean_evaluations": int(vv.eq(0).sum()),
            "thermal_clean_evaluations": int(tv.eq(0).sum()),
            "combined_security_clean_evaluations": int(clean.sum()),
            "success_fraction": float(ok.mean()) if len(df) else np.nan,
            "combined_security_clean_fraction": (
                float(clean.mean()) if len(df) else np.nan
            ),
        }
    )

add_summary(
    "5A",
    "IEEE118_ACPF",
    a,
    "acpf_success",
    "acpf_error",
    "acpf_bus_voltage_violation_count",
    "acpf_selected_corridor_thermal_violation_count",
)

# Distribution exact-BFS summary is distinct from transmission ACPF.
dist_clean = pd.to_numeric(
    a["distribution_voltage_violation_feeders"], errors="coerce"
).eq(0)
rows.append(
    {
        "stage": "5A",
        "model": "IEEE33_exact_BFS_0.95_1.05",
        "evaluations": int(len(a)),
        "successful_or_converged": int(len(a)),
        "execution_exceptions": 0,
        "voltage_clean_evaluations": int(dist_clean.sum()),
        "thermal_clean_evaluations": np.nan,
        "combined_security_clean_evaluations": int(dist_clean.sum()),
        "success_fraction": 1.0,
        "combined_security_clean_fraction": float(dist_clean.mean()),
    }
)

add_summary(
    "5B",
    "IEEE118_ACOPF",
    b,
    "acopf_success",
    "acopf_error",
    "acopf_bus_voltage_violation_count",
    "acopf_selected_corridor_thermal_violation_count",
)

add_summary(
    "5C",
    "IEEE118_N1_ACPF",
    cc,
    "n1_acpf_success",
    "n1_acpf_error",
    "n1_bus_voltage_violation_count",
    "n1_remaining_selected_corridor_thermal_violation_count",
)

add_summary(
    "5D",
    "IEEE39_ACPF_normalized_robustness",
    d,
    "ieee39_acpf_success",
    "ieee39_acpf_error",
    "ieee39_acpf_bus_voltage_violation_count",
    "ieee39_acpf_selected_branch_thermal_violation_count",
)

add_summary(
    "5D",
    "IEEE39_ACOPF_normalized_robustness",
    d,
    "ieee39_acopf_success",
    "ieee39_acopf_error",
    "ieee39_acopf_bus_voltage_violation_count",
    "ieee39_acopf_selected_branch_thermal_violation_count",
)

pub = pd.DataFrame(rows)
pub.to_csv(PUB_OUT, index=False)

# -------------------------------------------------------------------------
# Paired STR/DLR effects on common sentinel timestamps
# -------------------------------------------------------------------------
paired_rows = []

def paired_metric(df, stage, metric, extra_keys=None):
    keys = ["pair_id", "timestamp_utc"]
    if extra_keys:
        keys += list(extra_keys)
    z = df[keys + ["case", metric]].copy()
    p = z.pivot_table(index=keys, columns="case", values=metric, aggfunc="first")
    if {"STR-SMPC", "DLR-SMPC"}.issubset(p.columns):
        q = p.dropna(subset=["STR-SMPC", "DLR-SMPC"]).copy()
        for idx, r in q.iterrows():
            idx_tuple = idx if isinstance(idx, tuple) else (idx,)
            rec = dict(zip(keys, idx_tuple))
            rec.update(
                {
                    "stage": stage,
                    "metric": metric,
                    "STR": float(r["STR-SMPC"]),
                    "DLR": float(r["DLR-SMPC"]),
                    "DLR_minus_STR": float(r["DLR-SMPC"] - r["STR-SMPC"]),
                }
            )
            paired_rows.append(rec)

for metric in [
    "acpf_selected_corridor_max_loading_pu",
    "acpf_bus_voltage_violation_count",
]:
    paired_metric(a, "5A", metric)

for metric in [
    "acopf_selected_corridor_max_loading_pu",
    "acopf_bus_voltage_violation_count",
]:
    paired_metric(b, "5B", metric)

for metric in [
    "n1_remaining_selected_corridor_max_loading_pu",
    "n1_bus_voltage_violation_count",
]:
    paired_metric(cc, "5C", metric, extra_keys=["outage_branch_id"])

for metric in [
    "ieee39_acpf_selected_branch_max_loading_pu",
    "ieee39_acpf_bus_voltage_violation_count",
    "ieee39_acopf_selected_branch_max_loading_pu",
]:
    paired_metric(d, "5D", metric)

paired = pd.DataFrame(paired_rows)
paired.to_csv(PAIR_OUT, index=False)

# -------------------------------------------------------------------------
# Process-integrity gates
# -------------------------------------------------------------------------
def no_exceptions(df, col):
    return bool(
        ~(
            df[col].notna()
            & df[col].astype(str).str.strip().ne("")
        ).any()
    )

a_pair_complete = bool(
    (
        a.groupby(["pair_id", "timestamp_utc"])["case"].nunique()
        == 2
    ).all()
)
b_pair_complete = bool(
    (
        b.groupby(["pair_id", "timestamp_utc"])["case"].nunique()
        == 2
    ).all()
)
c_pair_complete = bool(
    (
        cc.groupby(["pair_id", "timestamp_utc", "outage_branch_id"])["case"].nunique()
        == 2
    ).all()
)
d_pair_complete = bool(
    (
        d.groupby(["pair_id", "timestamp_utc"])["case"].nunique()
        == 2
    ).all()
)

expected_n1 = len(a) * int(cc["outage_branch_id"].nunique())

gates = [
    {
        "gate": "phase5a_operating_points_exist_and_are_paired",
        "status": bool(len(a) > 0 and a_pair_complete),
        "note": "Same sentinel timestamp is evaluated under STR and DLR.",
    },
    {
        "gate": "phase5a_no_backend_execution_exceptions",
        "status": no_exceptions(a, "acpf_error"),
        "note": "Returned PF non-convergence, if any, is not treated as an exception.",
    },
    {
        "gate": "phase5b_same_operating_points_and_complete_pairs",
        "status": bool(len(b) == len(a) and b_pair_complete),
        "note": "ACOPF evaluates the exact same frozen sentinel states.",
    },
    {
        "gate": "phase5b_no_backend_execution_exceptions",
        "status": no_exceptions(b, "acopf_error"),
        "note": "Returned OPF infeasibility, if any, remains a research result.",
    },
    {
        "gate": "phase5c_expected_selected_N1_matrix_complete",
        "status": bool(len(cc) == expected_n1 and c_pair_complete),
        "note": "Each sentinel state is evaluated for every frozen selected-corridor outage.",
    },
    {
        "gate": "phase5c_no_backend_execution_exceptions",
        "status": no_exceptions(cc, "n1_acpf_error"),
        "note": "Post-contingency non-convergence remains a research result.",
    },
    {
        "gate": "phase5d_ieee39_baseline_selection_frozen",
        "status": bool(len(dsel) == 5),
        "note": "IEEE-39 branches are selected from baseline loading before transferred DLR outcomes.",
    },
    {
        "gate": "phase5d_complete_STR_DLR_pairing",
        "status": bool(len(d) == len(a) and d_pair_complete),
        "note": "Same mapped robustness states are compared under STR and normalized DLR uplift.",
    },
    {
        "gate": "phase5d_no_backend_execution_exceptions",
        "status": bool(
            no_exceptions(d, "ieee39_acpf_error")
            and no_exceptions(d, "ieee39_acopf_error")
        ),
        "note": "Returned PF/OPF failure remains a research result; exceptions do not.",
    },
    {
        "gate": "phase5_publication_tables_created",
        "status": bool(len(pub) >= 6 and PAIR_OUT.exists()),
        "note": "Validation summary and paired-effect tables exist.",
    },
]

gate = pd.DataFrame(gates)
gate.to_csv(GATE_OUT, index=False)

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

meta = {
    "stage": "5E",
    "phase5_meaning_of_pass": (
        "A PASS certifies completion/integrity of the validation workflow, not "
        "universal security satisfaction."
    ),
    "source_hashes_sha256": {
        p.name: sha256(p) for p in [P5A, P5B, P5C, P5D, P5A_SEL, P5D_SEL]
    },
    "publication_summary": str(PUB_OUT),
    "paired_validation_effects": str(PAIR_OUT),
    "gate_summary": str(GATE_OUT),
}
META_OUT.write_text(json.dumps(meta, indent=2), encoding="utf-8")

print("\nPHASE-5E PUBLICATION SUMMARY")
print(pub.to_string(index=False))
print("\nPHASE-5E RESEARCH / PROCESS GATE")
print(gate.to_string(index=False))

if not c.boolify(gate["status"]).all():
    failed = gate.loc[~c.boolify(gate["status"])]
    raise RuntimeError(
        "Phase 5E process-integrity gates failed:\n"
        + failed.to_string(index=False)
    )

print("\nPASS: PHASE 5E VALIDATION CONSOLIDATION COMPLETE.")
print(
    "IMPORTANT: This PASS means the workflow completed consistently; "
    "inspect the publication summary for actual security violations."
)
