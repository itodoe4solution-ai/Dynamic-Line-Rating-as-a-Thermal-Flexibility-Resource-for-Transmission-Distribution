import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from epsr_pipeline.common import ROOT, load_config, require_study_period, ensure_directories
from epsr_pipeline.ev import build_ev_profile_from_jsonl

ensure_directories(); cfg=load_config(); start,end=require_study_period(cfg)
profile,qc,balance=build_ev_profile_from_jsonl(
    ROOT/"01_raw/acn_ev/acn_sessions_timeseries.jsonl", start,end,int(cfg["project"]["interval_minutes"])
)
profile.to_csv(ROOT/"03_processed/ev_profile_15min.csv", index=False)
qc.to_csv(ROOT/"05_quality_control/ev_quality_flags.csv", index=False)
balance.to_csv(ROOT/"05_quality_control/ev_energy_balance_report.csv", index=False)
bucket_order = ["0-1h", "1-2h", "2-4h", "4-8h", "8h+", "unknown"]
bucket_summary_rows = []
if len(balance):
    total_energy = float(balance["reported_kwh"].sum()) if "reported_kwh" in balance else 0.0
    if "duration_bucket" in balance:
        grouped = balance.copy()
        grouped["duration_bucket"] = grouped["duration_bucket"].fillna("unknown")
        for bucket in bucket_order:
            sub = grouped[grouped["duration_bucket"] == bucket]
            if sub.empty:
                continue
            energy_total = float(sub["reported_kwh"].sum()) if "reported_kwh" in sub else 0.0
            measured_energy = float(sub.loc[sub["reconstruction_method"] == "measured_current_shape", "reported_kwh"].sum()) if "reconstruction_method" in sub else 0.0
            template_energy = float(sub.loc[sub["reconstruction_method"] == "template_shape", "reported_kwh"].sum()) if "reconstruction_method" in sub else 0.0
            bucket_summary_rows.append({
                "duration_bucket": bucket,
                "sessions_total": int(len(sub)),
                "sessions_measured_shape": int((sub.get("reconstruction_method") == "measured_current_shape").sum()) if "reconstruction_method" in sub else 0,
                "sessions_template_shape": int((sub.get("reconstruction_method") == "template_shape").sum()) if "reconstruction_method" in sub else 0,
                "sessions_no_energy": int((sub.get("reconstruction_method") == "no_energy").sum()) if "reconstruction_method" in sub else 0,
                "energy_kwh_total": energy_total,
                "energy_kwh_measured_shape": measured_energy,
                "energy_kwh_template_shape": template_energy,
                "fallback_share_of_energy": float(sub.loc[sub["reconstruction_method"] != "measured_current_shape", "reported_kwh"].sum() / energy_total) if energy_total > 0 and "reconstruction_method" in sub else 0.0,
                "template_shape_share_of_energy": float(template_energy / energy_total) if energy_total > 0 else 0.0,
            })
bucket_summary = pd.DataFrame(bucket_summary_rows)
if not bucket_summary.empty:
    bucket_summary.to_csv(ROOT/"05_quality_control/ev_duration_bucket_summary.csv", index=False)
temporal = pd.DataFrame([{
    "sessions_total": int(len(balance)),
    "sessions_with_full_window": int(balance.full_session_inside_study_window.sum()) if "full_session_inside_study_window" in balance else 0,
    "sessions_measured_shape": int((balance.get("reconstruction_method") == "measured_current_shape").sum()) if "reconstruction_method" in balance else 0,
    "sessions_template_shape": int((balance.get("reconstruction_method") == "template_shape").sum()) if "reconstruction_method" in balance else 0,
    "sessions_no_energy": int((balance.get("reconstruction_method") == "no_energy").sum()) if "reconstruction_method" in balance else 0,
    "energy_kwh_measured_shape": float(balance.loc[balance.get("reconstruction_method") == "measured_current_shape", "reported_kwh"].sum()) if "reconstruction_method" in balance else 0.0,
    "energy_kwh_template_shape": float(balance.loc[balance.get("reconstruction_method") == "template_shape", "reported_kwh"].sum()) if "reconstruction_method" in balance else 0.0,
    "fallback_share_of_energy": float(balance.loc[balance.get("reconstruction_method") != "measured_current_shape", "reported_kwh"].sum() / balance["reported_kwh"].sum()) if len(balance) and float(balance["reported_kwh"].sum()) > 0 else 0.0,
    "template_shape_share_of_energy": float(balance.loc[balance.get("reconstruction_method") == "template_shape", "reported_kwh"].sum() / balance["reported_kwh"].sum()) if len(balance) and float(balance["reported_kwh"].sum()) > 0 else 0.0,
}])
temporal.to_csv(ROOT/"05_quality_control/ev_temporal_realism_report.csv", index=False)
print(f"EV profile rows: {len(profile)}")
print(temporal.to_string(index=False))
if not bucket_summary.empty:
    print(bucket_summary.to_string(index=False))
print(f"Connected=0 but EV power>0: {int(((profile.ev_connected_count==0)&(profile.ev_power_kw>1e-9)).sum())}")
if not balance.empty and balance.error_percent.notna().any():
    print(f"Median full-session energy error: {balance.error_percent.dropna().median():.6f}%")
