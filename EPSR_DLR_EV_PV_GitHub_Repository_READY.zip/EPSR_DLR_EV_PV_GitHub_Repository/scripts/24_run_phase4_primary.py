from __future__ import annotations

from pathlib import Path
from collections import deque
import math, time, json
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from sklearn.ensemble import HistGradientBoostingRegressor

# -----------------------------------------------------------------------------
# Paths -- portable repository discovery
# -----------------------------------------------------------------------------
import os

def _resolve_root() -> Path:
    env = os.environ.get('EPSR_ROOT')
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path.cwd(),
        Path(__file__).resolve().parent.parent if '__file__' in globals() else Path.cwd(),
        Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd(),
    ])
    for p in candidates:
        p = p.resolve()
        if (p/'04_master/master_dataset_classified.csv').exists() and (p/'06_scenarios/selected_periods.csv').exists():
            return p
    raise FileNotFoundError(
        'Could not locate EPSR repository root. Run this script from the repository root '
        'or set environment variable EPSR_ROOT to that folder.'
    )

ROOT = _resolve_root()
P2 = ROOT/'09_simulation_inputs'/'phase2_td'
P3 = ROOT/'07_forecasts'
OUTDIR = ROOT/'09_simulation_inputs'/'results'
OUTDIR.mkdir(parents=True, exist_ok=True)
OUT = OUTDIR/'phase4_primary_results.csv'

REQUIRED_INPUTS = [
    ROOT/'04_master/master_dataset_classified.csv',
    ROOT/'06_scenarios/selected_periods.csv',
    P2/'heterogeneous_feeder_classes.csv',
    P2/'feeder_population_calculation.csv',
    P2/'selected_dlr_corridors.csv',
    P2/'corridor_ratings_15min.csv',
    P3/'final_model_selection.csv',
]
_missing_inputs = [str(p.relative_to(ROOT)) for p in REQUIRED_INPUTS if not p.exists()]
if _missing_inputs:
    raise FileNotFoundError('Missing Phase-4 input artifacts: ' + ', '.join(_missing_inputs))

print('EPSR ROOT:', ROOT)
print('Phase-4 output:', OUT)

# -----------------------------------------------------------------------------
# Study constants (frozen for primary Phase-4 comparison)
# -----------------------------------------------------------------------------
CLASSES = list('ABCDE')
H = 4  # 4-hour primary SMPC horizon
SCENARIO_COUNT = 20
COMMON_SEEDS = list(range(10))
VLOW, VHIGH = 0.90, 1.10  # Phase-4 reduced-order envelope; Phase-5 checks 0.95-1.05 AC
BINDING_THRESHOLD = 0.98
W_DUE = 1e6
W_CURTAIL = 1e3
W_BACKLOG = 10.0
W_RAMP = 0.1
RNG_BASE = 20260820

# -----------------------------------------------------------------------------
# Load inputs
# -----------------------------------------------------------------------------
master15 = pd.read_csv(ROOT/'04_master/master_dataset_classified.csv', parse_dates=['timestamp_utc'])
master15 = master15.sort_values('timestamp_utc').reset_index(drop=True)
periods = pd.read_csv(ROOT/'06_scenarios/selected_periods.csv')
classes = pd.read_csv(P2/'heterogeneous_feeder_classes.csv')
pop = pd.read_csv(P2/'feeder_population_calculation.csv')
selected = pd.read_csv(P2/'selected_dlr_corridors.csv')
ratings15 = pd.read_csv(P2/'corridor_ratings_15min.csv', parse_dates=['timestamp_utc'])
phase3_selection = pd.read_csv(P3/'final_model_selection.csv')

nom = pop[pop['selected_nominal'].astype(bool)].iloc[0]
counts = {c:int(nom[f'class_{c}_count']) for c in CLASSES}
assert sum(counts.values()) == int(nom['recommended_integer_feeder_count']) == 37

class_row = {r.feeder_class:r for _,r in classes.iterrows()}
ev_scale = {c:float(class_row[c].ev_profile_scale_factor) for c in CLASSES}
pv_scale = {c:float(class_row[c].pv_profile_scale_factor) for c in CLASSES}
deadline_h = {c:max(2, int(math.ceil(float(class_row[c].median_session_duration_h)))) for c in CLASSES}

# Physical charge ceiling: enough to reproduce the reconstructed uncontrolled profile.
base_ev_max_kw = float(master15.ev_power_kw.max())
pmax_mw = {c:base_ev_max_kw*ev_scale[c]/1000.0 for c in CLASSES}

# Empirical 2019 ACN connection-to-disconnection duration distributions by the
# frozen Phase-2 station-energy quintiles. Each hourly flexible-energy arrival
# is split across these deadline bins, preserving the Phase-2 aggregate energy
# chronology while replacing the earlier median-deadline approximation.
DURATION_PROB = {
'A':{1:.062,2:.188,3:.090,4:.073,5:.056,6:.041,7:.047,8:.072,9:.122,10:.104,11:.052,12:.094},
'B':{1:.045,2:.096,3:.075,4:.080,5:.067,6:.084,7:.083,8:.113,9:.161,10:.096,11:.041,12:.058},
'C':{1:.072,2:.158,3:.082,4:.071,5:.071,6:.082,7:.097,8:.108,9:.100,10:.079,11:.033,12:.047},
'D':{1:.081,2:.125,3:.114,4:.086,5:.073,6:.069,7:.096,8:.119,9:.106,10:.065,11:.031,12:.035},
'E':{1:.177,2:.127,3:.152,4:.076,5:.089,6:.038,7:.063,8:.127,9:.114,10:.025,12:.013},
}
# Renormalize rounded probabilities exactly to one.
for _c in CLASSES:
    _z=sum(DURATION_PROB[_c].values())
    DURATION_PROB[_c]={d:p/_z for d,p in DURATION_PROB[_c].items()}

# -----------------------------------------------------------------------------
# Hourly aggregation
# -----------------------------------------------------------------------------
m = master15.set_index('timestamp_utc').copy()
# Power/meteorological quantities -> mean; EV interval energy -> sum.
mean_cols = [
    'ev_power_kw','pv_ac_kw','system_load_mw','load_forecast_mw',
    'temperature_c','wind_speed_ms','relative_humidity_pct','ghi_wm2','dni_wm2',
    'dhi_wm2','poa_global_wm2','pv_cell_temperature_c','solar_zenith_angle_deg',
    'ev_connected_count','ev_charging_count','ev_arrivals','ev_departures'
]
hourly = m[mean_cols].resample('1h').mean()
hourly['ev_energy_kwh'] = m['ev_energy_kwh'].resample('1h').sum()
hourly = hourly.reset_index()

# Conservative hourly ratings: minimum of four 15-min ratings.
rh = ratings15.set_index('timestamp_utc').groupby('corridor_id').resample('1h').agg({
    'branch_id':'first','from_bus':'first','to_bus':'first','str_mva':'min','dlr_mva':'min'
}).reset_index()
rating_lookup = {}
for cid in selected.corridor_id:
    d = rh[rh.corridor_id==cid].set_index('timestamp_utc')
    rating_lookup[cid] = d[['str_mva','dlr_mva']]

# -----------------------------------------------------------------------------
# Frozen Phase-3 model types, mapped to hourly horizons.
# Exact frozen anchors: EV 1h=HGB, 2h/4h=HOW; PV 1h/2h/4h=HGB.
# 3h inherits the nearest longer-horizon family (EV HOW, PV HGB).
# -----------------------------------------------------------------------------
MODEL_TYPE = {
    'ev_power_kw': {1:'hist_gradient_boosting_direct',2:'historical_hour_of_week_mean',3:'historical_hour_of_week_mean',4:'historical_hour_of_week_mean'},
    'pv_ac_kw': {1:'hist_gradient_boosting_direct',2:'hist_gradient_boosting_direct',3:'hist_gradient_boosting_direct',4:'hist_gradient_boosting_direct'},
}

# Confirm the frozen anchor selections used to define this mapping.
sel_map = {(r.target,int(r.horizon_minutes//60)):r.selected_model for _,r in phase3_selection.iterrows() if r.horizon_minutes in [60,120,240]}
assert sel_map[('ev_power_kw',1)] == MODEL_TYPE['ev_power_kw'][1]
assert sel_map[('ev_power_kw',2)] == MODEL_TYPE['ev_power_kw'][2]
assert sel_map[('ev_power_kw',4)] == MODEL_TYPE['ev_power_kw'][4]
assert sel_map[('pv_ac_kw',1)] == MODEL_TYPE['pv_ac_kw'][1]
assert sel_map[('pv_ac_kw',2)] == MODEL_TYPE['pv_ac_kw'][2]
assert sel_map[('pv_ac_kw',4)] == MODEL_TYPE['pv_ac_kw'][4]

# EV source support ends at last nonzero/active interval; preserve zero structural tail explicitly.
ev_support_cols=['ev_power_kw','ev_energy_kwh','ev_connected_count','ev_charging_count','ev_arrivals','ev_departures']
active15 = master15[ev_support_cols].fillna(0).abs().sum(axis=1).gt(0).to_numpy()
ev_support_end_ts = master15.loc[np.where(active15)[0][-1], 'timestamp_utc'].floor('h')

# -----------------------------------------------------------------------------
# Hourly forecast models + calibration residual pools
# -----------------------------------------------------------------------------
def hourly_slot_of_week(ts: pd.Series) -> pd.Series:
    return (ts.dt.dayofweek*24 + ts.dt.hour).astype(int)

def historical_how(y: pd.Series, fit_mask: np.ndarray) -> np.ndarray:
    slots = hourly_slot_of_week(hourly.timestamp_utc)
    z = pd.DataFrame({'slot':slots[fit_mask], 'y':y[fit_mask]}).dropna()
    mp = z.groupby('slot').y.mean().to_dict()
    fallback = float(z.y.mean())
    return np.array([mp.get(int(s), fallback) for s in slots], float)

def hourly_features(target: str, h: int) -> pd.DataFrame:
    y = pd.to_numeric(hourly[target], errors='coerce')
    ts = hourly.timestamp_utc
    X = pd.DataFrame(index=hourly.index)
    for name,lag in [('y_origin',h),('y_lag1',h+1),('y_lag24',h+24),('y_lag168',h+168)]:
        X[name] = y.shift(lag)
    for w in [4,12,24]:
        X[f'rollmean_{w}'] = y.rolling(w,min_periods=w).mean().shift(h)
    X['rollstd_12'] = y.rolling(12,min_periods=12).std().shift(h)
    hour = ts.dt.hour
    X['sin_day']=np.sin(2*np.pi*hour/24); X['cos_day']=np.cos(2*np.pi*hour/24)
    X['sin_week']=np.sin(2*np.pi*(ts.dt.dayofweek*24+hour)/(7*24)); X['cos_week']=np.cos(2*np.pi*(ts.dt.dayofweek*24+hour)/(7*24))
    X['sin_year']=np.sin(2*np.pi*(ts.dt.dayofyear-1)/365.25); X['cos_year']=np.cos(2*np.pi*(ts.dt.dayofyear-1)/365.25)
    X['weekend']=(ts.dt.dayofweek>=5).astype(int)
    for c in ['system_load_mw','temperature_c','wind_speed_ms','relative_humidity_pct']:
        X[c+'_origin']=pd.to_numeric(hourly[c],errors='coerce').shift(h)
    if target=='ev_power_kw':
        for c in ['ev_connected_count','ev_charging_count','ev_arrivals','ev_departures']:
            X[c+'_origin']=pd.to_numeric(hourly[c],errors='coerce').shift(h)
    else:
        for c in ['ghi_wm2','dni_wm2','dhi_wm2','poa_global_wm2','pv_cell_temperature_c']:
            X[c+'_origin']=pd.to_numeric(hourly[c],errors='coerce').shift(h)
        X['solar_zenith_target']=pd.to_numeric(hourly.solar_zenith_angle_deg,errors='coerce')
        X['daylight_target']=(X.solar_zenith_target<90).astype(int)
    return X

def hgb():
    return HistGradientBoostingRegressor(
        learning_rate=.06,max_iter=120,max_leaf_nodes=31,min_samples_leaf=20,
        l2_regularization=.1,early_stopping=True,validation_fraction=.1,
        random_state=2026
    )

forecast = {t:{} for t in ['ev_power_kw','pv_ac_kw']}
resid_pool = {t:{} for t in ['ev_power_kw','pv_ac_kw']}

for target in ['ev_power_kw','pv_ac_kw']:
    y = pd.to_numeric(hourly[target], errors='coerce')
    if target=='ev_power_kw':
        support = hourly.timestamp_utc <= ev_support_end_ts
    else:
        support = np.ones(len(hourly),dtype=bool)
    support = np.asarray(support)
    n = int(np.where(support)[0][-1]+1)
    tr = int(n*.70); ve=int(n*.85); se=tr+(ve-tr)//2
    fit_mask = (np.arange(len(hourly)) < se) & support
    cal_mask = (np.arange(len(hourly)) >= se) & (np.arange(len(hourly)) < ve) & support
    for h in range(1,H+1):
        model_type = MODEL_TYPE[target][h]
        if model_type=='historical_hour_of_week_mean':
            pred = historical_how(y, fit_mask)
        else:
            X = hourly_features(target,h)
            valid = X.notna().all(axis=1).to_numpy()
            idx = np.where(fit_mask & y.notna().to_numpy() & valid)[0]
            model=hgb(); model.fit(X.iloc[idx], y.iloc[idx])
            pred=np.full(len(hourly),np.nan)
            pred[valid]=model.predict(X.loc[valid])
        pred=np.maximum(pred,0)
        if target=='ev_power_kw': pred[~support]=0.0
        forecast[target][h]=pred
        good=cal_mask & np.isfinite(y.to_numpy()) & np.isfinite(pred)
        resid=(y.to_numpy()-pred)[good]
        resid_pool[target][h]=resid[np.isfinite(resid)]

# Load forecast residual margins, trained/calibrated on first 70% of year.
load_resid = (hourly.system_load_mw - hourly.load_forecast_mw).to_numpy(float)
load_train = load_resid[:int(len(load_resid)*.70)]
load_train=load_train[np.isfinite(load_train)]
load_q10, load_q90 = np.quantile(load_train,[.10,.90])
annual_system_max = float(master15.system_load_mw.max())

# -----------------------------------------------------------------------------
# IEEE-33 reduced-order voltage envelope derived from exact balanced BFS.
# Active native/EV/PV is allocated proportional to canonical active load weights.
# Native Q scales with native load; EV and PV are unity-PF.
# -----------------------------------------------------------------------------
LOADS = {
    1:(0,0), 2:(100,60), 3:(90,40), 4:(120,80), 5:(60,30), 6:(60,20),
    7:(200,100), 8:(200,100), 9:(60,20), 10:(60,20), 11:(45,30),
    12:(60,35), 13:(60,35), 14:(120,80), 15:(60,10), 16:(60,20),
    17:(60,20), 18:(90,40), 19:(90,40), 20:(90,40), 21:(90,40),
    22:(90,40), 23:(90,50), 24:(420,200), 25:(420,200), 26:(60,25),
    27:(60,25), 28:(60,20), 29:(120,70), 30:(200,600), 31:(150,70),
    32:(210,100), 33:(60,40),
}
BRANCHES = [
    (1,2,0.0922,0.0470),(2,3,0.4930,0.2511),(3,4,0.3660,0.1864),(4,5,0.3811,0.1941),
    (5,6,0.8190,0.7070),(6,7,0.1872,0.6188),(7,8,0.7114,0.2351),(8,9,1.0300,0.7400),
    (9,10,1.0440,0.7400),(10,11,0.1966,0.0650),(11,12,0.3744,0.1238),(12,13,1.4680,1.1550),
    (13,14,0.5416,0.7129),(14,15,0.5910,0.5260),(15,16,0.7463,0.5450),(16,17,1.2890,1.7210),
    (17,18,0.7320,0.5740),(2,19,0.1640,0.1565),(19,20,1.5042,1.3554),(20,21,0.4095,0.4784),
    (21,22,0.7089,0.9373),(3,23,0.4512,0.3083),(23,24,0.8980,0.7091),(24,25,0.8960,0.7011),
    (6,26,0.2030,0.1034),(26,27,0.2842,0.1447),(27,28,1.0590,0.9337),(28,29,0.8042,0.7006),
    (29,30,0.5075,0.2585),(30,31,0.9744,0.9630),(31,32,0.3105,0.3619),(32,33,0.3410,0.5302),
]
children=[[] for _ in range(34)]; parent=np.zeros(34,dtype=int); zline={}
for f,t,r,x in BRANCHES:
    children[f].append(t); parent[t]=f; zline[(f,t)]=complex(r,x)
order=[]; dq=deque([1])
while dq:
    u=dq.popleft();order.append(u);dq.extend(children[u])
P0=np.array([0.0]+[LOADS[i][0] for i in range(1,34)],float)
Q0=np.array([0.0]+[LOADS[i][1] for i in range(1,34)],float)
wbus=P0/P0.sum(); vsl=12.66e3/math.sqrt(3)

def bfs_v(native_factor:float, net_p_mw:float):
    extra_kw=net_p_mw*1000.0-P0.sum()*native_factor
    P=P0*native_factor+wbus*extra_kw; Q=Q0*native_factor
    v=np.full(34,complex(vsl,0.0))
    for _ in range(100):
        il=np.zeros(34,dtype=complex)
        for i in range(2,34):
            sph=complex(P[i],Q[i])*1000.0/3.0
            il[i]=np.conj(sph/v[i])
        ib={}
        for u in reversed(order[1:]):
            ib[(parent[u],u)] = il[u]+sum(ib[(u,c)] for c in children[u])
        vn=np.zeros(34,dtype=complex); vn[1]=vsl
        for u in order[1:]: vn[u]=vn[parent[u]]-ib[(parent[u],u)]*zline[(parent[u],u)]
        if np.max(np.abs(vn[1:]-v[1:]))<1e-7:
            v=vn; break
        v=vn
    pu=np.abs(v[1:])/vsl
    return float(pu.min()),float(pu.max())

def find_bounds(f):
    # lower export bound: max V <= VHIGH
    lo,hi=-15.0,0.0
    if bfs_v(f,lo)[1] <= VHIGH: pmin=lo
    else:
        for _ in range(30):
            mid=(lo+hi)/2
            if bfs_v(f,mid)[1] > VHIGH: lo=mid
            else: hi=mid
        pmin=hi
    # upper import bound: min V >= VLOW
    lo,hi=0.0,12.0
    if bfs_v(f,hi)[0] >= VLOW: pmax=hi
    else:
        for _ in range(30):
            mid=(lo+hi)/2
            if bfs_v(f,mid)[0] >= VLOW: lo=mid
            else: hi=mid
        pmax=lo
    return pmin,pmax

fgrid=np.linspace(0.15,1.20,43)
bounds=np.array([find_bounds(float(f)) for f in fgrid])

def voltage_bounds(f):
    f=float(np.clip(f,fgrid[0],fgrid[-1]))
    return (float(np.interp(f,fgrid,bounds[:,0])), float(np.interp(f,fgrid,bounds[:,1])))

# -----------------------------------------------------------------------------
# LP helpers
# -----------------------------------------------------------------------------
# variable blocks x, curtail, slack_due, ramp; shape C x H each
C=len(CLASSES); NCH=C*H

def vid(block,c,k):
    b={'x':0,'cur':1,'slack':2,'ramp':3}[block]
    return b*NCH + c*H+k

NVAR=4*NCH

def add_ub(A,b,coef,rhs):
    row=np.zeros(NVAR,float)
    for j,v in coef.items(): row[j]+=v
    A.append(row);b.append(float(rhs))

# corridor data frozen in Phase 2
corridors=[]
for _,r in selected.iterrows():
    corridors.append({
        'cid':r.corridor_id,'base':float(r.baseline_dc_flow_mw),
        'ptdf':float(r.ptdf_pcc78_to_slack69),
    })

# Time lookup indices
h_index = {ts:i for i,ts in enumerate(hourly.timestamp_utc)}

# Forecast residual paired sampler. We sample target-specific residuals independently
# because the current Phase-3 artifacts do not freeze a joint residual copula.
def scenario_forecasts(origin_i, seed):
    """Current hour is observed; k=1..3 are stochastic 1h..3h forecasts."""
    rng=np.random.default_rng(seed)
    ev_s=np.zeros((SCENARIO_COUNT,H)); pv_s=np.zeros((SCENARIO_COUNT,H))
    # current-hour nowcast/observation
    ev_now=float(hourly.loc[origin_i,'ev_power_kw']) if origin_i < len(hourly) else 0.0
    pv_now=float(hourly.loc[origin_i,'pv_ac_kw']) if origin_i < len(hourly) else 0.0
    ev_s[:,0]=max(0.0,ev_now); pv_s[:,0]=max(0.0,pv_now)
    for k in range(1,H):
        ti=origin_i+k
        if ti>=len(hourly):
            ev_hat=pv_hat=0.0
        else:
            ev_hat=float(forecast['ev_power_kw'][k][ti])
            pv_hat=float(forecast['pv_ac_kw'][k][ti])
        er=resid_pool['ev_power_kw'][k]; pr=resid_pool['pv_ac_kw'][k]
        ev_err=rng.choice(er,size=SCENARIO_COUNT,replace=True) if len(er) else np.zeros(SCENARIO_COUNT)
        pv_err=rng.choice(pr,size=SCENARIO_COUNT,replace=True) if len(pr) else np.zeros(SCENARIO_COUNT)
        ev_s[:,k]=np.maximum(0.0,ev_hat+ev_err)
        pv_s[:,k]=np.maximum(0.0,pv_hat+pv_err)
    return ev_s,pv_s

# -----------------------------------------------------------------------------
# Actual queue execution
# -----------------------------------------------------------------------------
def queue_energy(q): return float(sum(q.values()))

def add_energy_arrival(q, t, energy, c):
    if energy <= 0: return
    for d,p in DURATION_PROB[c].items():
        due=int(t+d)
        q[due]=q.get(due,0.0)+float(energy)*float(p)

def serve_fifo(q, energy):
    served=0.0; rem=float(max(0,energy))
    for due in sorted(list(q.keys())):
        if rem<=1e-12: break
        amt=q.get(due,0.0); take=min(rem,amt); amt-=take; rem-=take; served+=take
        if amt<=1e-12: q.pop(due,None)
        else: q[due]=amt
    return served

def expire_due(q,t):
    lost=0.0
    for due in sorted([d for d in q if d<=t]):
        lost += q.pop(due,0.0)
    return lost

# -----------------------------------------------------------------------------
# Solve one selected week / seed / rating case
# -----------------------------------------------------------------------------
def run_case(window_row, seed:int, case:str):
    start=pd.Timestamp(window_row.start_utc); end=pd.Timestamp(window_row.end_utc_exclusive)
    win=hourly[(hourly.timestamp_utc>=start)&(hourly.timestamp_utc<end)].copy().reset_index(drop=True)
    if len(win)!=168: raise RuntimeError(f'{window_row.scenario}: expected 168 hours, got {len(win)}')

    queues={c:{} for c in CLASSES}
    prev_x={c:0.0 for c in CLASSES}
    unserved=0.0; required_due=0.0; curtail_total=0.0; pcc_energy=0.0
    ramp_total=0.0; solver_time=0.0; solver_fail=0
    all_loadings=[]; binding_hours=0; thermal_viol=0; voltage_viol=0

    for j,row in win.iterrows():
        for c in CLASSES:
            arr=float(row.ev_energy_kwh)*ev_scale[c]/1000.0
            if row.timestamp_utc>ev_support_end_ts: arr=0.0
            for d,prob in DURATION_PROB[c].items():
                if j+d <= len(win)-1:
                    required_due += arr*prob*counts[c]

    # Four-hour rolling blocks: solve a 4h stochastic program, execute its four
    # hourly set-points, then re-estimate state and re-solve.
    for block_start in range(0,len(win),H):
        row0=win.iloc[block_start]; ts0=row0.timestamp_utc; gi0=h_index[ts0]
        # Add current-hour arrivals before optimizing the first block action.
        for c in CLASSES:
            arr=float(row0.ev_energy_kwh)*ev_scale[c]/1000.0
            if ts0>ev_support_end_ts: arr=0.0
            if arr>0: add_energy_arrival(queues[c],block_start,arr,c)

        ev_s,pv_s=scenario_forecasts(gi0, RNG_BASE + seed*100000 + block_start*97)
        ev_med=np.quantile(ev_s,.50,axis=0); ev_hi=np.quantile(ev_s,.90,axis=0)
        pv_lo=np.quantile(pv_s,.10,axis=0); pv_hi=np.quantile(pv_s,.90,axis=0)

        A=[]; b=[]; cobj=np.zeros(NVAR,float); bounds_lp=[]
        for ci,c in enumerate(CLASSES):
            for k in range(H):
                cobj[vid('x',ci,k)] = -W_BACKLOG*counts[c]
                cobj[vid('cur',ci,k)] = W_CURTAIL*counts[c]
                cobj[vid('slack',ci,k)] = W_DUE*counts[c]
                cobj[vid('ramp',ci,k)] = W_RAMP*counts[c]
        for block in ['x','cur','slack','ramp']:
            for ci,c in enumerate(CLASSES):
                for k in range(H):
                    if block=='x': ub=pmax_mw[c]
                    elif block=='cur': ub=max(0.0,pv_hi[k]*pv_scale[c]/1000.0)
                    else: ub=None
                    bounds_lp.append((0,ub))

        for ci,c in enumerate(CLASSES):
            B0=queue_energy(queues[c]); qlist=list(queues[c].items())
            for k in range(H):
                avail=B0
                # k=0 is current hour and already in B0. Future energy enters from j=1.
                for j in range(1,k+1):
                    avail += max(0.0,ev_med[j])*ev_scale[c]/1000.0
                add_ub(A,b,{vid('x',ci,j):1.0 for j in range(k+1)},avail)

                due=sum(amt for due_t,amt in qlist if due_t <= block_start+k)
                for j in range(1,k+1):
                    future_arr=max(0.0,ev_hi[j])*ev_scale[c]/1000.0
                    for d,prob in DURATION_PROB[c].items():
                        if block_start+j+d <= block_start+k:
                            due += future_arr*prob
                coef={vid('x',ci,j):-1.0 for j in range(k+1)}; coef[vid('slack',ci,k)] = -1.0
                add_ub(A,b,coef,-due)

                if k==0:
                    add_ub(A,b,{vid('x',ci,k):1,vid('ramp',ci,k):-1},prev_x[c])
                    add_ub(A,b,{vid('x',ci,k):-1,vid('ramp',ci,k):-1},-prev_x[c])
                else:
                    add_ub(A,b,{vid('x',ci,k):1,vid('x',ci,k-1):-1,vid('ramp',ci,k):-1},0)
                    add_ub(A,b,{vid('x',ci,k):-1,vid('x',ci,k-1):1,vid('ramp',ci,k):-1},0)

        for k in range(H):
            ti=min(gi0+k,len(hourly)-1)
            future_ts=hourly.loc[ti,'timestamp_utc']
            lf=float(hourly.loc[ti,'load_forecast_mw'])
            native_lo_factor=max(0.0,(lf+load_q10)/annual_system_max)
            native_hi_factor=max(0.0,(lf+load_q90)/annual_system_max)
            native_lo=3.715*native_lo_factor; native_hi=3.715*native_hi_factor

            for ci,c in enumerate(CLASSES):
                pmin,_=voltage_bounds(native_lo_factor); _,pmaxv=voltage_bounds(native_hi_factor)
                pvlow=max(0,pv_lo[k])*pv_scale[c]/1000.0; pvhigh=max(0,pv_hi[k])*pv_scale[c]/1000.0
                add_ub(A,b,{vid('x',ci,k):1,vid('cur',ci,k):1},pmaxv-native_hi+pvlow)
                add_ub(A,b,{vid('x',ci,k):-1,vid('cur',ci,k):-1},native_lo-pvhigh-pmin)

            const_hi=0.0; const_lo=0.0; coeff={}
            for ci,c in enumerate(CLASSES):
                n=counts[c]; pvlow=max(0,pv_lo[k])*pv_scale[c]/1000.0; pvhigh=max(0,pv_hi[k])*pv_scale[c]/1000.0
                const_hi += n*(native_hi-pvlow); const_lo += n*(native_lo-pvhigh)
                coeff[vid('x',ci,k)] = coeff.get(vid('x',ci,k),0)+n
                coeff[vid('cur',ci,k)] = coeff.get(vid('cur',ci,k),0)+n

            for cor in corridors:
                rr=rating_lookup[cor['cid']]
                rating=float(rr.loc[future_ts,'str_mva' if case=='STR-SMPC' else 'dlr_mva'])
                base=cor['base']; ptdf=cor['ptdf']
                coef_hi={j:(-ptdf)*v for j,v in coeff.items()}
                add_ub(A,b,coef_hi,rating-base+ptdf*const_hi)
                add_ub(A,b,coef_hi,rating-base+ptdf*const_lo)
                coef_lo={j:(ptdf)*v for j,v in coeff.items()}
                add_ub(A,b,coef_lo,rating+base-ptdf*const_hi)
                add_ub(A,b,coef_lo,rating+base-ptdf*const_lo)

        t0=time.perf_counter(); res=linprog(cobj,A_ub=np.asarray(A),b_ub=np.asarray(b),bounds=bounds_lp,method='highs'); solver_time += time.perf_counter()-t0
        if not res.success:
            solver_fail += 1
            plan_x=np.zeros((C,H)); plan_cur=np.zeros((C,H))
        else:
            plan_x=np.array([[res.x[vid('x',ci,k)] for k in range(H)] for ci in range(C)])
            plan_cur=np.array([[res.x[vid('cur',ci,k)] for k in range(H)] for ci in range(C)])

        # Execute all four hourly set-points in the block against realized data.
        for k in range(H):
            local_t=block_start+k
            if local_t>=len(win): break
            row=win.iloc[local_t]; ts=row.timestamp_utc
            # Arrivals for k>0 become known only at execution time.
            if k>0:
                for c in CLASSES:
                    arr=float(row.ev_energy_kwh)*ev_scale[c]/1000.0
                    if ts>ev_support_end_ts: arr=0.0
                    if arr>0: add_energy_arrival(queues[c],local_t,arr,c)

            actual_factor=float(row.system_load_mw)/annual_system_max; native_actual=3.715*actual_factor
            pcc=0.0; hour_vviol=0
            for ci,c in enumerate(CLASSES):
                actual_pv=max(0.0,float(row.pv_ac_kw)*pv_scale[c]/1000.0)
                cur=min(float(plan_cur[ci,k]),actual_pv)
                avail=queue_energy(queues[c]); x=min(float(plan_x[ci,k]),pmax_mw[c],avail)
                x=serve_fifo(queues[c],x)
                lost=expire_due(queues[c],local_t); unserved += lost*counts[c]
                curtail_total += cur*counts[c]; ramp_total += abs(x-prev_x[c])*counts[c]; prev_x[c]=x
                net=native_actual+x-(actual_pv-cur); pcc += counts[c]*net
                pmin,pmaxv=voltage_bounds(actual_factor)
                if net < pmin-1e-6 or net > pmaxv+1e-6: hour_vviol += counts[c]
            voltage_viol += hour_vviol; pcc_energy += pcc

            hour_binding=False
            for cor in corridors:
                rr=rating_lookup[cor['cid']]; rating=float(rr.loc[ts,'str_mva' if case=='STR-SMPC' else 'dlr_mva'])
                flow=cor['base']-cor['ptdf']*pcc; loading=abs(flow)/rating; all_loadings.append(loading)
                if loading>=BINDING_THRESHOLD: hour_binding=True
                if loading>1.000001: thermal_viol += 1
            if hour_binding: binding_hours += 1

    last=len(win)-1
    for c in CLASSES: unserved += expire_due(queues[c],last)*counts[c]
    service_ratio=1.0 if required_due<=1e-12 else max(0.0,1.0-unserved/required_due)
    cost=W_DUE*unserved+W_CURTAIL*curtail_total+W_RAMP*ramp_total
    ev_support_fraction=float(np.mean(win.timestamp_utc<=ev_support_end_ts))
    return {
        'network':'IEEE118+37xIEEE33','window_id':window_row.scenario,'seed':seed,'case':case,
        'rating_policy':'STR' if case=='STR-SMPC' else 'DLR','ev_unserved_mwh':unserved,'ev_service_ratio':service_ratio,
        'pv_curtailment_mwh':curtail_total,'pcc_energy_mwh':pcc_energy,'mean_loading_pu':float(np.mean(all_loadings)),
        'max_loading_pu':float(np.max(all_loadings)),'binding_hours':int(binding_hours),'voltage_violation_count':int(voltage_viol),
        'thermal_violation_count':int(thermal_viol),'cost':float(cost),'solve_time_s':float(solver_time),
        'required_ev_due_mwh':float(required_due),'served_ev_due_mwh':float(max(0,required_due-unserved)),'feeder_count':37,
        'pcc_bus':78,'slack_bus':69,'critical_branch_id':121,'mpc_horizon_h':H,'control_interval_h':H,'scenario_count':SCENARIO_COUNT,
        'ev_deadline_model':'aggregate reconstructed charging-energy arrivals split by empirical 2019 ACN class-specific connection-duration deadline distribution (1-12 h)',
        'uncertainty_method':'empirical calibration-residual bootstrap from frozen Phase-3 model families; 10/50/90 scenario quantiles',
        'rating_forecast_assumption':'short-horizon STR/DLR rating chronology treated as known; DLR weather-forecast uncertainty deferred',
        'voltage_limit_low_pu':VLOW,'voltage_limit_high_pu':VHIGH,
        'voltage_check_method':'IEEE-33 balanced BFS-derived reduced-order active-power envelope; Phase-5 AC check pending',
        'ev_support_fraction':ev_support_fraction,'solver_fail_count':solver_fail,
        'cost_units':'penalty units = 1e6*unserved_MWh + 1e3*curtail_MWh + 0.1*ramp_MW',
        'phase4_status':'primary reduced-order stochastic T-D experiment; final AC/N-1 confirmation deferred to Phase 5',
    }

# -----------------------------------------------------------------------------
# Run all frozen windows, common seeds, paired STR/DLR cases.
# Serial execution is the safest default inside Windows/Jupyter.
# -----------------------------------------------------------------------------
def main():
    rows=[]
    start_all=time.perf_counter()
    jobs=[]
    for _,w in periods.iterrows():
        for seed in COMMON_SEEDS:
            for case in ['STR-SMPC','DLR-SMPC']:
                jobs.append((w,seed,case))

    print(f'Phase-4 jobs: {len(jobs)} = {len(periods)} windows x {len(COMMON_SEEDS)} seeds x 2 rating policies')
    for i,args in enumerate(jobs,1):
        rows.append(run_case(*args))
        if i % 10 == 0 or i == len(jobs):
            print(f'completed {i}/{len(jobs)}', flush=True)

    dfout=pd.DataFrame(rows)
    # Frozen notebook contract first; extra audit columns after.
    required=[
        'network','window_id','seed','case','rating_policy',
        'ev_unserved_mwh','ev_service_ratio','pv_curtailment_mwh','pcc_energy_mwh',
        'mean_loading_pu','max_loading_pu','binding_hours','voltage_violation_count',
        'thermal_violation_count','cost','solve_time_s'
    ]
    dfout=dfout[required+[c for c in dfout.columns if c not in required]]
    dfout=dfout.sort_values(['window_id','seed','case']).reset_index(drop=True)
    dfout.to_csv(OUT,index=False)

    # QA checks
    assert len(dfout)==len(periods)*len(COMMON_SEEDS)*2
    assert not dfout[required].isna().any().any()
    assert set(dfout['case'])=={'STR-SMPC','DLR-SMPC'}
    assert dfout.groupby(['window_id','seed']).size().eq(2).all()
    assert dfout.ev_service_ratio.between(0,1).all()
    assert (dfout[['ev_unserved_mwh','pv_curtailment_mwh','solve_time_s']]>=0).all().all()

    summary=dfout.groupby('case').agg(
        rows=('case','size'),
        mean_unserved_mwh=('ev_unserved_mwh','mean'),
        mean_service_ratio=('ev_service_ratio','mean'),
        mean_pv_curt_mwh=('pv_curtailment_mwh','mean'),
        mean_max_loading=('max_loading_pu','mean'),
        thermal_viol=('thermal_violation_count','sum'),
        voltage_viol=('voltage_violation_count','sum'),
        solver_fail=('solver_fail_count','sum'),
        solve_s=('solve_time_s','sum'),
    ).reset_index()
    summary.to_csv(OUTDIR/'phase4_primary_summary_check.csv',index=False)

    p=dfout.pivot(index=['window_id','seed'],columns='case',values='ev_unserved_mwh').dropna()
    p['DLR_minus_STR']=p['DLR-SMPC']-p['STR-SMPC']
    p.reset_index().to_csv(OUTDIR/'phase4_ev_unserved_paired_check.csv',index=False)

    meta={
        'rows':len(dfout), 'windows':len(periods), 'seeds':COMMON_SEEDS,
        'scenario_count':SCENARIO_COUNT, 'primary_horizon_h':H,
        'runtime_s':time.perf_counter()-start_all,
        'ev_support_end_utc':str(ev_support_end_ts),
        'voltage_limits_phase4':[VLOW,VHIGH],
        'output':str(OUT),
        'method_note':'Reduced-order stochastic T-D Phase-4 screen; final AC/N-1 confirmation is Phase 5.'
    }
    (OUTDIR/'phase4_run_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')

    print('\nPASS: Phase-4 primary result contract generated.')
    print('Saved:', OUT)
    print(summary.to_string(index=False))
    print('\nPaired DLR-STR unserved MWh:')
    print(p['DLR_minus_STR'].describe().to_string())
    print('runtime_s',meta['runtime_s'])
    return dfout

if __name__ == '__main__':
    main()
