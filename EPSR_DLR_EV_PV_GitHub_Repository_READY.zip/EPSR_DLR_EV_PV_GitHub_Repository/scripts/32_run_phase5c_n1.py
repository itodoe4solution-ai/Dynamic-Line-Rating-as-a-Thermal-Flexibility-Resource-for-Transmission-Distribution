
from __future__ import annotations

"""Phase 5C — selected N-1 branch-contingency AC power-flow validation."""

from pathlib import Path
import importlib.util
import json
import os
import time

import numpy as np
import pandas as pd


def load_common():
    path = Path(__file__).resolve().parent / "29_phase5_common.py"
    spec = importlib.util.spec_from_file_location("phase5_common", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


c = load_common()
ROOT = c.resolve_root()
OUTDIR = c.ensure_dir(ROOT / "09_simulation_inputs" / "results")
IN = OUTDIR / "phase5a_acpf_results.csv"
OUT = OUTDIR / "phase5c_n1_results.csv"
SUMMARY_OUT = OUTDIR / "phase5c_summary.csv"
META_OUT = OUTDIR / "phase5c_metadata.json"

RUN_CORRECTIVE_OPF = os.environ.get(
    "PHASE5C_RUN_CORRECTIVE_OPF", "0"
).strip() == "1"

if not IN.exists():
    raise FileNotFoundError(f"Phase-5A output not found: {IN}")

p4c = c.import_phase4c(ROOT)
corridors = c.corridor_rows_from_phase4(p4c.p4)
branch_ids = [int(x["branch_id"]) for x in corridors]
branch_to_cid = {int(x["branch_id"]): x["corridor_id"] for x in corridors}

backend = c.load_power_backend()
print("EPSR ROOT:", ROOT)
print("PHASE 5C — selected N-1 AC validation")
print("Contingencies:", branch_ids)
print("Corrective ACOPF enabled:", RUN_CORRECTIVE_OPF)

src = pd.read_csv(IN)
records = []
t0 = time.perf_counter()

total = len(src) * len(branch_ids)
counter = 0

for _, row in src.iterrows():
    ratings = c.parse_int_float_json(row["corridor_ratings_mva_json"])

    for outage_bid in branch_ids:
        counter += 1
        mpc = c.build_case118_state(
            backend,
            pcc_mw=float(row["pcc_mw"]),
            pcc_q_mvar=float(row["pcc_q_mvar"]),
            pcc_bus=78,
            ratings_by_branch=ratings,
            vmin=0.95,
            vmax=1.05,
        )
        mpc["branch"][outage_bid - 1, c.BR_STATUS] = 0

        result, success, error = c.run_pf(backend, mpc)
        ev = c.evaluate_ac_result(
            result,
            corridor_branch_ids=branch_ids,
            vmin=0.95,
            vmax=1.05,
            outaged_branch_id=outage_bid,
        )

        copf_success = np.nan
        copf_error = None
        copf_vviol = np.nan
        copf_tviol = np.nan
        if RUN_CORRECTIVE_OPF:
            opfr, opfs, opfe = c.run_opf(backend, mpc)
            opev = c.evaluate_ac_result(
                opfr,
                corridor_branch_ids=branch_ids,
                vmin=0.95,
                vmax=1.05,
                outaged_branch_id=outage_bid,
            )
            copf_success = bool(opfs)
            copf_error = opfe
            copf_vviol = opev["bus_voltage_violation_count"]
            copf_tviol = opev["selected_corridor_thermal_violation_count"]

        records.append(
            {
                "pair_id": row["pair_id"],
                "window_id": row["window_id"],
                "seed": int(row["seed"]),
                "stress_regime": row["stress_regime"],
                "feeder_count": int(row["feeder_count"]),
                "mpc_horizon_h": int(row["mpc_horizon_h"]),
                "timestamp_utc": row["timestamp_utc"],
                "sentinel_reason": row["sentinel_reason"],
                "case": row["case"],
                "rating_policy": row["rating_policy"],
                "pcc_mw": float(row["pcc_mw"]),
                "pcc_q_mvar": float(row["pcc_q_mvar"]),
                "outage_branch_id": int(outage_bid),
                "outage_corridor_id": branch_to_cid[int(outage_bid)],
                "n1_acpf_success": bool(success),
                "n1_acpf_error": error,
                "n1_bus_vmin_pu": ev["bus_vmin_pu"],
                "n1_bus_vmax_pu": ev["bus_vmax_pu"],
                "n1_bus_voltage_violation_count": ev[
                    "bus_voltage_violation_count"
                ],
                "n1_remaining_selected_corridor_max_loading_pu": ev[
                    "selected_corridor_max_loading_pu"
                ],
                "n1_remaining_selected_corridor_thermal_violation_count": ev[
                    "selected_corridor_thermal_violation_count"
                ],
                "corrective_acopf_enabled": bool(RUN_CORRECTIVE_OPF),
                "corrective_acopf_success": copf_success,
                "corrective_acopf_error": copf_error,
                "corrective_acopf_bus_voltage_violation_count": copf_vviol,
                "corrective_acopf_selected_corridor_thermal_violation_count": copf_tviol,
            }
        )

        if counter % 25 == 0 or counter == total:
            print(f"N-1 evaluated {counter}/{total}")

df = pd.DataFrame(records)
df.to_csv(OUT, index=False)

summary = (
    df.assign(
        pf_ok=c.boolify(df["n1_acpf_success"]),
        voltage_clean=pd.to_numeric(
            df["n1_bus_voltage_violation_count"], errors="coerce"
        ).eq(0),
        thermal_clean=pd.to_numeric(
            df["n1_remaining_selected_corridor_thermal_violation_count"],
            errors="coerce",
        ).eq(0),
    )
    .groupby(["stress_regime", "case"], dropna=False)
    .agg(
        contingency_evaluations=("outage_branch_id", "size"),
        n1_pf_converged=("pf_ok", "sum"),
        execution_errors=("n1_acpf_error", lambda s: int(s.notna().sum())),
        voltage_clean=("voltage_clean", "sum"),
        remaining_corridor_thermal_clean=("thermal_clean", "sum"),
        worst_vmin=("n1_bus_vmin_pu", "min"),
        worst_vmax=("n1_bus_vmax_pu", "max"),
        worst_remaining_corridor_loading=(
            "n1_remaining_selected_corridor_max_loading_pu",
            "max",
        ),
    )
    .reset_index()
)
summary.to_csv(SUMMARY_OUT, index=False)

errors = int(df["n1_acpf_error"].notna().sum())
if RUN_CORRECTIVE_OPF:
    errors += int(df["corrective_acopf_error"].notna().sum())

if errors:
    raise RuntimeError(
        f"Phase-5C had {errors} backend execution exceptions. "
        "Returned non-convergence/infeasibility is retained as a research result."
    )

META_OUT.write_text(
    json.dumps(
        {
            "stage": "5C",
            "backend": backend["name"],
            "selected_contingencies": branch_ids,
            "selection_rule": (
                "all five DLR corridors frozen before Phase-4 outcomes; "
                "each is opened individually as an N-1 line contingency"
            ),
            "corrective_acopf_enabled": RUN_CORRECTIVE_OPF,
            "evaluations": int(len(df)),
            "output": str(OUT),
        },
        indent=2,
    ),
    encoding="utf-8",
)

print("\nPHASE-5C SUMMARY")
print(summary.to_string(index=False))
print("\nPASS: PHASE 5C COMPUTATION COMPLETE.")
print("Saved:", OUT)
print("runtime_s:", time.perf_counter() - t0)
