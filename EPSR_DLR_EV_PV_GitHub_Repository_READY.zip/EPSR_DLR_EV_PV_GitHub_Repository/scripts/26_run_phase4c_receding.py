from __future__ import annotations

"""
Phase 4C — true hourly receding-horizon SMPC confirmation.

Scientific purpose
------------------
This script upgrades the Phase-4A/4B block-execution controller to a genuine
receding-horizon implementation. At every hourly control instant it:

    1. updates the EV deadline queues with current arrivals,
    2. rebuilds the stochastic EV/PV forecast scenarios,
    3. solves the H-hour STR-SMPC or DLR-SMPC problem,
    4. implements only the first control action,
    5. observes the realized hour and updates queues/states,
    6. moves forward one hour and re-solves.

The default confirmation matrix is intentionally narrower than Phase 4B:
    feeder regimes: nominal 37 and high-stress 43
    MPC horizons:   2 h, 4 h, 8 h
    frozen windows: all selected periods
    common seeds:   0..9
    rating cases:   STR-SMPC and DLR-SMPC

For 13 frozen windows this produces:
    2 regimes × 3 horizons × 13 windows × 10 seeds × 2 cases = 1560 rows.

The script does NOT overwrite Phase-4A or Phase-4B outputs.

Important interpretation boundary
---------------------------------
The reduced-order voltage envelope is the same 0.90–1.10 pu Phase-4 screen.
Definitive 0.95–1.05 pu AC feasibility, ACOPF, N-1 and IEEE-39 validation
remain Phase 5 tasks.
"""

from pathlib import Path
import importlib.util
import json
import os
import time
from collections import Counter

import numpy as np
import pandas as pd
from scipy.optimize import linprog


# =============================================================================
# 1. Locate repository and import the already-validated Phase-4B foundation
# =============================================================================

def _resolve_root() -> Path:
    env = os.environ.get("EPSR_ROOT")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path.cwd(),
        Path(__file__).resolve().parent.parent,
        Path(__file__).resolve().parent,
    ])
    for p in candidates:
        p = p.resolve()
        if (
            (p / "04_master" / "master_dataset_classified.csv").exists()
            and (p / "06_scenarios" / "selected_periods.csv").exists()
        ):
            return p
    raise FileNotFoundError(
        "Could not locate EPSR repository root. Run from the repository root "
        "or set EPSR_ROOT to that folder."
    )


ROOT = _resolve_root()
PHASE4B_ENGINE = ROOT / "scripts" / "25_run_phase4b_sensitivity.py"
if not PHASE4B_ENGINE.exists():
    raise FileNotFoundError(
        f"Required Phase-4B engine not found: {PHASE4B_ENGINE}\n"
        "Copy 25_run_phase4b_sensitivity.py into ROOT/scripts first."
    )

spec = importlib.util.spec_from_file_location("phase4b_engine", PHASE4B_ENGINE)
if spec is None or spec.loader is None:
    raise RuntimeError("Could not import the Phase-4B engine.")
p4b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p4b)
p4 = p4b.p4


# =============================================================================
# 2. Output paths — Phase 4C is isolated from Phase 4A / 4B
# =============================================================================

OUTDIR = ROOT / "09_simulation_inputs" / "results"
OUTDIR.mkdir(parents=True, exist_ok=True)

OUT = OUTDIR / "phase4c_receding_horizon_results.csv"
SUMMARY_OUT = OUTDIR / "phase4c_receding_horizon_summary.csv"
FEAS_OUT = OUTDIR / "phase4c_pair_feasibility.csv"
PAIRED_OUT = OUTDIR / "phase4c_strict_feasible_paired_effects.csv"
META_OUT = OUTDIR / "phase4c_receding_horizon_metadata.json"


# =============================================================================
# 3. Frozen confirmation design
# =============================================================================

# Primary receding-horizon confirmation: nominal + predeclared high stress.
REGIMES = ["nominal", "high"]
if os.environ.get("PHASE4C_INCLUDE_MODERATE", "0").strip() == "1":
    REGIMES = ["moderate", "nominal", "high"]

MPC_HORIZONS_H = [2, 4, 8]
COMMON_SEEDS = list(range(10))
CASES = ["STR-SMPC", "DLR-SMPC"]

# Smoke test: one nominal window, one seed, 4-h horizon, both cases.
SMOKE_TEST = os.environ.get("PHASE4C_SMOKE_TEST", "0").strip() == "1"

# Reuse all frozen penalties and reduced-order security settings.
SCENARIO_COUNT = p4b.SCENARIO_COUNT
VLOW, VHIGH = p4b.VLOW, p4b.VHIGH
BINDING_THRESHOLD = p4b.BINDING_THRESHOLD
W_DUE = p4b.W_DUE
W_CURTAIL = p4b.W_CURTAIL
W_BACKLOG = p4b.W_BACKLOG
W_RAMP = p4b.W_RAMP
RNG_BASE = p4b.RNG_BASE
CLASSES = p4b.CLASSES
C = len(CLASSES)

hourly = p4b.hourly
periods_all = p4.periods.copy()
regime_rows = p4b.regime_rows

for regime in REGIMES:
    if regime not in regime_rows:
        raise RuntimeError(f"Missing frozen Phase-2 feeder regime: {regime}")


# =============================================================================
# 4. LP construction for one receding-horizon solve
# =============================================================================

def _solve_receding_plan(
    *,
    win: pd.DataFrame,
    local_t: int,
    seed: int,
    case: str,
    regime: str,
    requested_horizon_h: int,
    queues: dict[str, dict[int, float]],
    prev_x: dict[str, float],
):
    """Solve the current stochastic horizon and return the first control action.

    The horizon is truncated only near the final hour of the frozen week.
    The current hour is observed; future hours use the frozen Phase-3 forecast
    families and empirical calibration-residual bootstrap already established
    in Phase 4B.
    """

    reg = regime_rows[regime]
    counts = reg["counts"]

    H = int(min(requested_horizon_h, len(win) - local_t))
    if H < 1:
        raise RuntimeError("Internal horizon became empty.")

    _, NVAR, vid = p4b.make_lp_index(H)

    row0 = win.iloc[local_t]
    ts0 = row0.timestamp_utc
    gi0 = p4.h_index[ts0]

    # Same stochastic sample for STR and DLR for a given paired run/hour.
    scenario_seed = (
        RNG_BASE
        + seed * 100_000
        + local_t * 97
        + requested_horizon_h * 1_009
    )
    ev_s, pv_s = p4b.scenario_forecasts_h(gi0, scenario_seed, H)
    ev_med = np.quantile(ev_s, 0.50, axis=0)
    ev_hi = np.quantile(ev_s, 0.90, axis=0)
    pv_lo = np.quantile(pv_s, 0.10, axis=0)
    pv_hi = np.quantile(pv_s, 0.90, axis=0)

    A, b = [], []
    cobj = np.zeros(NVAR, dtype=float)
    bounds_lp = []

    # Objective: prioritize deadline service, then curtailment/backlog/ramp.
    for ci, c in enumerate(CLASSES):
        for k in range(H):
            cobj[vid("x", ci, k)] = -W_BACKLOG * counts[c]
            cobj[vid("cur", ci, k)] = W_CURTAIL * counts[c]
            cobj[vid("slack", ci, k)] = W_DUE * counts[c]
            cobj[vid("ramp", ci, k)] = W_RAMP * counts[c]

    # Variable bounds.
    for block in ["x", "cur", "slack", "ramp"]:
        for ci, c in enumerate(CLASSES):
            for k in range(H):
                if block == "x":
                    ub = p4.pmax_mw[c]
                elif block == "cur":
                    ub = max(0.0, pv_hi[k] * p4.pv_scale[c] / 1000.0)
                else:
                    ub = None
                bounds_lp.append((0.0, ub))

    # -------------------------------------------------------------------------
    # EV availability, deadline, and ramp constraints
    # -------------------------------------------------------------------------
    for ci, c in enumerate(CLASSES):
        B0 = p4.queue_energy(queues[c])
        qlist = list(queues[c].items())

        for k in range(H):
            # Current queue plus forecast future arrivals through k.
            avail = B0
            for jj in range(1, k + 1):
                avail += max(0.0, ev_med[jj]) * p4.ev_scale[c] / 1000.0

            p4b.add_ub(
                A,
                b,
                NVAR,
                {vid("x", ci, jj): 1.0 for jj in range(k + 1)},
                avail,
            )

            # Energy whose deadline is reached by future hour k.
            due = sum(
                amt
                for due_t, amt in qlist
                if due_t <= local_t + k
            )
            for jj in range(1, k + 1):
                future_arr = max(0.0, ev_hi[jj]) * p4.ev_scale[c] / 1000.0
                for d, prob in p4.DURATION_PROB[c].items():
                    if local_t + jj + d <= local_t + k:
                        due += future_arr * prob

            coef = {
                vid("x", ci, jj): -1.0
                for jj in range(k + 1)
            }
            coef[vid("slack", ci, k)] = -1.0
            p4b.add_ub(A, b, NVAR, coef, -due)

            if k == 0:
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, 0): 1.0,
                        vid("ramp", ci, 0): -1.0,
                    },
                    prev_x[c],
                )
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, 0): -1.0,
                        vid("ramp", ci, 0): -1.0,
                    },
                    -prev_x[c],
                )
            else:
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, k): 1.0,
                        vid("x", ci, k - 1): -1.0,
                        vid("ramp", ci, k): -1.0,
                    },
                    0.0,
                )
                p4b.add_ub(
                    A,
                    b,
                    NVAR,
                    {
                        vid("x", ci, k): -1.0,
                        vid("x", ci, k - 1): 1.0,
                        vid("ramp", ci, k): -1.0,
                    },
                    0.0,
                )

    # -------------------------------------------------------------------------
    # Reduced-order feeder voltage + IEEE-118 corridor constraints
    # -------------------------------------------------------------------------
    for k in range(H):
        ti = min(gi0 + k, len(hourly) - 1)
        future_ts = hourly.loc[ti, "timestamp_utc"]

        lf = float(hourly.loc[ti, "load_forecast_mw"])
        native_lo_factor = max(
            0.0,
            (lf + p4.load_q10) / p4.annual_system_max,
        )
        native_hi_factor = max(
            0.0,
            (lf + p4.load_q90) / p4.annual_system_max,
        )
        native_lo = 3.715 * native_lo_factor
        native_hi = 3.715 * native_hi_factor

        for ci, c in enumerate(CLASSES):
            pmin, _ = p4.voltage_bounds(native_lo_factor)
            _, pmaxv = p4.voltage_bounds(native_hi_factor)

            pvlow = max(0.0, pv_lo[k]) * p4.pv_scale[c] / 1000.0
            pvhigh = max(0.0, pv_hi[k]) * p4.pv_scale[c] / 1000.0

            p4b.add_ub(
                A,
                b,
                NVAR,
                {
                    vid("x", ci, k): 1.0,
                    vid("cur", ci, k): 1.0,
                },
                pmaxv - native_hi + pvlow,
            )
            p4b.add_ub(
                A,
                b,
                NVAR,
                {
                    vid("x", ci, k): -1.0,
                    vid("cur", ci, k): -1.0,
                },
                native_lo - pvhigh - pmin,
            )

        const_hi = 0.0
        const_lo = 0.0
        coeff = {}

        for ci, c in enumerate(CLASSES):
            n = counts[c]
            pvlow = max(0.0, pv_lo[k]) * p4.pv_scale[c] / 1000.0
            pvhigh = max(0.0, pv_hi[k]) * p4.pv_scale[c] / 1000.0

            const_hi += n * (native_hi - pvlow)
            const_lo += n * (native_lo - pvhigh)

            coeff[vid("x", ci, k)] = (
                coeff.get(vid("x", ci, k), 0.0) + n
            )
            coeff[vid("cur", ci, k)] = (
                coeff.get(vid("cur", ci, k), 0.0) + n
            )

        for cor in p4.corridors:
            rr = p4.rating_lookup[cor["cid"]]
            rating_col = "str_mva" if case == "STR-SMPC" else "dlr_mva"
            rating = float(rr.loc[future_ts, rating_col])
            base = cor["base"]
            ptdf = cor["ptdf"]

            coef_hi = {
                j: (-ptdf) * v
                for j, v in coeff.items()
            }
            p4b.add_ub(
                A,
                b,
                NVAR,
                coef_hi,
                rating - base + ptdf * const_hi,
            )
            p4b.add_ub(
                A,
                b,
                NVAR,
                coef_hi,
                rating - base + ptdf * const_lo,
            )

            coef_lo = {
                j: ptdf * v
                for j, v in coeff.items()
            }
            p4b.add_ub(
                A,
                b,
                NVAR,
                coef_lo,
                rating + base - ptdf * const_hi,
            )
            p4b.add_ub(
                A,
                b,
                NVAR,
                coef_lo,
                rating + base - ptdf * const_lo,
            )

    t0 = time.perf_counter()
    res = linprog(
        cobj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=bounds_lp,
        method="highs",
    )
    solve_s = time.perf_counter() - t0

    if res.success:
        first_x = np.array(
            [res.x[vid("x", ci, 0)] for ci in range(C)],
            dtype=float,
        )
        first_cur = np.array(
            [res.x[vid("cur", ci, 0)] for ci in range(C)],
            dtype=float,
        )
    else:
        # Do not silently fabricate a feasible plan. Zero controls are used only
        # as an execution fallback so realized states can continue to be logged.
        # Continuous performance comparisons later exclude any run with a failed
        # strict hard-constrained optimization hour.
        first_x = np.zeros(C, dtype=float)
        first_cur = np.zeros(C, dtype=float)

    return {
        "success": bool(res.success),
        "status": int(res.status),
        "message": str(res.message),
        "solve_time_s": float(solve_s),
        "first_x": first_x,
        "first_cur": first_cur,
        "effective_horizon_h": H,
    }


# =============================================================================
# 5. Run one frozen week / seed / rating policy with hourly re-optimization
# =============================================================================

def run_case_receding(
    window_row,
    seed: int,
    case: str,
    regime: str,
    requested_horizon_h: int,
):
    if regime not in REGIMES:
        raise ValueError(regime)
    if requested_horizon_h not in MPC_HORIZONS_H:
        raise ValueError(requested_horizon_h)
    if case not in CASES:
        raise ValueError(case)

    reg = regime_rows[regime]
    counts = reg["counts"]
    feeder_count = reg["feeder_count"]

    start = pd.Timestamp(window_row.start_utc)
    end = pd.Timestamp(window_row.end_utc_exclusive)
    win = hourly[
        (hourly.timestamp_utc >= start)
        & (hourly.timestamp_utc < end)
    ].copy().reset_index(drop=True)

    if len(win) != 168:
        raise RuntimeError(
            f"{window_row.scenario}: expected 168 hourly rows, got {len(win)}"
        )

    queues = {c: {} for c in CLASSES}
    prev_x = {c: 0.0 for c in CLASSES}

    unserved = 0.0
    required_due = 0.0
    curtail_total = 0.0
    pcc_energy = 0.0
    ramp_total = 0.0
    solver_time = 0.0
    solver_fail = 0
    infeasible_count = 0
    other_failure_count = 0
    failure_status_counts = Counter()
    first_failure_hour = None
    first_failure_timestamp = None

    all_loadings = []
    binding_hours = 0
    thermal_viol = 0
    voltage_viol = 0

    # Denominator for EV service: only empirical deadline energy whose deadline
    # remains inside the frozen evaluation week.
    for j, row in win.iterrows():
        for c in CLASSES:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if row.timestamp_utc > p4.ev_support_end_ts:
                arr = 0.0
            for d, prob in p4.DURATION_PROB[c].items():
                if j + d <= len(win) - 1:
                    required_due += arr * prob * counts[c]

    # -------------------------------------------------------------------------
    # TRUE RECEDING HORIZON: re-optimize every hour, execute only k=0
    # -------------------------------------------------------------------------
    for local_t, row in win.iterrows():
        ts = row.timestamp_utc

        # Current-hour EV arrivals are observed before optimization.
        for c in CLASSES:
            arr = float(row.ev_energy_kwh) * p4.ev_scale[c] / 1000.0
            if ts > p4.ev_support_end_ts:
                arr = 0.0
            if arr > 0.0:
                p4.add_energy_arrival(queues[c], local_t, arr, c)

        sol = _solve_receding_plan(
            win=win,
            local_t=local_t,
            seed=seed,
            case=case,
            regime=regime,
            requested_horizon_h=requested_horizon_h,
            queues=queues,
            prev_x=prev_x,
        )
        solver_time += sol["solve_time_s"]

        if not sol["success"]:
            solver_fail += 1
            failure_status_counts[sol["status"]] += 1
            if sol["status"] == 2:  # HiGHS infeasible
                infeasible_count += 1
            else:
                other_failure_count += 1
            if first_failure_hour is None:
                first_failure_hour = int(local_t)
                first_failure_timestamp = str(ts)

        first_x = sol["first_x"]
        first_cur = sol["first_cur"]

        # ---------------------------------------------------------------------
        # Execute ONLY the first action against realized current-hour data.
        # ---------------------------------------------------------------------
        actual_factor = float(row.system_load_mw) / p4.annual_system_max
        native_actual = 3.715 * actual_factor
        pcc = 0.0
        hour_vviol = 0

        for ci, c in enumerate(CLASSES):
            actual_pv = max(
                0.0,
                float(row.pv_ac_kw) * p4.pv_scale[c] / 1000.0,
            )
            cur = min(float(first_cur[ci]), actual_pv)

            avail = p4.queue_energy(queues[c])
            x = min(float(first_x[ci]), p4.pmax_mw[c], avail)
            x = p4.serve_fifo(queues[c], x)

            lost = p4.expire_due(queues[c], local_t)

            unserved += lost * counts[c]
            curtail_total += cur * counts[c]
            ramp_total += abs(x - prev_x[c]) * counts[c]
            prev_x[c] = x

            net = native_actual + x - (actual_pv - cur)
            pcc += counts[c] * net

            pmin, pmaxv = p4.voltage_bounds(actual_factor)
            if net < pmin - 1e-6 or net > pmaxv + 1e-6:
                hour_vviol += counts[c]

        voltage_viol += hour_vviol
        pcc_energy += pcc

        hour_binding = False
        for cor in p4.corridors:
            rr = p4.rating_lookup[cor["cid"]]
            rating_col = "str_mva" if case == "STR-SMPC" else "dlr_mva"
            rating = float(rr.loc[ts, rating_col])
            flow = cor["base"] - cor["ptdf"] * pcc
            loading = abs(flow) / rating
            all_loadings.append(loading)

            if loading >= BINDING_THRESHOLD:
                hour_binding = True
            if loading > 1.000001:
                thermal_viol += 1

        if hour_binding:
            binding_hours += 1

    # Expire only deadlines that lie inside the frozen week.
    last = len(win) - 1
    for c in CLASSES:
        unserved += p4.expire_due(queues[c], last) * counts[c]

    service_ratio = (
        1.0
        if required_due <= 1e-12
        else max(0.0, 1.0 - unserved / required_due)
    )
    cost = W_DUE * unserved + W_CURTAIL * curtail_total + W_RAMP * ramp_total
    ev_support_fraction = float(
        np.mean(win.timestamp_utc <= p4.ev_support_end_ts)
    )

    return {
        "network": f"IEEE118+{feeder_count}xIEEE33",
        "window_id": window_row.scenario,
        "seed": int(seed),
        "case": case,
        "rating_policy": "STR" if case == "STR-SMPC" else "DLR",
        "ev_unserved_mwh": float(unserved),
        "ev_service_ratio": float(service_ratio),
        "pv_curtailment_mwh": float(curtail_total),
        "pcc_energy_mwh": float(pcc_energy),
        "mean_loading_pu": float(np.mean(all_loadings)),
        "max_loading_pu": float(np.max(all_loadings)),
        "binding_hours": int(binding_hours),
        "voltage_violation_count": int(voltage_viol),
        "thermal_violation_count": int(thermal_viol),
        "cost": float(cost),
        "solve_time_s": float(solver_time),
        "stress_regime": regime,
        "target_loading_pu": float(reg["target_loading_pu"]),
        "phase2_predicted_loading_pu": float(reg["predicted_loading_pu"]),
        "feeder_count": int(feeder_count),
        "class_A_count": int(counts["A"]),
        "class_B_count": int(counts["B"]),
        "class_C_count": int(counts["C"]),
        "class_D_count": int(counts["D"]),
        "class_E_count": int(counts["E"]),
        "required_ev_due_mwh": float(required_due),
        "served_ev_due_mwh": float(max(0.0, required_due - unserved)),
        "pcc_bus": 78,
        "slack_bus": 69,
        "critical_branch_id": 121,
        "mpc_horizon_h": int(requested_horizon_h),
        "control_interval_h": 1,
        "reoptimization_interval_h": 1,
        "actions_executed_per_solve": 1,
        "execution_semantics": (
            "true hourly receding horizon: solve H-hour stochastic program, "
            "execute only k=0, update realized state, then re-solve next hour"
        ),
        "scenario_count": int(SCENARIO_COUNT),
        "ev_deadline_model": (
            "aggregate reconstructed charging-energy arrivals split by empirical "
            "2019 ACN class-specific connection-duration deadline distribution (1-12 h)"
        ),
        "uncertainty_method": (
            "empirical calibration-residual bootstrap from frozen Phase-3 selected "
            "model families; 10/50/90 scenario quantiles"
        ),
        "rating_forecast_assumption": (
            "short-horizon STR/DLR rating chronology treated as known; "
            "DLR weather-forecast uncertainty deferred"
        ),
        "voltage_limit_low_pu": float(VLOW),
        "voltage_limit_high_pu": float(VHIGH),
        "voltage_check_method": (
            "IEEE-33 balanced BFS-derived reduced-order active-power envelope; "
            "Phase-5 AC check pending"
        ),
        "ev_support_fraction": float(ev_support_fraction),
        "solver_fail_count": int(solver_fail),
        "solver_infeasible_count": int(infeasible_count),
        "solver_other_failure_count": int(other_failure_count),
        "strict_security_feasible": bool(solver_fail == 0),
        "first_failure_hour": first_failure_hour,
        "first_failure_timestamp_utc": first_failure_timestamp,
        "solver_status_counts_json": json.dumps(
            {str(k): int(v) for k, v in sorted(failure_status_counts.items())}
        ),
        "cost_units": (
            "penalty units = 1e6*unserved_MWh + 1e3*curtail_MWh + 0.1*ramp_MW"
        ),
        "phase4c_status": (
            "true hourly receding-horizon reduced-order stochastic T-D confirmation; "
            "final AC/N-1 confirmation deferred to Phase 5"
        ),
    }


# =============================================================================
# 6. Pair-feasibility and strict-feasible paired-effect tables
# =============================================================================

PAIR_KEYS = [
    "stress_regime",
    "feeder_count",
    "mpc_horizon_h",
    "network",
    "window_id",
    "seed",
]


def build_pair_feasibility(df: pd.DataFrame) -> pd.DataFrame:
    p = (
        df.pivot_table(
            index=PAIR_KEYS,
            columns="case",
            values="strict_security_feasible",
            aggfunc="first",
        )
        .reset_index()
    )
    p.columns.name = None
    p = p.rename(
        columns={
            "STR-SMPC": "str_strict_feasible",
            "DLR-SMPC": "dlr_strict_feasible",
        }
    )
    for c in ["str_strict_feasible", "dlr_strict_feasible"]:
        p[c] = p[c].astype(bool)

    p["both_strict_feasible"] = (
        p["str_strict_feasible"] & p["dlr_strict_feasible"]
    )
    p["dlr_restores_feasibility"] = (
        ~p["str_strict_feasible"] & p["dlr_strict_feasible"]
    )
    p["str_only_feasible"] = (
        p["str_strict_feasible"] & ~p["dlr_strict_feasible"]
    )
    p["neither_feasible"] = (
        ~p["str_strict_feasible"] & ~p["dlr_strict_feasible"]
    )
    return p


def build_strict_feasible_paired_effects(
    df: pd.DataFrame,
    pair_feas: pd.DataFrame,
) -> pd.DataFrame:
    valid_keys = pair_feas.loc[
        pair_feas["both_strict_feasible"],
        PAIR_KEYS,
    ].copy()

    metrics = [
        "ev_unserved_mwh",
        "ev_service_ratio",
        "pv_curtailment_mwh",
        "pcc_energy_mwh",
        "mean_loading_pu",
        "max_loading_pu",
        "binding_hours",
        "thermal_violation_count",
        "voltage_violation_count",
        "cost",
    ]

    out = valid_keys.copy()
    for metric in metrics:
        p = (
            df.pivot_table(
                index=PAIR_KEYS,
                columns="case",
                values=metric,
                aggfunc="first",
            )
            .reset_index()
        )
        p.columns.name = None
        if "STR-SMPC" not in p.columns or "DLR-SMPC" not in p.columns:
            raise RuntimeError(f"Incomplete paired cases for metric {metric}")

        p[f"{metric}__DLR_minus_STR"] = p["DLR-SMPC"] - p["STR-SMPC"]
        out = out.merge(
            p[PAIR_KEYS + [f"{metric}__DLR_minus_STR"]],
            on=PAIR_KEYS,
            how="left",
        )

    return out


# =============================================================================
# 7. Main experiment
# =============================================================================

def main():
    start_all = time.perf_counter()

    if SMOKE_TEST:
        periods = periods_all.iloc[:1].copy()
        seeds = [0]
        regimes = ["nominal"]
        horizons = [4]
    else:
        periods = periods_all.copy()
        seeds = COMMON_SEEDS
        regimes = REGIMES
        horizons = MPC_HORIZONS_H

    expected_rows = (
        len(regimes)
        * len(horizons)
        * len(periods)
        * len(seeds)
        * len(CASES)
    )

    print("EPSR ROOT:", ROOT)
    print("Phase 4C output:", OUT)
    print("Execution: TRUE hourly receding horizon")
    print("Regimes:", regimes)
    print("Horizons (h):", horizons)
    print("Windows:", len(periods))
    print("Seeds:", seeds)
    print("Expected result rows:", expected_rows)

    rows = []
    total_jobs = expected_rows
    job = 0

    for regime in regimes:
        for H in horizons:
            for _, window_row in periods.iterrows():
                for seed in seeds:
                    for case in CASES:
                        job += 1
                        if job == 1 or job % 20 == 0 or job == total_jobs:
                            print(
                                f"[{job:4d}/{total_jobs}] "
                                f"{regime} N={regime_rows[regime]['feeder_count']} "
                                f"H={H}h {window_row.scenario} seed={seed} {case}"
                            )
                        rows.append(
                            run_case_receding(
                                window_row,
                                seed,
                                case,
                                regime,
                                H,
                            )
                        )

    df = pd.DataFrame(rows)

    required = [
        "network",
        "window_id",
        "seed",
        "case",
        "rating_policy",
        "ev_unserved_mwh",
        "ev_service_ratio",
        "pv_curtailment_mwh",
        "pcc_energy_mwh",
        "mean_loading_pu",
        "max_loading_pu",
        "binding_hours",
        "voltage_violation_count",
        "thermal_violation_count",
        "cost",
        "solve_time_s",
        "stress_regime",
        "feeder_count",
        "mpc_horizon_h",
        "control_interval_h",
        "reoptimization_interval_h",
        "actions_executed_per_solve",
        "solver_fail_count",
        "solver_infeasible_count",
        "solver_other_failure_count",
        "strict_security_feasible",
    ]

    if len(df) != expected_rows:
        raise RuntimeError(
            f"Expected {expected_rows} Phase-4C rows, generated {len(df)}."
        )
    if df[required].isna().any().any():
        bad = df[required].columns[df[required].isna().any()].tolist()
        raise RuntimeError(f"Required Phase-4C columns contain missing values: {bad}")
    if set(df["case"]) != set(CASES):
        raise RuntimeError("Phase-4C cases are incomplete.")
    if not df["ev_service_ratio"].between(0, 1).all():
        raise RuntimeError("EV service ratio outside [0,1].")
    if not (df["control_interval_h"] == 1).all():
        raise RuntimeError("Phase-4C control interval is not hourly.")
    if not (df["reoptimization_interval_h"] == 1).all():
        raise RuntimeError("Phase-4C did not re-optimize hourly.")
    if not (df["actions_executed_per_solve"] == 1).all():
        raise RuntimeError("Phase-4C executed more than the first MPC action.")

    pair_sizes = df.groupby(PAIR_KEYS).size()
    if not pair_sizes.eq(2).all():
        raise RuntimeError("Incomplete STR/DLR paired design in Phase 4C.")

    df = df.sort_values(
        ["stress_regime", "feeder_count", "mpc_horizon_h", "window_id", "seed", "case"]
    ).reset_index(drop=True)
    df.to_csv(OUT, index=False)

    summary = (
        df.groupby(["stress_regime", "feeder_count", "mpc_horizon_h", "case"])
        .agg(
            runs=("case", "size"),
            strict_feasible_runs=("strict_security_feasible", "sum"),
            failed_runs=("solver_fail_count", lambda s: int((s > 0).sum())),
            failed_hours=("solver_fail_count", "sum"),
            infeasible_hours=("solver_infeasible_count", "sum"),
            other_solver_failure_hours=("solver_other_failure_count", "sum"),
            mean_ev_unserved_mwh=("ev_unserved_mwh", "mean"),
            mean_ev_service_ratio=("ev_service_ratio", "mean"),
            mean_pv_curtailment_mwh=("pv_curtailment_mwh", "mean"),
            mean_pcc_energy_mwh=("pcc_energy_mwh", "mean"),
            mean_loading_pu=("mean_loading_pu", "mean"),
            mean_max_loading_pu=("max_loading_pu", "mean"),
            binding_hours=("binding_hours", "sum"),
            thermal_violations=("thermal_violation_count", "sum"),
            voltage_violations=("voltage_violation_count", "sum"),
            solve_time_s=("solve_time_s", "sum"),
        )
        .reset_index()
    )
    summary["feasible_run_fraction"] = (
        summary["strict_feasible_runs"] / summary["runs"]
    )
    summary.to_csv(SUMMARY_OUT, index=False)

    pair_feas = build_pair_feasibility(df)
    pair_feas.to_csv(FEAS_OUT, index=False)

    paired = build_strict_feasible_paired_effects(df, pair_feas)
    paired.to_csv(PAIRED_OUT, index=False)

    pair_summary = (
        pair_feas.groupby(["stress_regime", "feeder_count", "mpc_horizon_h"])
        .agg(
            paired_runs=("seed", "size"),
            both_strict_feasible=("both_strict_feasible", "sum"),
            dlr_restores_feasibility=("dlr_restores_feasibility", "sum"),
            str_only_feasible=("str_only_feasible", "sum"),
            neither_feasible=("neither_feasible", "sum"),
        )
        .reset_index()
    )
    pair_summary["dlr_feasibility_restoration_rate"] = (
        pair_summary["dlr_restores_feasibility"] / pair_summary["paired_runs"]
    )

    runtime = time.perf_counter() - start_all
    meta = {
        "rows": int(len(df)),
        "windows": int(len(periods)),
        "seeds": seeds,
        "feeder_regimes": regimes,
        "feeder_counts": [regime_rows[r]["feeder_count"] for r in regimes],
        "mpc_horizons_h": horizons,
        "rating_cases": CASES,
        "scenario_count": int(SCENARIO_COUNT),
        "control_interval_h": 1,
        "reoptimization_interval_h": 1,
        "actions_executed_per_solve": 1,
        "runtime_s": float(runtime),
        "smoke_test": bool(SMOKE_TEST),
        "output": str(OUT),
        "summary_output": str(SUMMARY_OUT),
        "pair_feasibility_output": str(FEAS_OUT),
        "strict_feasible_paired_output": str(PAIRED_OUT),
        "execution_semantics": (
            "true hourly receding horizon: solve H-hour SMPC every hour, "
            "implement k=0 only, update realized states, repeat"
        ),
        "scientific_note": (
            "Phase 4C confirms the Phase-4 findings under genuine receding-horizon "
            "implementation using the frozen nominal (37) and high-stress (43) feeder "
            "regimes and the predeclared 2/4/8 h horizons. Continuous paired effects "
            "are exported only for pairs where both STR and DLR remain strictly feasible."
        ),
    }
    META_OUT.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nPASS: Phase-4C receding-horizon result contract generated.")
    print("Saved:", OUT)
    print("Rows:", len(df))
    print("Total failed optimization hours:", int(df["solver_fail_count"].sum()))
    print("Other (non-infeasibility) solver failures:", int(df["solver_other_failure_count"].sum()))
    print("\nSUMMARY")
    print(summary.to_string(index=False))
    print("\nPAIR FEASIBILITY")
    print(pair_summary.to_string(index=False))
    if len(paired):
        print("\nSTRICT-FEASIBLE PAIRED EV UNSERVED ENERGY (DLR - STR)")
        print(
            paired.groupby(["stress_regime", "feeder_count", "mpc_horizon_h"])
            ["ev_unserved_mwh__DLR_minus_STR"]
            .agg(["count", "mean", "std", "min", "median", "max"])
            .to_string()
        )
    print("runtime_s", runtime)
    return df


if __name__ == "__main__":
    main()
