# GitHub upload checklist

Before making the repository public:

- [ ] Create the repository (suggested name: `dlr-ev-pv-transmission-distribution-epsr`).
- [ ] Upload the contents of this folder, preserving the directory structure.
- [ ] Confirm `.env` is **not** present and no API credentials are committed.
- [ ] Choose a license for the authors' original code after confirming institutional/co-author requirements.
- [ ] Run `python scripts/00_restore_repository_inputs.py` after cloning and verify the compressed corridor file restores correctly.
- [ ] Run the key Phase 4–6 scripts or at minimum inspect the included frozen outputs.
- [ ] Create a GitHub release (for example `v1.0-epsr-submission`).
- [ ] Optionally archive the release on Zenodo to obtain a persistent DOI.
- [ ] Replace `[GITHUB_REPOSITORY_URL]` in the manuscript/README availability statement with the public URL.
- [ ] Add the final article DOI to the README after publication.
